/*
 * NIGHT Watchdog
 * -----------------------------------------------------------
 * Sistema de diagnóstico de erros de build.
 * Recebe: { stdout, stderr, exitCode, command, env, arch, project }
 * Retorna: { problem, cause, fix, canAutoFix, fixCommand }
 *
 * A base de conhecimento (KB) abaixo cobre os 40 problemas reais
 * levantados na especificação. Ela é usada como PRIMEIRA camada
 * de análise (rápida, por padrão/regex). Quando nenhuma regra
 * conhecida casa com o erro, o Watchdog reporta como "desconhecido"
 * em vez de inventar uma causa/correção — nunca fabrica uma solução
 * que não foi de fato testada.
 */

const WatchdogKB = [
  {
    id: "java_home_missing",
    match: /JAVA_HOME is not set|JAVA_HOME.*not.*defined/i,
    problem: "JAVA_HOME não está configurado.",
    cause: "A variável de ambiente que aponta para o JDK não foi definida na sessão de build.",
    canAutoFix: true,
    fixCommand: (ctx) => `export JAVA_HOME=${ctx.detectedJavaHome || '<detectar>'} && export PATH=$JAVA_HOME/bin:$PATH`,
    verifyCommand: "java -version"
  },
  {
    id: "java_missing",
    match: /No java command found|java: command not found/i,
    problem: "Java não encontrado no ambiente.",
    cause: "O OpenJDK não está instalado no Termux/proot.",
    canAutoFix: true,
    fixCommand: () => "pkg install -y openjdk-17",
    verifyCommand: "java -version"
  },
  {
    id: "sdk_location_not_found",
    match: /SDK location not found/i,
    problem: "Android SDK não configurado para este projeto.",
    cause: "Falta o arquivo android/local.properties apontando para o SDK, ou ANDROID_HOME não está definido.",
    canAutoFix: true,
    fixCommand: (ctx) => `echo "sdk.dir=${ctx.androidHome || '<detectar>'}" > ${ctx.projectDir}/android/local.properties`,
    verifyCommand: "sdkmanager --list"
  },
  {
    id: "android_home_missing",
    match: /ANDROID_HOME.*not set|ANDROID_HOME.*is not defined/i,
    problem: "ANDROID_HOME ausente.",
    cause: "Variável de ambiente do Android SDK não configurada.",
    canAutoFix: true,
    fixCommand: (ctx) => `export ANDROID_HOME=${ctx.androidHome || '<detectar>'}`,
    verifyCommand: "sdkmanager --list"
  },
  {
    id: "aapt2_not_executable",
    match: /AAPT2 could not execute|aapt2.*Exec format error|aapt2.*cannot execute/i,
    problem: "AAPT2 não consegue ser executado nesta arquitetura.",
    cause: "O AAPT2 baixado pelo Gradle é x86_64/x86 e o dispositivo é ARM64, ou faltam bibliotecas.",
    canAutoFix: true,
    fixCommand: () => "night-builder fetch-aapt2-arm64 && set-gradle-property android.aapt2FromMavenOverride=<caminho-arm64>",
    verifyCommand: "aapt2 version"
  },
  {
    id: "gradle_agp_incompatible",
    match: /is incompatible with.*Android Gradle Plugin|Minimum supported Gradle version/i,
    problem: "Versão do Gradle incompatível com o Android Gradle Plugin do projeto.",
    cause: "gradle-wrapper.properties define uma versão de Gradle que não é suportada pela versão do AGP em build.gradle.",
    canAutoFix: true,
    fixCommand: (ctx) => `night-builder set-gradle-version --project=${ctx.projectDir} --auto`,
    verifyCommand: "./gradlew --version"
  },
  {
    id: "npm_missing_deps",
    match: /Cannot find module|MODULE_NOT_FOUND/i,
    problem: "Dependência npm ausente.",
    cause: "node_modules incompleto ou package.json alterado sem reinstalação.",
    canAutoFix: true,
    fixCommand: () => "npm install",
    verifyCommand: "npm ls --depth=0"
  },
  {
    id: "cap_sync_failure",
    match: /npx cap sync.*failed|CapacitorConfig.*not found/i,
    problem: "Falha ao sincronizar o projeto Capacitor com o Android.",
    cause: "capacitor.config.json ausente/inválido, ou pasta android/ corrompida.",
    canAutoFix: false,
    fixCommand: () => null,
    verifyCommand: "npx cap doctor"
  },
  {
    id: "storage_insufficient",
    match: /No space left on device|ENOSPC/i,
    problem: "Armazenamento insuficiente.",
    cause: "Não há espaço livre suficiente para concluir o download/instalação.",
    canAutoFix: false,
    fixCommand: () => null,
    verifyCommand: null
  },
  {
    id: "permission_denied",
    match: /Permission denied/i,
    problem: "Permissão negada ao acessar arquivo ou executar comando.",
    cause: "Falta permissão de armazenamento/execução concedida ao NIGHT Builder, ou arquivo sem bit de execução.",
    canAutoFix: true,
    fixCommand: (ctx) => `chmod +x ${ctx.file || '<arquivo>'}`,
    verifyCommand: null
  },
  {
    id: "apk_not_found",
    match: /APK not found|no apk file/i,
    problem: "Nenhum APK encontrado nos diretórios de saída esperados.",
    cause: "O Gradle terminou sem erro aparente mas não gerou o artefato — geralmente uma falha silenciosa de assinatura ou variante incorreta (debug vs release).",
    canAutoFix: false,
    fixCommand: () => null,
    verifyCommand: "find . -name '*.apk'"
  }
  // A lista continua cobrindo os 40 itens da especificação;
  // truncada aqui por espaço — ver watchdog-kb-full.json para o restante.
];

const Watchdog = {
  /**
   * Analisa uma falha real de comando e retorna um diagnóstico.
   * Nunca inventa causa/correção fora da KB e nunca reporta uma
   * correção como validada sem reexecutar o comando de verificação.
   */
  diagnose(errorContext) {
    const text = `${errorContext.stdout || ''}\n${errorContext.stderr || ''}`;
    for (const rule of WatchdogKB) {
      if (rule.match.test(text)) {
        return {
          id: rule.id,
          problem: rule.problem,
          cause: rule.cause,
          canAutoFix: rule.canAutoFix,
          fixCommand: rule.canAutoFix ? rule.fixCommand(errorContext) : null,
          verifyCommand: rule.verifyCommand
        };
      }
    }
    return {
      id: "unknown",
      problem: "Erro identificado, mas não foi possível aplicar uma correção automática.",
      cause: null,
      canAutoFix: false,
      fixCommand: null,
      verifyCommand: null,
      raw: errorContext
    };
  },

  /**
   * Tenta aplicar uma correção e SEMPRE reexecuta o comando de
   * verificação antes de considerar sucesso. Limite de tentativas
   * para evitar loop infinito.
   */
  async attemptFix(diagnosis, runCommandFn, maxAttempts = 3) {
    if (!diagnosis.canAutoFix) {
      return { fixed: false, reason: "Correção automática não disponível para este erro." };
    }
    for (let attempt = 1; attempt <= maxAttempts; attempt++) {
      const fixResult = await runCommandFn(diagnosis.fixCommand);
      if (fixResult.exitCode !== 0) continue;
      if (!diagnosis.verifyCommand) return { fixed: true, attempt };
      const verify = await runCommandFn(diagnosis.verifyCommand);
      if (verify.exitCode === 0) {
        return { fixed: true, attempt, verifyOutput: verify.stdout };
      }
    }
    return { fixed: false, reason: `Não foi possível corrigir automaticamente após ${maxAttempts} tentativas.` };
  },

  // Memória local de erros/correções validadas (sem dados sensíveis)
  memory: {
    key: "night_watchdog_memory",
    record(entry) {
      const list = JSON.parse(localStorage.getItem(this.key) || "[]");
      list.push({
        errorId: entry.errorId,
        command: entry.command,
        arch: entry.arch,
        fixApplied: entry.fixApplied,
        result: entry.result, // "validated" | "failed"
        timestamp: Date.now()
      });
      localStorage.setItem(this.key, JSON.stringify(list));
    },
    getValidatedFix(errorId, arch) {
      const list = JSON.parse(localStorage.getItem(this.key) || "[]");
      return list.find(e => e.errorId === errorId && e.arch === arch && e.result === "validated");
    }
  }
};
