/*
 * NIGHT Builder - App Logic
 * Liga a interface HTML aos comandos reais via bridge.js.
 * Nenhum estado aqui é fingido: se o plugin nativo não responder,
 * a tela mostra erro real, não um "sucesso" fabricado.
 */

let currentProject = null;

// ---------- NAVEGAÇÃO ----------
document.querySelectorAll('.nav-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.nav-btn').forEach(b => b.classList.remove('active'));
    document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
    btn.classList.add('active');
    document.getElementById('screen-' + btn.dataset.screen).classList.add('active');
  });
});

function log(elId, text) {
  const el = document.getElementById(elId);
  el.textContent += text + "\n";
  el.scrollTop = el.scrollHeight;
}

// ---------- DASHBOARD / STATUS ----------
async function refreshDashboard() {
  try {
    const status = await NightBuilder.getEnvironmentStatus();
    document.getElementById('env-status').textContent = status.ready ? "AMBIENTE PRONTO" : "AMBIENTE INCOMPLETO";
    document.getElementById('dash-arch').textContent = status.arch || '-';
    document.getElementById('dash-java').textContent = status.components.java?.version || 'Ausente';
    document.getElementById('dash-node').textContent = status.components.node?.version || 'Ausente';
    document.getElementById('dash-gradle').textContent = status.components.gradle?.version || 'Ausente';
    document.getElementById('dash-sdk').textContent = status.components.androidSdk?.version || 'Ausente';
    document.getElementById('dash-aapt2').textContent = status.components.aapt2?.ok ? 'OK' : 'Falhou';
    document.getElementById('dash-project').textContent = currentProject?.name || 'Nenhum';

    // Preenche a tabela de componentes na tela "Ambiente"
    const tbody = document.querySelector('#env-table tbody');
    tbody.innerHTML = '';
    for (const [name, info] of Object.entries(status.components)) {
      const tr = document.createElement('tr');
      const cls = info.ok ? 'status-ok' : (info.installed ? 'status-warn' : 'status-err');
      const label = info.ok ? '✓ Funcionando' : (info.installed ? '! Instalado mas falhou no teste' : '✗ Ausente');
      tr.innerHTML = `<td>${name}</td><td class="${cls}">${label}</td><td>${info.version || '-'}</td>`;
      tbody.appendChild(tr);
    }
  } catch (e) {
    document.getElementById('env-status').textContent = "Erro: " + e.message;
  }
}
refreshDashboard();

// ---------- PREPARAR AMBIENTE ----------
document.getElementById('btn-prepare-env').addEventListener('click', async () => {
  document.getElementById('env-progress').textContent = '';
  try {
    await NightBuilder.prepareEnvironment((progress) => {
      log('env-progress', `[${progress.step}] ${progress.message}`);
    });
    log('env-progress', '[✓] Ambiente pronto.');
    refreshDashboard();
  } catch (e) {
    log('env-progress', '[!] Falha: ' + e.message);
    handleWatchdogError({ stderr: e.message, command: 'prepareEnvironment' });
  }
});

document.getElementById('btn-update-env').addEventListener('click', async () => {
  document.getElementById('env-progress').textContent = '';
  log('env-progress', 'Verificando atualizações de componentes...');
  try {
    await NightBuilder.prepareEnvironment((progress) => {
      log('env-progress', `[${progress.step}] ${progress.message}`);
    });
    refreshDashboard();
  } catch (e) {
    log('env-progress', '[!] Falha: ' + e.message);
  }
});

// ---------- PROJETOS ----------
document.getElementById('btn-add-project').addEventListener('click', async () => {
  try {
    const project = await NightBuilder.pickProject();
    currentProject = project; // { name, dir, detected: { hasIndexHtml, hasPackageJson, hasAndroidDir, ... } }
    renderProjectList();
    document.getElementById('project-config').classList.remove('hidden');
    document.getElementById('cfg-dir').textContent = project.dir;
    refreshDashboard();
  } catch (e) {
    alert('Erro ao selecionar projeto: ' + e.message);
  }
});

function renderProjectList() {
  const list = document.getElementById('project-list');
  list.innerHTML = '';
  if (!currentProject) return;
  const div = document.createElement('div');
  div.className = 'list-item';
  div.textContent = `${currentProject.name} — ${currentProject.dir}`;
  list.appendChild(div);
}

document.querySelectorAll('#project-config input').forEach(input => {
  input.addEventListener('change', async () => {
    if (!currentProject) return;
    const config = {
      name: document.getElementById('cfg-name').value,
      packageId: document.getElementById('cfg-package').value,
      version: document.getElementById('cfg-version').value,
      versionCode: parseInt(document.getElementById('cfg-versioncode').value || '1', 10),
      projectDir: currentProject.dir
    };
    await NightBuilder.saveProjectConfig(config);
  });
});

// ---------- COMPILAÇÃO ----------
document.getElementById('btn-compile').addEventListener('click', async () => {
  if (!currentProject) { alert('Selecione um projeto primeiro.'); return; }
  document.getElementById('build-log').textContent = '';
  document.getElementById('build-result').classList.add('hidden');
  document.getElementById('btn-cancel-build').classList.remove('hidden');
  document.querySelectorAll('.step').forEach(s => s.classList.remove('active', 'done', 'error'));

  try {
    const result = await NightBuilder.buildApk((progress) => {
      const stepEl = document.querySelector(`.step[data-step="${progress.step}"]`);
      document.querySelectorAll('.step.active').forEach(s => s.classList.remove('active'));
      if (stepEl) stepEl.classList.add(progress.done ? 'done' : 'active');
      if (progress.log) log('build-log', progress.log);
    });

    document.getElementById('btn-cancel-build').classList.add('hidden');

    if (result.success) {
      document.querySelectorAll('.step').forEach(s => s.classList.add('done'));
      showBuildSummary(result);
    } else {
      document.querySelector('.step.active')?.classList.add('error');
      log('build-log', '[!] Build falhou: ' + result.error);
      handleWatchdogError({ stderr: result.error, command: 'buildApk', projectDir: currentProject.dir });
    }
  } catch (e) {
    document.getElementById('btn-cancel-build').classList.add('hidden');
    log('build-log', '[!] Erro: ' + e.message);
  }
});

document.getElementById('btn-cancel-build').addEventListener('click', async () => {
  await NightBuilder.cancelBuild();
  log('build-log', '[!] Build cancelado pelo usuário.');
  document.getElementById('btn-cancel-build').classList.add('hidden');
});

function showBuildSummary(result) {
  document.getElementById('build-result').classList.remove('hidden');
  document.getElementById('build-summary').innerHTML = `
    <p>Projeto: ${currentProject.name}</p>
    <p>APK: ${result.apkPath}</p>
    <p>Tamanho: ${(result.sizeBytes / 1024 / 1024).toFixed(2)} MB</p>
    <p>Status: <span class="status-ok">Sucesso</span></p>
  `;
  document.getElementById('btn-install-apk').onclick = () => NightBuilder.installApk(result.apkPath);
  document.getElementById('btn-export-apk').onclick = () => NightBuilder.exportApk(result.apkPath);
}

// ---------- WATCHDOG ----------
async function handleWatchdogError(errorContext) {
  const diagnosis = Watchdog.diagnose(errorContext);
  renderWatchdogEntry(diagnosis);

  if (diagnosis.canAutoFix) {
    const fixResult = await Watchdog.attemptFix(diagnosis, async (cmd) => {
      return NightBuilder.runCommand(cmd, errorContext.projectDir);
    });
    Watchdog.memory.record({
      errorId: diagnosis.id,
      command: errorContext.command,
      arch: (await NightBuilder.getSystemInfo()).arch,
      fixApplied: diagnosis.fixCommand,
      result: fixResult.fixed ? 'validated' : 'failed'
    });
    renderWatchdogEntry({
      problem: fixResult.fixed ? 'Correção aplicada e verificada com sucesso.' : fixResult.reason,
      cause: null
    });
  }
}

function renderWatchdogEntry(diagnosis) {
  const list = document.getElementById('watchdog-log');
  const div = document.createElement('div');
  div.className = 'list-item';
  div.innerHTML = `<strong>${diagnosis.problem}</strong>` +
    (diagnosis.cause ? `<br><span class="hint">${diagnosis.cause}</span>` : '');
  list.prepend(div);
}

// ---------- TERMINAL ----------
document.getElementById('btn-run-command').addEventListener('click', runTerminalCommand);
document.getElementById('terminal-input').addEventListener('keydown', (e) => {
  if (e.key === 'Enter') runTerminalCommand();
});

async function runTerminalCommand() {
  const input = document.getElementById('terminal-input');
  const command = input.value.trim();
  if (!command) return;
  log('terminal-output', '$ ' + command);
  input.value = '';
  try {
    const result = await NightBuilder.runCommand(command, currentProject?.dir, (chunk) => {
      log('terminal-output', chunk.text);
    });
    log('terminal-output', `[exitCode: ${result.exitCode}]`);
  } catch (e) {
    log('terminal-output', '[!] ' + e.message);
  }
}
