/*
 * NIGHT Builder Bridge
 * -----------------------------------------------------------
 * Ponte entre a interface HTML/CSS/JS e o plugin nativo Android
 * (NightBuilderPlugin.java), registrado via Capacitor.
 *
 * Toda função aqui retorna dados REAIS vindos do lado nativo:
 * stdout, stderr, exitCode. Nada aqui é simulado — se o plugin
 * nativo não estiver disponível (ex: rodando isso num navegador
 * comum fora do APK), as chamadas vão falhar de forma explícita,
 * nunca retornar sucesso falso.
 */

const NightBuilder = (() => {
  let native = null;

  function getNative() {
    if (native) return native;
    if (window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.NightBuilder) {
      native = window.Capacitor.Plugins.NightBuilder;
      return native;
    }
    return null;
  }

  function requireNative() {
    const n = getNative();
    if (!n) {
      throw new Error(
        "Plugin nativo NightBuilder indisponível. Este recurso só funciona " +
        "dentro do APK compilado no Android, não em um navegador comum."
      );
    }
    return n;
  }

  return {
    // Detecta arquitetura, versão Android, armazenamento, permissões
    async getSystemInfo() {
      return requireNative().getSystemInfo();
    },

    // Executa a checklist completa de preparação do ambiente
    // (ver ARQUITETURA.md / plugin nativo para a implementação real)
    async prepareEnvironment(onProgress) {
      const n = requireNative();
      // addListener é fornecido pelo Capacitor para eventos contínuos
      const handle = n.addListener('environmentProgress', (data) => {
        if (onProgress) onProgress(data);
      });
      const result = await n.prepareEnvironment();
      handle.remove();
      return result; // { steps: [...], success: bool }
    },

    async getEnvironmentStatus() {
      return requireNative().getEnvironmentStatus();
    },

    async pickProject() {
      return requireNative().pickProject(); // abre seletor real de pasta/zip
    },

    async saveProjectConfig(config) {
      // config: { name, packageId, version, versionCode, iconPath, projectDir }
      return requireNative().saveProjectConfig(config);
    },

    async runCommand(command, cwd, onOutput) {
      const n = requireNative();
      const handle = n.addListener('commandOutput', (data) => {
        if (onOutput) onOutput(data); // streaming real de stdout/stderr
      });
      const result = await n.runCommand({ command, cwd });
      handle.remove();
      return result; // { stdout, stderr, exitCode }
    },

    async buildApk(onProgress) {
      const n = requireNative();
      const handle = n.addListener('buildProgress', (data) => {
        if (onProgress) onProgress(data); // { step, log, done }
      });
      const result = await n.buildApk();
      handle.remove();
      return result; // { success, apkPath, sizeBytes, error }
    },

    async cancelBuild() {
      return requireNative().cancelBuild();
    },

    async installApk(path) {
      return requireNative().installApk({ path });
    },

    async exportApk(path) {
      return requireNative().exportApk({ path });
    },

    async listFiles(dir) {
      return requireNative().listFiles({ dir });
    },

    async requestPermissions(permissions) {
      return requireNative().requestPermissions({ permissions });
    }
  };
})();
