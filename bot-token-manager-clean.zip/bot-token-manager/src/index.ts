// Carregar .env automaticamente — deve ser o primeiro import.
// Se o arquivo .env não existir, continua sem erro.
import "dotenv/config";

import app from "./app.js";
import { connectDiscord } from "./lib/discord.js";
import { logger } from "./lib/logger.js";

// PORT é opcional — padrão 3000.
const rawPort = process.env["PORT"] ?? "3000";
const port = Number(rawPort);

if (Number.isNaN(port) || port <= 0) {
  logger.error({ PORT: rawPort }, "Valor de PORT inválido — verifique o .env");
  process.exit(1);
}

const server = app.listen(port, (err?: Error) => {
  if (err) {
    logger.error({ err }, "Erro ao iniciar o servidor HTTP");
    process.exit(1);
  }
  logger.info({ port }, "Servidor HTTP iniciado (health check em /api/healthz)");
});

connectDiscord().catch((error: unknown) => {
  logger.error({ err: error }, "Não foi possível conectar o bot Discord");
  server.close(() => process.exit(1));
});
