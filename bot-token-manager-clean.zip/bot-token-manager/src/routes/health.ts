import { Router, type IRouter } from "express";

const router: IRouter = Router();

// Health check — usado por hospedagens para verificar se o processo está ativo.
router.get("/healthz", (_req, res) => {
  res.json({ status: "ok" });
});

export default router;
