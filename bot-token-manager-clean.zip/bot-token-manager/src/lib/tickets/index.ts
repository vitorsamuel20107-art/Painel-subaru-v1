import {
  ActionRowBuilder,
  AttachmentBuilder,
  ButtonBuilder,
  ButtonStyle,
  ChannelType,
  Client,
  EmbedBuilder,
  GuildMember,
  Interaction,
  Message,
  PermissionFlagsBits,
  TextChannel,
} from "discord.js";
import path from "node:path";
import { logger } from "../logger.js";

// ─── IDs ────────────────────────────────────────────────────────────────────
const PANEL_CHANNEL_ID = "1522327800424435773";
const ROLE_SUPORTE_ID  = "1522399407365165177";
const ROLE_DONO_ID     = "1490895038576726217";

// ─── Button custom IDs ───────────────────────────────────────────────────────
const BTN_OPEN  = "ticket_open";
const BTN_CLOSE = "ticket_close";

// ─── Colours ─────────────────────────────────────────────────────────────────
const COLOR_PURPLE = 0x7c3aed;
const COLOR_RED    = 0xe11d48;

// ─── Assets ──────────────────────────────────────────────────────────────────
// process.cwd() = raiz do projeto (onde está o package.json)
const ASSETS_ROOT = path.resolve(process.cwd(), "assets");
const BANNER_PATH = path.join(ASSETS_ROOT, "banner.png");
const THUMB_PATH  = path.join(ASSETS_ROOT, "thumb.png");

// ─── In-memory ticket registry ───────────────────────────────────────────────
interface TicketEntry {
  openerId: string;
  timer: NodeJS.Timeout;
}
const openTickets = new Map<string, TicketEntry>();

// ─── Helpers ─────────────────────────────────────────────────────────────────
function ptBrDate(): string {
  return new Date().toLocaleDateString("pt-BR", {
    day: "numeric",
    month: "long",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
    timeZone: "America/Sao_Paulo",
  });
}

// ─── Panel ───────────────────────────────────────────────────────────────────
async function sendPanel(channel: TextChannel): Promise<void> {
  // Evitar painel duplicado a cada reinicialização
  const recent = await channel.messages.fetch({ limit: 20 });
  const alreadySent = recent.find(
    (m) =>
      m.author.bot &&
      m.embeds.length > 0 &&
      m.embeds[0]?.title?.includes("Suporte"),
  );
  if (alreadySent) {
    logger.info({ channelId: channel.id }, "Ticket panel already present, skipping");
    return;
  }

  const banner = new AttachmentBuilder(BANNER_PATH, { name: "banner.png" });
  const thumb  = new AttachmentBuilder(THUMB_PATH,  { name: "thumb.png"  });

  const embed = new EmbedBuilder()
    .setColor(COLOR_PURPLE)
    .setTitle("🔨 Suporte — [NIGHT CHEATS]")
    .setDescription(
      "**Abra um ticket se precisar de:**\n\n" +
      "• Tirar dúvidas sobre nossos scripts, produtos ou serviços;\n\n" +
      "• Receber ajuda com configuração;\n\n" +
      "• Resolver bugs ou problemas técnicos;\n\n" +
      "• Resolver problemas relacionados a compras;\n\n" +
      "🎫 Clique no botão abaixo para abrir um ticket.",
    )
    .setImage("attachment://banner.png")
    .setThumbnail("attachment://thumb.png")
    .setFooter({ text: "Night Cheats • Suporte e atendimento" });

  const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder()
      .setCustomId(BTN_OPEN)
      .setLabel("Abrir Ticket")
      .setEmoji("🎫")
      .setStyle(ButtonStyle.Success),
  );

  await channel.send({ embeds: [embed], files: [banner, thumb], components: [row] });
  logger.info({ channelId: channel.id }, "Ticket panel sent");
}

// ─── Open ticket ─────────────────────────────────────────────────────────────
async function handleOpen(interaction: Interaction): Promise<void> {
  if (!interaction.isButton() || interaction.customId !== BTN_OPEN) return;
  if (!interaction.guild || !interaction.member) return;

  await interaction.deferReply({ ephemeral: true });

  const guild  = interaction.guild;
  const user   = interaction.user;
  const member = interaction.member as GuildMember;

  // Impedir tickets duplicados
  for (const [chId, entry] of openTickets.entries()) {
    if (entry.openerId === user.id) {
      if (guild.channels.cache.has(chId)) {
        await interaction.editReply({ content: `Você já tem um ticket aberto: <#${chId}>` });
        return;
      }
      openTickets.delete(chId);
    }
  }

  // Nome do canal: suporte-<username> (apenas alfanumérico, limite do Discord)
  const safeName    = member.user.username.toLowerCase().replace(/[^a-z0-9]/g, "").slice(0, 20);
  const channelName = `suporte-${safeName}`;

  const ticketChannel = await guild.channels.create({
    name: channelName,
    type: ChannelType.GuildText,
    permissionOverwrites: [
      { id: guild.roles.everyone.id, deny:  [PermissionFlagsBits.ViewChannel] },
      { id: user.id,         allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages] },
      { id: ROLE_SUPORTE_ID, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages] },
      { id: ROLE_DONO_ID,    allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages] },
    ],
  });

  const welcomeEmbed = new EmbedBuilder()
    .setColor(COLOR_PURPLE)
    .setTitle("👋 Bem-vindo ao suporte!")
    .setDescription(
      `Olá, ${user}.\n\n` +
      "Explique sua dúvida ou problema de forma clara e objetiva.\n\n" +
      "⚠️ Não abra um ticket sem enviar nenhuma mensagem.\n\n" +
      "Tickets sem resposta serão fechados automaticamente após **2 minutos**.\n\n" +
      "⌛ Nossa equipe responderá o mais rápido possível.",
    )
    .setFooter({ text: "Night Cheats • Suporte" });

  const closeRow = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder()
      .setCustomId(BTN_CLOSE)
      .setLabel("Fechar Ticket")
      .setEmoji("🔒")
      .setStyle(ButtonStyle.Danger),
  );

  await ticketChannel.send({
    content: `<@&${ROLE_SUPORTE_ID}> <@&${ROLE_DONO_ID}> ${user}`,
    embeds:     [welcomeEmbed],
    components: [closeRow],
  });

  // Timer de inatividade 2 min (apenas silêncio do criador importa)
  const timer = setTimeout(
    () => void autoClose(ticketChannel, user.id),
    2 * 60 * 1000,
  );
  openTickets.set(ticketChannel.id, { openerId: user.id, timer });

  await interaction.editReply({ content: `✅ Seu ticket foi criado: <#${ticketChannel.id}>` });
  logger.info({ channelId: ticketChannel.id, userId: user.id }, "Ticket opened");
}

// ─── Auto-close (inatividade) ─────────────────────────────────────────────────
async function autoClose(channel: TextChannel, openerId: string): Promise<void> {
  openTickets.delete(channel.id);

  const closeEmbed = new EmbedBuilder()
    .setColor(COLOR_RED)
    .setTitle("⏰ Ticket fechado por inatividade")
    .setDescription("Seu ticket foi encerrado automaticamente por falta de resposta.")
    .addFields(
      {
        name:  "📋 Motivo",
        value: "Nenhuma mensagem foi enviada pelo criador do ticket durante os primeiros 2 minutos.",
      },
      { name: "🕒 Data e hora", value: ptBrDate() },
    )
    .setFooter({ text: "Caso ainda precise de ajuda, basta abrir um novo ticket." });

  await channel.send({ embeds: [closeEmbed] });

  // DM para o usuário
  try {
    const user = await channel.client.users.fetch(openerId);
    const dmEmbed = new EmbedBuilder()
      .setColor(COLOR_RED)
      .setTitle("⏰ Ticket fechado por inatividade")
      .setDescription(
        "Seu ticket foi fechado automaticamente.\n\n" +
        "**Motivo:** Você não enviou nenhuma mensagem durante os primeiros 2 minutos.\n\n" +
        "Caso precise de ajuda, abra outro ticket.",
      );
    await user.send({ embeds: [dmEmbed] });
  } catch {
    logger.warn({ userId: openerId }, "Could not DM user (DMs may be disabled)");
  }

  // Deletar canal após 5 s
  setTimeout(() => {
    channel.delete("Ticket fechado por inatividade").catch(() => {
      logger.warn({ channelId: channel.id }, "Could not delete ticket channel");
    });
  }, 5_000);

  logger.info({ channelId: channel.id, openerId }, "Ticket auto-closed (inactivity)");
}

// ─── Manual close ─────────────────────────────────────────────────────────────
async function handleClose(interaction: Interaction): Promise<void> {
  if (!interaction.isButton() || interaction.customId !== BTN_CLOSE) return;
  if (!interaction.guild || !interaction.member) return;

  const member = interaction.member as GuildMember;
  const hasPermission =
    member.roles.cache.has(ROLE_SUPORTE_ID) ||
    member.roles.cache.has(ROLE_DONO_ID);

  if (!hasPermission) {
    await interaction.reply({
      content: "❌ Apenas a equipe de suporte pode fechar tickets.",
      ephemeral: true,
    });
    return;
  }

  await interaction.deferUpdate();

  const channel = interaction.channel as TextChannel;
  const entry   = openTickets.get(channel.id);
  if (entry) {
    clearTimeout(entry.timer);
    openTickets.delete(channel.id);
  }

  const closeEmbed = new EmbedBuilder()
    .setColor(COLOR_RED)
    .setTitle("🔒 Ticket encerrado")
    .setDescription(
      `Ticket fechado por ${interaction.user} em ${ptBrDate()}.`,
    )
    .setFooter({ text: "Night Cheats • Suporte" });

  await channel.send({ embeds: [closeEmbed] });

  setTimeout(() => {
    channel.delete("Ticket fechado pela equipe").catch(() => {
      logger.warn({ channelId: channel.id }, "Could not delete ticket channel");
    });
  }, 5_000);

  logger.info(
    { channelId: channel.id, closedBy: interaction.user.id },
    "Ticket manually closed",
  );
}

// ─── Message watcher (reset do timer de inatividade) ─────────────────────────
function handleMessage(message: Message): void {
  if (message.author.bot) return;
  if (!message.guild)     return;

  const entry = openTickets.get(message.channelId);
  if (!entry) return;

  // Apenas a mensagem do criador cancela o timer
  if (message.author.id !== entry.openerId) return;

  clearTimeout(entry.timer);
  openTickets.delete(message.channelId);
  logger.info(
    { channelId: message.channelId, userId: message.author.id },
    "Opener responded — inactivity timer cancelled",
  );
}

// ─── Registro ─────────────────────────────────────────────────────────────────
export function registerTicketSystem(client: Client): void {
  client.once("clientReady", async (readyClient) => {
    try {
      const channel = await readyClient.channels.fetch(PANEL_CHANNEL_ID);
      if (channel?.isTextBased() && channel.type === ChannelType.GuildText) {
        await sendPanel(channel as TextChannel);
      } else {
        logger.error({ channelId: PANEL_CHANNEL_ID }, "Panel channel not found or not GuildText");
      }
    } catch (err) {
      logger.error({ err }, "Failed to initialise ticket panel");
    }
  });

  client.on("interactionCreate", async (interaction) => {
    try {
      if (!interaction.isButton()) return;
      if (interaction.customId === BTN_OPEN)  await handleOpen(interaction);
      if (interaction.customId === BTN_CLOSE) await handleClose(interaction);
    } catch (err) {
      logger.error({ err }, "Ticket interaction error");
    }
  });

  client.on("messageCreate", handleMessage);

  logger.info("Ticket system registered");
}
