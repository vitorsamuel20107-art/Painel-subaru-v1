import { Client, GatewayIntentBits } from "discord.js";
import { logger } from "./logger.js";
import { registerTicketSystem } from "./tickets/index.js";

export const discordClient = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    // GuildMessages: necessário para detectar quando o criador do ticket envia mensagem.
    // MessageContent (privileged) NÃO é necessário — verificamos apenas message.author.id.
    // Ative no Dev Portal → Bot → Privileged Gateway Intents somente se precisar do conteúdo.
    GatewayIntentBits.GuildMessages,
  ],
});

discordClient.once("clientReady", (client) => {
  logger.info({ discordTag: client.user.tag }, "Discord bot is online");
});

discordClient.on("error", (error) => {
  logger.error({ err: error }, "Discord bot client error");
});

discordClient.on("shardError", (error) => {
  logger.error({ err: error }, "Discord gateway connection error");
});

// Registrar sistemas independentes aqui — não modificar outros módulos
registerTicketSystem(discordClient);

export async function connectDiscord(): Promise<void> {
  // Verificar token em runtime (após dotenv já ter sido carregado em index.ts)
  const token = process.env["DISCORD_BOT_TOKEN"];
  if (!token) {
    throw new Error(
      "DISCORD_BOT_TOKEN não encontrado.\n" +
      "  → Adicione DISCORD_BOT_TOKEN ao arquivo .env e reinicie.",
    );
  }
  await discordClient.login(token);
}
