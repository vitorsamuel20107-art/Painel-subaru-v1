#!/bin/bash
cd "$(dirname "$0")"

CHECK_INTERVAL=5; RESTART_DELAY=3; MAX_CRASHES=8; CRASH_WINDOW=60; LOG_MAX=5000
mkdir -p logs
LOG_ST="logs/status.log"; LOG_ERR="logs/error.log"
WD_PID="watchdog.pid"; BOT_PID="bot.pid"

ts()      { date '+%Y-%m-%d %H:%M:%S'; }
log_ev()  { echo "[$(ts)] $1" | tee -a "$LOG_ST"; }
log_err() { echo "[$(ts)] ERROR: $1" | tee -a "$LOG_ERR" >&2; }
rotate()  { local f="$1"; [ -f "$f" ] && [ "$(wc -l < "$f")" -gt $LOG_MAX ] && tail -n $((LOG_MAX/2)) "$f" > "$f.tmp" && mv "$f.tmp" "$f"; }

if [ -f "$WD_PID" ]; then
  OLD=$(cat "$WD_PID" 2>/dev/null)
  [ -n "$OLD" ] && kill -0 "$OLD" 2>/dev/null && echo "Watchdog já rodando (PID $OLD)" >&2 && exit 1
fi
echo $$ > "$WD_PID"
[ ! -f ".env" ] && log_err ".env não encontrado" && rm -f "$WD_PID" && exit 1

BOT_PROC=""
cleanup() {
  log_ev "Watchdog encerrando..."
  [ -n "$BOT_PROC" ] && kill "$BOT_PROC" 2>/dev/null; sleep 1; kill -9 "$BOT_PROC" 2>/dev/null || true
  rm -f "$WD_PID" "$BOT_PID"; exit 0
}
trap cleanup SIGTERM SIGINT SIGHUP

start_bot() {
  [ ! -d "node_modules/discord.js" ] && npm install >> "$LOG_ST" 2>&1
  [ ! -f "dist/index.mjs" ] && { npm run build >> "$LOG_ST" 2>&1 || { log_err "Falha no build"; return 1; }; }
  npm start >> "logs/bot.log" 2>> "$LOG_ERR" &
  BOT_PROC=$!; echo "$BOT_PROC" > "$BOT_PID"
  log_ev "Bot iniciado (PID $BOT_PROC)"
}

log_ev "Watchdog iniciado (PID $$)"; start_bot
CRASH_TIMES=()

while true; do
  sleep "$CHECK_INTERVAL"; rotate "$LOG_ST"; rotate "$LOG_ERR"
  if [ -z "$BOT_PROC" ] || ! kill -0 "$BOT_PROC" 2>/dev/null; then
    NOW=$(date +%s); CRASH_TIMES+=("$NOW")
    RECENT=(); for T in "${CRASH_TIMES[@]}"; do (( NOW-T <= CRASH_WINDOW )) && RECENT+=("$T"); done
    CRASH_TIMES=("${RECENT[@]}"); COUNT=${#CRASH_TIMES[@]}
    log_err "Bot caiu (crashes/${CRASH_WINDOW}s: $COUNT)"
    if (( COUNT >= MAX_CRASHES )); then log_err "Loop de crash — pausando 60s"; sleep 60; CRASH_TIMES=(); fi
    log_ev "Reiniciando em ${RESTART_DELAY}s..."; sleep "$RESTART_DELAY"
    start_bot || log_err "Falha ao reiniciar"
  else
    (( $(date +%s) % 60 < CHECK_INTERVAL )) && log_ev "✓ Bot ativo (PID $BOT_PROC)"
  fi
done
