#!/bin/bash
set -e
cd "$(dirname "$0")"

R='\033[0;31m'; G='\033[0;32m'; Y='\033[1;33m'; C='\033[0;36m'; NC='\033[0m'
_ok()   { echo -e "${G}[✓]${NC} $1"; }
_warn() { echo -e "${Y}[!]${NC} $1"; }
_err()  { echo -e "${R}[✗]${NC} $1"; exit 1; }
_info() { echo -e "${C}[→]${NC} $1"; }

echo -e "\n${C}━━━ NightBot Tickets — Iniciando ━━━${NC}\n"

command -v node &>/dev/null || _err "Node.js não encontrado.\n  Termux: pkg install nodejs\n  Ubuntu: apt install nodejs npm"
_ok "Node.js $(node -e 'console.log(process.version)')"

[ ! -f ".env" ] && _err ".env não encontrado.\n  Execute: cp .env.example .env && nano .env"

source .env 2>/dev/null || true
[ -z "$DISCORD_BOT_TOKEN" ] && _err "DISCORD_BOT_TOKEN não definido no .env"
_ok ".env carregado"

[ ! -d "node_modules/discord.js" ] && { _info "Instalando dependências..."; npm install; _ok "Instalado"; } || _ok "node_modules OK"

NEEDS_BUILD=false
[ ! -f "dist/index.mjs" ] && NEEDS_BUILD=true && _warn "Compilando..."
[ "$NEEDS_BUILD" = false ] && NEWER=$(find src -name "*.ts" -newer dist/index.mjs 2>/dev/null | head -1) && [ -n "$NEWER" ] && NEEDS_BUILD=true && _warn "Recompilando..."
[ "$NEEDS_BUILD" = true ] && npm run build && _ok "Build OK" || _ok "dist/ atualizado"

mkdir -p logs
_ok "Iniciando bot...\n"
exec npm start
