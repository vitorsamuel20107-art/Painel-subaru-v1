#!/bin/bash
# ══════════════════════════════════════════════════════════════════
#  painel.sh — Painel de controle NightBot Tickets
# ══════════════════════════════════════════════════════════════════
cd "$(dirname "$0")"

R='\033[0;31m'; G='\033[0;32m'; Y='\033[1;33m'
C='\033[0;36m'; B='\033[1m'; D='\033[0;37m'; NC='\033[0m'

BOT_PID="bot.pid"; WD_PID="watchdog.pid"
LOG_BOT="logs/bot.log"; LOG_ERR="logs/error.log"; LOG_ST="logs/status.log"
mkdir -p logs

get_pid() { local f="$1" p; [ -f "$f" ] && p=$(cat "$f" 2>/dev/null) && [ -n "$p" ] && kill -0 "$p" 2>/dev/null && echo "$p"; }
bot_pid()  { local p; p=$(get_pid "$BOT_PID"); [ -n "$p" ] && echo "$p" && return; pgrep -f "dist/index.mjs" 2>/dev/null | head -1; }
wd_pid()   { get_pid "$WD_PID"; }

bot_running() { local p; p=$(bot_pid); [ -n "$p" ] && echo "$p" > "$BOT_PID"; [ -n "$p" ]; }

status_bot() {
  bot_running && echo -e "${G}🟢 Online${NC} (PID $(bot_pid))" && return
  [ -f "$LOG_ERR" ] && tail -5 "$LOG_ERR" 2>/dev/null | grep -q "ERROR" && echo -e "${Y}⚠️  Erro detectado${NC}" && return
  echo -e "${R}🔴 Offline${NC}"
}
status_wd() { local p; p=$(wd_pid); [ -n "$p" ] && echo -e "${G}🟢 Ativo${NC} (PID $p)" || echo -e "${R}🔴 Inativo${NC}"; }

enter() { echo ""; echo -e "${D}Enter para continuar...${NC}"; read -r; }

header() {
  clear
  echo -e "${C}${B}"
  echo "  ╔═══════════════════════════════════════╗"
  echo "  ║   NightBot Tickets — Painel           ║"
  echo "  ╚═══════════════════════════════════════╝"
  echo -e "${NC}"
  echo -e "  ${B}Bot:${NC}      $(status_bot)"
  echo -e "  ${B}Watchdog:${NC} $(status_wd)"
  echo -e "  ${D}─────────────────────────────────────${NC}"
}

menu() {
  echo -e "\n  ${B}[1]${NC}  Iniciar bot             ${B}[6]${NC}  Status do watchdog"
  echo -e "  ${B}[2]${NC}  Parar bot               ${B}[7]${NC}  Atualizar pelo GitHub"
  echo -e "  ${B}[3]${NC}  Reiniciar bot           ${B}[8]${NC}  Abrir console ao vivo"
  echo -e "  ${B}[4]${NC}  Ver logs (tempo real)   ${B}[9]${NC}  Executar em segundo plano"
  echo -e "  ${B}[5]${NC}  Ver histórico           ${R}[10]${NC} Sair"
  echo ""; echo -ne "  ${B}Opção:${NC} "
}

do_start() {
  bot_running && echo -e "${Y}[!]${NC} Bot já está rodando (PID $(bot_pid))." && enter && return
  [ ! -f ".env" ] && echo -e "${R}[✗]${NC} .env não encontrado." && enter && return
  echo -e "${C}[→]${NC} Iniciando em foreground (use [9] para background)..."
  bash start.sh
}

do_stop() {
  local p; p=$(bot_pid)
  [ -z "$p" ] && echo -e "${Y}[!]${NC} Bot não está rodando." && enter && return
  echo -e "${C}[→]${NC} Parando bot (PID $p)..."
  kill "$p" 2>/dev/null
  local i=0; while kill -0 "$p" 2>/dev/null && (( i<20 )); do sleep 0.5; (( i++ )); done
  kill -9 "$p" 2>/dev/null || true; rm -f "$BOT_PID"
  echo -e "${G}[✓]${NC} Bot parado."; enter
}

do_restart() {
  local p; p=$(bot_pid)
  [ -n "$p" ] && kill "$p" 2>/dev/null && sleep 2 && kill -9 "$p" 2>/dev/null || true && rm -f "$BOT_PID"
  _bg_quiet && echo -e "${G}[✓]${NC} Bot reiniciado." || echo -e "${R}[✗]${NC} Falha. Veja logs/error.log."
  enter
}

do_logs() {
  echo -e "${C}[→]${NC} Logs em tempo real (Ctrl+C para sair)..."
  local files=(); [ -f "$LOG_BOT" ] && files+=("$LOG_BOT"); [ -f "$LOG_ST" ] && files+=("$LOG_ST")
  [ ${#files[@]} -eq 0 ] && echo -e "${Y}[!]${NC} Nenhum log ainda." && enter && return
  tail -f "${files[@]}" 2>/dev/null || true
}

do_history() {
  echo -e "\n  ${B}[1]${NC} bot.log  ${B}[2]${NC} error.log  ${B}[3]${NC} status.log  ${B}[4]${NC} Voltar"
  echo -ne "  Opção: "; read -r s
  case $s in
    1) f="$LOG_BOT";; 2) f="$LOG_ERR";; 3) f="$LOG_ST";; *) return;;
  esac
  [ ! -f "$f" ] && echo -e "${Y}[!]${NC} Arquivo ainda não existe." && enter && return
  echo ""; tail -60 "$f"; enter
}

do_watchdog() {
  local p; p=$(wd_pid)
  if [ -n "$p" ]; then
    echo -e "\n  ${G}🟢 Watchdog ativo${NC} (PID $p)"
    echo -ne "  Parar watchdog? (s/N): "; read -r c
    [[ "$c" =~ ^[Ss]$ ]] && kill "$p" 2>/dev/null && sleep 1 && rm -f "$WD_PID" && echo -e "  ${G}[✓]${NC} Parado."
  else
    echo -e "\n  ${R}🔴 Watchdog inativo${NC}"
    echo -ne "  Iniciar watchdog? (S/n): "; read -r c
    if [[ ! "$c" =~ ^[Nn]$ ]]; then
      bash watchdog.sh >> "$LOG_ST" 2>> "$LOG_ERR" &
      sleep 1; p=$(wd_pid)
      [ -n "$p" ] && echo -e "  ${G}[✓]${NC} Watchdog iniciado (PID $p)" || echo -e "  ${R}[✗]${NC} Falha."
    fi
  fi
  enter
}

do_update() {
  [ ! -d ".git" ] && echo -e "${Y}[!]${NC} Não é um repositório git." && enter && return
  local p; p=$(bot_pid); [ -n "$p" ] && kill "$p" 2>/dev/null && sleep 2 && rm -f "$BOT_PID"
  echo -e "${C}[→]${NC} git pull..."; git pull || { echo -e "${R}[✗]${NC} Erro."; enter; return; }
  npm install; npm run build
  echo -e "${G}[✓]${NC} Atualizado!"
  echo -ne "  Reiniciar agora? (S/n): "; read -r r
  [[ ! "$r" =~ ^[Nn]$ ]] && _bg_quiet && echo -e "${G}[✓]${NC} Bot reiniciado."
  enter
}

do_console() {
  echo -e "${C}[→]${NC} Console ao vivo (Ctrl+C para sair)..."
  local files=(); [ -f "$LOG_BOT" ] && files+=("$LOG_BOT"); [ -f "$LOG_ERR" ] && files+=("$LOG_ERR")
  [ ${#files[@]} -eq 0 ] && echo -e "${Y}[!]${NC} Nenhum log disponível." && enter && return
  tail -n 30 "${files[@]}" 2>/dev/null; echo ""; tail -f "${files[@]}" 2>/dev/null || true
}

_bg_quiet() {
  [ ! -f ".env" ] && return 1
  [ ! -d "node_modules/discord.js" ] && npm install >> "$LOG_ST" 2>&1
  [ ! -f "dist/index.mjs" ] && npm run build >> "$LOG_ST" 2>&1
  mkdir -p logs
  nohup npm start > "$LOG_BOT" 2> "$LOG_ERR" &
  local PID=$!; echo "$PID" > "$BOT_PID"; sleep 1
  kill -0 "$PID" 2>/dev/null
}

do_background() {
  bot_running && echo -e "${Y}[!]${NC} Bot já está rodando (PID $(bot_pid)). Pare primeiro com [2]." && enter && return
  [ ! -f ".env" ] && echo -e "${R}[✗]${NC} .env não encontrado." && enter && return

  [ ! -d "node_modules/discord.js" ] && echo -e "${C}[→]${NC} Instalando dependências..." && npm install
  [ ! -f "dist/index.mjs" ] && echo -e "${C}[→]${NC} Compilando..." && npm run build
  mkdir -p logs

  nohup npm start > "$LOG_BOT" 2> "$LOG_ERR" &
  local PID=$!; echo "$PID" > "$BOT_PID"; sleep 1

  if kill -0 "$PID" 2>/dev/null; then
    echo ""
    echo -e "  ${G}🟢 Bot iniciado em segundo plano.${NC}"
    echo ""
    echo -e "  ${B}PID:${NC} $PID"
    echo ""
    echo -e "  Os logs foram redirecionados para:"
    echo -e "    ${D}$LOG_BOT${NC}"
    echo -e "    ${D}$LOG_ERR${NC}"
    echo ""
    echo -e "  Você pode continuar usando o terminal normalmente."
    echo ""
    echo -ne "  Iniciar watchdog também? (S/n): "; read -r w
    if [[ ! "$w" =~ ^[Nn]$ ]] && [ -z "$(wd_pid)" ]; then
      bash watchdog.sh >> "$LOG_ST" 2>> "$LOG_ERR" &
      sleep 1; local WP; WP=$(wd_pid)
      [ -n "$WP" ] && echo -e "  ${G}[✓]${NC} Watchdog iniciado (PID $WP)"
    fi
  else
    echo -e "  ${R}[✗]${NC} Falha ao iniciar. Verifique logs/error.log"
    rm -f "$BOT_PID"
  fi
  enter
}

while true; do
  header; menu; read -r c
  case "$c" in
    1) do_start;;  2) do_stop;;   3) do_restart;;  4) do_logs;;
    5) do_history;; 6) do_watchdog;; 7) do_update;; 8) do_console;;
    9) do_background;;
    10) echo -e "\n${D}Saindo. Bot continua em background.${NC}\n"; exit 0;;
    *) echo -e "${R}[!]${NC} Inválido."; sleep 1;;
  esac
done
