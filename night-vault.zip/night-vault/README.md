# NIGHT Vault

Aplicação original em HTML/CSS/JS empacotada com Capacitor para Android. A
interface e a lógica permanecem em `index.html`; o código nativo fica limitado
ao contêiner Android gerado pelo Capacitor.

## Build no Termux

Pré-requisitos:

- Node.js e npm
- JDK compatível com o Android Gradle Plugin
- Android SDK com `platform-tools`, `platforms;android-35` e
  `build-tools;35.0.0`

Na pasta `artifacts/night-vault`:

```sh
npm install
npm run cap:sync
cd android
./gradlew assembleDebug
```

O APK de debug será gerado em:

```text
android/app/build/outputs/apk/debug/app-debug.apk
```

Para gerar o bundle de release:

```sh
cd artifacts/night-vault
npm run cap:build:release
```

O projeto usa o `gradlew` incluído e não depende de uma instalação global do
Gradle. O caminho do Android SDK pode ser informado por `ANDROID_HOME` ou pelo
arquivo `android/local.properties`.