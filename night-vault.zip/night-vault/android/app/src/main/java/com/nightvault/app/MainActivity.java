package com.nightvault.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
