import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.nightvault.app',
  appName: 'NIGHT Vault',
  webDir: 'dist/public',
  bundledWebRuntime: false,
};

export default config;