/**
 * tickets-suporte.ts — Ticket system for the support panel.
 *
 * Each step is individually try/caught and logged so the real cause of any
 * failure is always visible in the console instead of a generic error message.
 */

import {
  ChannelType,
  OverwriteType,
  PermissionFlagsBits,
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
} from "discord.js";
import type {
  ButtonInteraction,
  Client,
  Guild,
  GuildMember,
  TextChannel,
  MessageActionRowComponentBuilder,
} from "discord.js";
import {
  FOUNDER_ROLE_ID,
  ADMIN_ROLE_ID,
  SUPPORT_ROLE_ID,
  SUPPORT_TICKET_CATEGORY_ID,
} from "./constants.js";
import { logger } from "./logger.js";
import { startInactivityTimer, clearInactivityTimer } from "./ticket-timers.js";

function hasPermission(member: GuildMember | null): boolean {
  if (!member) return false;
  return [FOUNDER_ROLE_ID, ADMIN_ROLE_ID, SUPPORT_ROLE_ID].some(id =>
    member.roles.cache.has(id),
  );
}

/**
 * Live check — scans the support category (SUPPORT_TICKET_CATEGORY_ID) for any
 * text channel that has a Member permission overwrite for this user.
 * Returns the channel if found, null otherwise.
 */
function findOpenSupportTicket(guild: Guild, userId: string): TextChannel | null {
  const ch = guild.channels.cache.find(
    c =>
      c.type === ChannelType.GuildText &&
      c.parentId === SUPPORT_TICKET_CATEGORY_ID &&
      (c as TextChannel).permissionOverwrites.cache.some(
        ow => ow.type === OverwriteType.Member && ow.id === userId,
      ),
  );
  return (ch as TextChannel) ?? null;
}

// ── Open support ticket ────────────────────────────────────────────────────
export async function openSupportTicket(
  interaction: ButtonInteraction,
  client: Client,
): Promise<void> {
  const guild  = interaction.guild;
  const member = interaction.member as GuildMember;

  // ── Sanity check ────────────────────────────────────────────────────────
  if (!guild || !member) {
    logger.error(
      { userId: interaction.user.id },
      "openSupportTicket: guild or member is null — interaction came from outside a server",
    );
    await interaction.reply({
      content: "❌ Erro: não foi possível identificar o servidor ou membro.",
      ephemeral: true,
    });
    return;
  }

  const userId = member.id;

  // ── 1. Check for an existing open ticket ────────────────────────────────
  let existing: TextChannel | null = null;
  try {
    existing = findOpenSupportTicket(guild, userId);
  } catch (err) {
    logger.error({ err, userId }, "openSupportTicket: erro durante verificação de ticket existente");
    await interaction.reply({
      content: "❌ Erro ao verificar tickets existentes. Tente novamente.",
      ephemeral: true,
    });
    return;
  }

  if (existing) {
    logger.info(
      { userId, existingChannelId: existing.id, existingChannelName: existing.name },
      "openSupportTicket: usuário já possui ticket aberto — bloqueado",
    );
    await interaction.reply({
      content: `❌ Você já possui um ticket aberto: ${existing}. Finalize ou feche o ticket atual antes de abrir outro.`,
      ephemeral: true,
    });
    return;
  }

  // ── 2. Acknowledge immediately (gives 15-min window for channel creation) ─
  try {
    await interaction.deferReply({ ephemeral: true });
  } catch (err) {
    logger.error({ err, userId }, "openSupportTicket: falha ao fazer deferReply na interação");
    // Cannot reply anymore — just return
    return;
  }

  // ── 3. Verify the support category exists ───────────────────────────────
  const category = guild.channels.cache.get(SUPPORT_TICKET_CATEGORY_ID);
  if (!category) {
    logger.error(
      { SUPPORT_TICKET_CATEGORY_ID, userId, guildId: guild.id },
      "openSupportTicket: categoria de suporte não encontrada no cache — ID incorreto ou bot sem permissão de leitura",
    );
    await interaction.editReply({
      content: "❌ Categoria de suporte não encontrada no servidor. Contate um administrador.",
    });
    return;
  }

  // ── 4. Verify bot has MANAGE_CHANNELS in the category ───────────────────
  const botMember = guild.members.me;
  if (!botMember) {
    logger.error({ userId }, "openSupportTicket: guild.members.me é null — bot não encontrado no servidor");
    await interaction.editReply({ content: "❌ Erro interno do bot. Contate um administrador." });
    return;
  }

  const botPerms = botMember.permissionsIn(category.id);
  if (!botPerms.has(PermissionFlagsBits.ManageChannels)) {
    logger.error(
      { userId, categoryId: SUPPORT_TICKET_CATEGORY_ID, botId: botMember.id },
      "openSupportTicket: bot não tem permissão MANAGE_CHANNELS na categoria de suporte",
    );
    await interaction.editReply({
      content: "❌ O bot não tem permissão para criar canais nesta categoria. Contate um administrador.",
    });
    return;
  }

  // ── 5. Create the ticket channel ─────────────────────────────────────────
  const channelName = `suporte-${member.user.username
    .toLowerCase()
    .replace(/[^a-z0-9]/g, "-")
    .replace(/-+/g, "-")
    .slice(0, 90)}`;

  logger.info({ userId, channelName, categoryId: SUPPORT_TICKET_CATEGORY_ID }, "openSupportTicket: criando canal...");

  const staffAllow = [
    PermissionFlagsBits.ViewChannel,
    PermissionFlagsBits.SendMessages,
    PermissionFlagsBits.ReadMessageHistory,
    PermissionFlagsBits.ManageMessages,
    PermissionFlagsBits.ManageChannels,
    PermissionFlagsBits.AttachFiles,
  ];

  let ticketChannel: TextChannel;
  try {
    ticketChannel = (await guild.channels.create({
      name: channelName,
      type: ChannelType.GuildText,
      parent: SUPPORT_TICKET_CATEGORY_ID,
      permissionOverwrites: [
        { id: guild.roles.everyone, deny: [PermissionFlagsBits.ViewChannel] },
        {
          id: userId,
          allow: [
            PermissionFlagsBits.ViewChannel,
            PermissionFlagsBits.SendMessages,
            PermissionFlagsBits.ReadMessageHistory,
            PermissionFlagsBits.AttachFiles,
          ],
        },
        { id: FOUNDER_ROLE_ID, allow: staffAllow },
        { id: ADMIN_ROLE_ID,   allow: staffAllow },
        { id: SUPPORT_ROLE_ID, allow: staffAllow },
        {
          id: client.user!.id,
          allow: [
            PermissionFlagsBits.ViewChannel,
            PermissionFlagsBits.SendMessages,
            PermissionFlagsBits.ManageChannels,
            PermissionFlagsBits.ReadMessageHistory,
          ],
        },
      ],
    })) as TextChannel;
  } catch (err) {
    const e = err as { code?: number; message?: string; httpStatus?: number };
    logger.error(
      {
        err,
        userId,
        channelName,
        categoryId: SUPPORT_TICKET_CATEGORY_ID,
        discordErrorCode: e?.code,
        httpStatus:       e?.httpStatus,
        errorMessage:     e?.message,
      },
      "openSupportTicket: falha ao criar canal — erro da API Discord",
    );
    await interaction.editReply({
      content: `❌ Falha ao criar o canal do ticket (código Discord: ${e?.code ?? "?"} — ${e?.message ?? "erro desconhecido"}). Contate um administrador.`,
    });
    return;
  }

  logger.info({ userId, channelId: ticketChannel.id, channelName }, "Ticket criado");

  // ── 6. Send the welcome embed ────────────────────────────────────────────
  const closeRow = new ActionRowBuilder<MessageActionRowComponentBuilder>().addComponents(
    new ButtonBuilder()
      .setCustomId(`suporte_close:${ticketChannel.id}`)
      .setLabel("🔒 Fechar Ticket")
      .setStyle(ButtonStyle.Danger),
  );

  try {
    await ticketChannel.send({
      content: `${member} <@&${FOUNDER_ROLE_ID}> <@&${SUPPORT_ROLE_ID}>`,
      embeds: [
        new EmbedBuilder()
          .setTitle("👋 Bem-vindo ao suporte!")
          .setColor(0x8b00ff)
          .setDescription(
            [
              `Olá, ${member}! 👋`,
              "",
              "Explique sua dúvida ou problema de forma clara e vá direto ao assunto.",
              "",
              "⚠️ **Não abra um ticket sem enviar nenhuma mensagem**, pois tickets sem resposta serão encerrados automaticamente após **2 minutos**.",
              "",
              "⏳ Nossa equipe responderá o mais breve possível.",
            ].join("\n"),
          )
          .setFooter({ text: "Night Cheats • Suporte" })
          .setTimestamp(),
      ],
      components: [closeRow],
    });
  } catch (err) {
    logger.error({ err, channelId: ticketChannel.id }, "openSupportTicket: falha ao enviar mensagem de boas-vindas");
    // Don't abort — the channel exists, staff can still see it
  }

  // ── 7. Confirm to user ───────────────────────────────────────────────────
  try {
    await interaction.editReply({ content: `✅ Ticket aberto: ${ticketChannel}` });
  } catch (err) {
    logger.warn({ err }, "openSupportTicket: falha ao editar reply de confirmação");
  }

  // ── 8. Start inactivity timer ────────────────────────────────────────────
  startInactivityTimer(ticketChannel.id, userId, client);
  logger.info({ userId, channelId: ticketChannel.id }, "Contador de 2 minutos iniciado");
}

// ── Close support ticket ───────────────────────────────────────────────────
export async function closeSupportTicket(interaction: ButtonInteraction): Promise<void> {
  const member = interaction.member as GuildMember;

  if (!hasPermission(member)) {
    await interaction.reply({
      content: "❌ Você não tem permissão para fechar este ticket.",
      ephemeral: true,
    });
    return;
  }

  const channelId = interaction.channelId;
  clearInactivityTimer(channelId);

  await interaction.reply({
    content: "🔒 Fechando ticket em 5 segundos...",
    ephemeral: true,
  });

  setTimeout(async () => {
    try {
      if (interaction.channel && !interaction.channel.isDMBased()) {
        await interaction.channel.delete("Ticket de suporte encerrado pela equipe");
        logger.info({ channelId, adminId: interaction.user.id }, "Ticket fechado manualmente pela equipe");
      }
    } catch (err) {
      logger.error({ err, channelId }, "closeSupportTicket: falha ao deletar canal do ticket");
    }
  }, 5000);
}
