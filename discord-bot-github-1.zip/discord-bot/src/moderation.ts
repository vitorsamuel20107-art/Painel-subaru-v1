/**
 * moderation.ts — Automatic moderation for the guild.
 *
 * Rule 1 — Links
 *   • Blocked everywhere except LINKS_ALLOWED_CHANNEL_ID.
 *   • All members (including staff): message deleted silently.
 *   • Regular members: also get a temp warning notice + mod log.
 *   • No infraction counter, no mute, no ban.
 *
 * Rule 2 — Spam (flood / repeated content / whitespace abuse / giant text)
 *   • Infractions expire after 24 h.
 *   • 1st infraction → delete + warning notice + log
 *   • 2nd infraction → delete + 30-min mute + log
 *   • 3rd+ infraction → delete + ban + log
 *   • Staff/immune roles: message deleted, but NO mute or ban.
 *
 * Rule 3 — Directed offensive language
 *   • Isolated swear words are NOT punished.
 *   • Only directed insults (pronoun + word, or 2+ offensive words).
 *   • delete + 5-min mute + log (no ban, no infraction counter).
 *   • Staff are always exempt from this check.
 */

import { EmbedBuilder } from "discord.js";
import type { Message, Client, GuildMember, GuildBasedChannel } from "discord.js";
import {
  FOUNDER_ROLE_ID,
  ADMIN_ROLE_ID,
  SUPPORT_ROLE_ID,
  MOD_LOG_CHANNEL_ID,
} from "./constants.js";
import { logger } from "./logger.js";

// ── Configuration ──────────────────────────────────────────────────────────
/** Only channel where links are freely allowed. */
const LINKS_ALLOWED_CHANNEL_ID = "1493004183035576491";

/** Spam infraction lifetime — after this period the infraction is discarded. */
const INFRACTION_TTL_MS = 24 * 60 * 60 * 1_000; // 24 hours

// ── Detection thresholds ───────────────────────────────────────────────────
const FLOOD_WINDOW_MS        = 5_000;  // ms window to count messages
const FLOOD_LIMIT            = 5;      // messages in window → flood
const REPEAT_WINDOW_MS       = 30_000; // ms window for repeated content
const REPEAT_LIMIT           = 3;      // same content N times → spam
const GIANT_TEXT_THRESHOLD   = 1_200;  // characters
const WHITESPACE_RATIO       = 0.70;   // >70 % whitespace → spam

// ── In-memory state ───────────────────────────────────────────────────────
interface MsgRecord {
  content:   string;
  timestamp: number;
}

/** Recent messages per user — pruned to the last 60 s on every call. */
const userHistory = new Map<string, MsgRecord[]>();

/**
 * Spam infraction timestamps per user.
 * Entries older than INFRACTION_TTL_MS are discarded automatically.
 */
const spamInfractions = new Map<string, number[]>();

// ── Helpers ───────────────────────────────────────────────────────────────
function isStaff(member: GuildMember): boolean {
  return [FOUNDER_ROLE_ID, ADMIN_ROLE_ID, SUPPORT_ROLE_ID]
    .some(id => member.roles.cache.has(id));
}

function getActiveCount(userId: string): number {
  const now   = Date.now();
  const times = (spamInfractions.get(userId) ?? []).filter(t => t > now - INFRACTION_TTL_MS);
  spamInfractions.set(userId, times);
  return times.length;
}

function addInfraction(userId: string): number {
  const now   = Date.now();
  const times = (spamInfractions.get(userId) ?? []).filter(t => t > now - INFRACTION_TTL_MS);
  times.push(now);
  spamInfractions.set(userId, times);
  return times.length;
}

// ── Offensive word list (PT-BR directed insults) ──────────────────────────
const OFFENSIVE_WORDS: string[] = [
  "idiota","imbecil","retardado","retardada","otário","otária",
  "fdp","filho da puta","filha da puta","viado","viadinho","viadona",
  "corno","corna","arrombado","arrombada","babaca","piranha",
  "vagabundo","vagabunda","inútil","escroto","escrotinho",
  "cuzão","puta","putinha","palhaço","palhaça",
  "lixo","escória","nojento","nojenta","verme","parasita",
  "burro","burra","anta","besta","macaco","macaca","lazarento","lazarenta",
];

/** Second-person indicators — signal the message is directed at someone. */
const DIRECTED_PRONOUNS: string[] = [
  "você","voce","vc","tu","te","teu","tua","seu","sua",
];

// ── Detection functions ───────────────────────────────────────────────────
const LINK_RE = /https?:\/\/\S+|discord(?:\.gg|\.com\/invite|app\.com\/invite)\/\S+/i;

function hasAnyLink(content: string): boolean {
  return LINK_RE.test(content);
}

function isFlood(history: MsgRecord[]): boolean {
  const cutoff = Date.now() - FLOOD_WINDOW_MS;
  return history.filter(m => m.timestamp > cutoff).length >= FLOOD_LIMIT;
}

function isRepeatSpam(history: MsgRecord[], content: string): boolean {
  const norm = content.trim().toLowerCase();
  if (norm.length < 3) return false;
  const cutoff = Date.now() - REPEAT_WINDOW_MS;
  const count  = history.filter(
    m => m.timestamp > cutoff && m.content.trim().toLowerCase() === norm,
  ).length;
  return count >= REPEAT_LIMIT;
}

function isGiantText(content: string): boolean {
  if (content.length < GIANT_TEXT_THRESHOLD) return false;
  const puncts = (content.match(/[.!?,;:\-]/g) ?? []).length;
  return puncts / content.length < 0.01; // < 1 % punctuation
}

function isWhitespaceSpam(content: string): boolean {
  if (content.length === 0) return false;
  const wsCount = (content.match(/\s/g) ?? []).length;
  if (wsCount / content.length > WHITESPACE_RATIO) return true;
  if (/(\n\s*){6,}/.test(content)) return true;
  if (/(.)\1{19,}/.test(content)) return true;
  return false;
}

function isOffensiveDirected(content: string): boolean {
  const lower   = content.toLowerCase();
  const matched = OFFENSIVE_WORDS.filter(w => lower.includes(w));
  if (matched.length === 0) return false;
  if (matched.length >= 2) return true; // 2+ offensive words → directed
  return DIRECTED_PRONOUNS.some(p => lower.includes(p)); // pronoun + word → directed
}

// ── Punishment types ──────────────────────────────────────────────────────
type PunishmentType = "warning" | "mute" | "ban" | "offensive-mute" | "link-removed";

interface LogOptions {
  type:         PunishmentType;
  reason:       string;
  member:       GuildMember;
  channelId:    string;
  infractions?: number;
  duration?:    string;
}

// ── Mod log embed ─────────────────────────────────────────────────────────
async function sendModLog(client: Client, guildId: string, opts: LogOptions): Promise<void> {
  const colorMap: Record<PunishmentType, number> = {
    warning:          0xFFC300, // 🟡 Advertência
    mute:             0xFF6B00, // 🟠 Mute
    ban:              0xFF0000, // 🔴 Ban
    "offensive-mute": 0xFF6B00, // 🟠 Mute por ofensa
    "link-removed":   0x3498DB, // 🔵 Link removido
  };
  const labelMap: Record<PunishmentType, string> = {
    warning:          "🟡 Advertência",
    mute:             "🟠 Mute",
    ban:              "🔴 Ban",
    "offensive-mute": "🟠 Mute — Linguagem Ofensiva",
    "link-removed":   "🔵 Link Removido",
  };

  try {
    const guild      = client.guilds.cache.get(guildId);
    if (!guild) return;
    const logChannel = guild.channels.cache.get(MOD_LOG_CHANNEL_ID) as GuildBasedChannel | undefined;
    if (!logChannel?.isTextBased()) return;

    const embed = new EmbedBuilder()
      .setTitle(labelMap[opts.type])
      .setColor(colorMap[opts.type])
      .setThumbnail(opts.member.user.displayAvatarURL())
      .addFields(
        { name: "👤 Usuário", value: `${opts.member.user.tag} (<@${opts.member.id}>)`, inline: true },
        { name: "🆔 ID",      value: opts.member.id,                                    inline: true },
        { name: "📌 Canal",   value: `<#${opts.channelId}>`,                           inline: true },
        { name: "📋 Motivo",  value: opts.reason,                                       inline: false },
      )
      .setTimestamp();

    if (opts.duration    !== undefined)
      embed.addFields({ name: "⏱️ Duração",   value: opts.duration,           inline: true });
    if (opts.infractions !== undefined)
      embed.addFields({ name: "⚠️ Infrações", value: String(opts.infractions), inline: true });

    await (logChannel as any).send({ embeds: [embed] });
  } catch (err) {
    logger.warn({ err }, "moderation: falha ao enviar log no canal de moderação");
  }
}

// ── Low-level utilities ───────────────────────────────────────────────────
async function deleteMsg(message: Message): Promise<void> {
  try {
    if (message.deletable) {
      await message.delete();
      logger.info({ channelId: message.channelId, userId: message.author.id },
        "Moderação: mensagem apagada");
    }
  } catch (err) {
    logger.warn({ err }, "moderation: não foi possível apagar a mensagem");
  }
}

async function tempNotice(message: Message, text: string): Promise<void> {
  try {
    if (!message.inGuild()) return;
    const sent = await message.channel.send({ content: text });
    setTimeout(() => sent.delete().catch(() => {}), 8_000);
  } catch { /* channel may have been deleted */ }
}

// ── Action handlers ───────────────────────────────────────────────────────

/**
 * Rule 1 — Link detected outside the allowed channel.
 * Everyone: delete.  Regular members: also warning + log.
 */
async function handleLink(
  message: Message,
  member:  GuildMember,
  client:  Client,
): Promise<void> {
  await deleteMsg(message);

  if (isStaff(member)) {
    logger.info({ userId: member.id, channelId: message.channelId },
      "Moderação: link de staff removido silenciosamente");
    return;
  }

  await tempNotice(
    message,
    `🔗 <@${member.id}>, links não são permitidos aqui. Use <#${LINKS_ALLOWED_CHANNEL_ID}> para compartilhar links.`,
  );

  await sendModLog(client, message.guildId!, {
    type:      "link-removed",
    reason:    "Envio de link fora do canal permitido",
    member,
    channelId: message.channelId,
  });
}

/**
 * Rule 2 — Spam detected.
 * Staff: delete only (no punishment, no log).
 * Regular members: delete + escalate infraction.
 */
async function handleSpam(
  message: Message,
  member:  GuildMember,
  reason:  string,
  client:  Client,
): Promise<void> {
  await deleteMsg(message);

  if (isStaff(member)) {
    logger.info({ userId: member.id, channelId: message.channelId, reason },
      "Moderação: spam de staff removido (sem punição)");
    return;
  }

  const count = addInfraction(member.id);

  logger.info({ userId: member.id, infractions: count, reason, channelId: message.channelId },
    "Moderação: infração de spam registrada");

  if (count >= 3) {
    // 3rd+ infraction → ban
    try {
      await member.ban({ reason: `Auto-mod: spam reincidente — ${count} infrações em 24h` });
      logger.info({ userId: member.id, infractions: count }, "Moderação: usuário banido por spam");
    } catch (err) {
      logger.error({ err, userId: member.id }, "moderation: falha ao banir usuário");
    }
    await sendModLog(client, message.guildId!, {
      type: "ban", reason, member, channelId: message.channelId, infractions: count,
    });

  } else if (count === 2) {
    // 2nd infraction → 30-min mute
    try {
      await member.timeout(30 * 60 * 1_000, `Auto-mod: 2ª infração de spam — ${reason}`);
      logger.info({ userId: member.id }, "Moderação: timeout de 30min aplicado");
    } catch (err) {
      logger.error({ err, userId: member.id }, "moderation: falha ao aplicar timeout");
    }
    await sendModLog(client, message.guildId!, {
      type: "mute", reason, member, channelId: message.channelId,
      infractions: count, duration: "30 minutos",
    });
    await tempNotice(
      message,
      `🔇 <@${member.id}>, você foi silenciado por **30 minutos** por spam. ` +
      `Esta é sua **2ª infração**. A próxima resultará em ban permanente.`,
    );

  } else {
    // 1st infraction → warning only
    await sendModLog(client, message.guildId!, {
      type: "warning", reason, member, channelId: message.channelId, infractions: count,
    });
    await tempNotice(
      message,
      `⚠️ <@${member.id}>, sua mensagem foi removida por spam (${reason}). ` +
      `**Aviso 1/3** — as infrações expiram em 24h. Com 3 infrações você será banido.`,
    );
  }
}

/**
 * Rule 3 — Directed offensive language.
 * delete + 5-min mute + log.  No ban, no infraction counter.
 */
async function handleOffensive(
  message: Message,
  member:  GuildMember,
  client:  Client,
): Promise<void> {
  const reason = "Insulto ou ofensa direcionada a outro membro";

  await deleteMsg(message);

  try {
    await member.timeout(5 * 60 * 1_000, `Auto-mod: ${reason}`);
    logger.info({ userId: member.id }, "Moderação: timeout de 5min por linguagem ofensiva");
  } catch (err) {
    logger.error({ err, userId: member.id }, "moderation: falha ao aplicar timeout por ofensa");
  }

  await sendModLog(client, message.guildId!, {
    type: "offensive-mute", reason, member,
    channelId: message.channelId, duration: "5 minutos",
  });

  await tempNotice(
    message,
    `🔇 <@${member.id}> foi silenciado por **5 minutos** por insultos ou ofensas a outros membros.`,
  );
}

// ── Main entry point ──────────────────────────────────────────────────────
export async function handleMessage(message: Message, client: Client): Promise<void> {
  // Guards
  if (message.author.bot) return;
  if (!message.guild || !message.inGuild()) return;
  if (!message.content) return; // MessageContent intent not enabled or empty

  const member = message.member as GuildMember | null;
  if (!member) return;

  const content = message.content;

  // ── Rule 1: Links (checked before staff bypass — applies to everyone) ──
  if (message.channelId !== LINKS_ALLOWED_CHANNEL_ID && hasAnyLink(content)) {
    logger.info({ userId: member.id, channelId: message.channelId },
      "Moderação: link detectado fora do canal permitido");
    await handleLink(message, member, client);
    return; // no stacking
  }

  // ── Rules 2 & 3: staff exempt from spam and offensive checks ──────────
  if (isStaff(member)) return;

  const userId = message.author.id;
  const now    = Date.now();

  // Maintain per-user message history (last 60 s)
  const history = (userHistory.get(userId) ?? []).filter(m => m.timestamp > now - 60_000);
  history.push({ content, timestamp: now });
  userHistory.set(userId, history);

  // ── Rule 2: Spam ──────────────────────────────────────────────────────
  let spamReason: string | null = null;

  if      (isFlood(history))               spamReason = "Flood — muitas mensagens em poucos segundos";
  else if (isRepeatSpam(history, content)) spamReason = "Mensagens repetidas";
  else if (isWhitespaceSpam(content))      spamReason = "Spam de espaços ou caracteres repetitivos";
  else if (isGiantText(content))           spamReason = "Texto gigante sem conteúdo legível";

  if (spamReason) {
    logger.info({ userId, reason: spamReason, channelId: message.channelId },
      "Moderação: spam detectado");
    await handleSpam(message, member, spamReason, client);
    return; // no stacking
  }

  // ── Rule 3: Directed offensive language ───────────────────────────────
  if (isOffensiveDirected(content)) {
    logger.info({ userId, channelId: message.channelId },
      "Moderação: linguagem ofensiva detectada");
    await handleOffensive(message, member, client);
  }
}
