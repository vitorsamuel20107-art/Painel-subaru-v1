import {
  Client,
  Collection,
  GatewayIntentBits,
  Events,
} from "discord.js";
import type { Command } from "./types.js";
import { DISCORD_TOKEN } from "./config.js";
import pingCommand from "./commands/ping.js";
import helpCommand from "./commands/help.js";
import serverInfoCommand from "./commands/serverinfo.js";
import painelCommand,  { handleProductSelect,  refreshPanel  } from "./commands/painel.js";
import painel2Command, { handleProductSelect2, refreshPanel2 } from "./commands/painel2.js";
import adminCommand from "./commands/admin.js";
import dmCommand from "./commands/dm.js";
import suporteCommand from "./commands/suporte.js";
import iaCommand from "./commands/ia.js";
import { createTicket1, handleAdminButton1 } from "./tickets.js";
import { createTicket2, handleAdminButton2 } from "./tickets2.js";
import { openSupportTicket, closeSupportTicket } from "./tickets-suporte.js";
import { inactivityTimers, clearInactivityTimer } from "./ticket-timers.js";
import { handleMessage } from "./moderation.js";
import { logger } from "./logger.js";
import type { ButtonInteraction, StringSelectMenuInteraction, ChatInputCommandInteraction } from "discord.js";

type RepliableInteraction = ChatInputCommandInteraction | ButtonInteraction | StringSelectMenuInteraction;

async function safeReplyError(interaction: RepliableInteraction, content: string): Promise<void> {
  try {
    if (interaction.replied || interaction.deferred) {
      await interaction.followUp({ content, ephemeral: true });
    } else {
      await interaction.reply({ content, ephemeral: true });
    }
  } catch (err) {
    logger.warn({ err }, "Could not send error reply to interaction");
  }
}

if (!DISCORD_TOKEN) {
  logger.error(
    "Não é possível iniciar o bot sem o Discord token. " +
    "Adicione o token em config/discord.token e reinicie.",
  );
  process.exit(1);
}

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent, // privileged intent — enable in Discord Dev Portal → Bot → Privileged Gateway Intents
  ],
});

const commands = new Collection<string, Command>();

for (const command of [
  pingCommand,
  helpCommand,
  serverInfoCommand,
  painelCommand,
  painel2Command,
  adminCommand,
  dmCommand,
  suporteCommand,
  iaCommand,
]) {
  commands.set(command.data.name, command);
  logger.info({ command: command.data.name }, "Registered command");
}

client.once(Events.ClientReady, (c) => {
  logger.info({ tag: c.user.tag, guilds: c.guilds.cache.size }, "Bot is online and ready");

  refreshPanel(c);
  refreshPanel2(c);
});

// ── Message handler: inactivity timer + auto-moderation ───────────────────
client.on(Events.MessageCreate, async (message) => {
  if (message.author.bot) return;

  // Cancel inactivity timer on first message from the ticket owner
  const entry = inactivityTimers.get(message.channelId);
  if (entry && message.author.id === entry.userId) {
    clearInactivityTimer(message.channelId);
    logger.info(
      { channelId: message.channelId, userId: message.author.id },
      "Inactivity timer cancelled — first message received from ticket owner",
    );
  }

  // Auto-moderation (all guild channels)
  await handleMessage(message, client);
});

client.on(Events.InteractionCreate, async (interaction) => {
  // ── Slash commands ──────────────────────────────────────────────────────
  if (interaction.isChatInputCommand()) {
    const command = commands.get(interaction.commandName);
    if (!command) {
      logger.warn({ command: interaction.commandName }, "Unknown command received");
      return;
    }

    try {
      await command.execute(interaction);
      logger.info(
        { command: interaction.commandName, user: interaction.user.tag },
        "Command executed",
      );
    } catch (err) {
      logger.error({ err, command: interaction.commandName }, "Error executing command");
      const reply = { content: "Ocorreu um erro ao executar este comando.", ephemeral: true };
      if (interaction.replied || interaction.deferred) {
        await interaction.followUp(reply);
      } else {
        await interaction.reply(reply);
      }
    }
    return;
  }

  // ── Select menus ────────────────────────────────────────────────────────
  if (interaction.isStringSelectMenu()) {
    const id  = interaction.customId;
    const log = { value: interaction.values[0], user: interaction.user.tag };

    if (id === "painel_produto") {
      try {
        await handleProductSelect(interaction);
        logger.info(log, "Panel 1 product selected");
      } catch (err) {
        logger.error({ err }, "Error handling panel 1 product select");
        if (!interaction.replied)
          await interaction.reply({
            content: "Ocorreu um erro ao processar sua seleção.",
            ephemeral: true,
          });
      }
      return;
    }

    if (id === "painel2_produto") {
      try {
        await handleProductSelect2(interaction);
        logger.info(log, "Panel 2 product selected");
      } catch (err) {
        logger.error({ err }, "Error handling panel 2 product select");
        if (!interaction.replied)
          await interaction.reply({
            content: "Ocorreu um erro ao processar sua seleção.",
            ephemeral: true,
          });
      }
      return;
    }
  }

  // ── Buttons ─────────────────────────────────────────────────────────────
  if (interaction.isButton()) {
    const id = interaction.customId;

    // Panel 1 — "Confirmar Pedido" → creates key ticket
    if (id.startsWith("painel_confirmar:")) {
      const productId = id.split(":")[1];
      try {
        await createTicket1(interaction, client, productId);
        logger.info({ productId, user: interaction.user.tag }, "Ticket created for panel 1 key order");
      } catch (err) {
        const e = err as { code?: number; message?: string };
        logger.error({ err, productId, user: interaction.user.tag, errorCode: e?.code, errorMessage: e?.message }, "Error creating ticket for panel 1 key order");
        await safeReplyError(interaction, "❌ Ocorreu um erro ao criar o ticket. Tente novamente.");
      }
      return;
    }

    // Panel 1 — Admin panel buttons (t1_fin, t1_cls)
    if (id.startsWith("t1_")) {
      try {
        await handleAdminButton1(interaction, client, refreshPanel);
        logger.info({ customId: id, user: interaction.user.tag }, "Panel 1 admin button clicked");
      } catch (err) {
        const e = err as { code?: number; message?: string };
        logger.error({ err, customId: id, errorCode: e?.code, errorMessage: e?.message }, "Error handling panel 1 admin button");
        await safeReplyError(interaction, "❌ Ocorreu um erro ao processar esta ação.");
      }
      return;
    }

    // Panel 2 — "Confirmar Pedido" → creates ticket
    if (id.startsWith("painel2_confirmar:")) {
      const productId = id.split(":")[1];
      try {
        await createTicket2(interaction, client, productId);
        logger.info({ productId, user: interaction.user.tag }, "Ticket created for panel 2 order");
      } catch (err) {
        const e = err as { code?: number; message?: string };
        logger.error({ err, productId, user: interaction.user.tag, errorCode: e?.code, errorMessage: e?.message }, "Error creating ticket for panel 2 order");
        await safeReplyError(interaction, "❌ Ocorreu um erro ao criar o ticket. Tente novamente.");
      }
      return;
    }

    // Panel 2 — Admin panel buttons (t2_fin, t2_cls)
    if (id.startsWith("t2_")) {
      try {
        await handleAdminButton2(interaction, client, refreshPanel2);
        logger.info({ customId: id, user: interaction.user.tag }, "Panel 2 admin button clicked");
      } catch (err) {
        const e = err as { code?: number; message?: string };
        logger.error({ err, customId: id, errorCode: e?.code, errorMessage: e?.message }, "Error handling panel 2 admin button");
        await safeReplyError(interaction, "❌ Ocorreu um erro ao processar esta ação.");
      }
      return;
    }

    // Support panel — Open ticket
    if (id === "suporte_open") {
      try {
        await openSupportTicket(interaction, client);
        logger.info({ user: interaction.user.tag }, "Support ticket opened");
      } catch (err) {
        const e = err as { code?: number; message?: string };
        logger.error({ err, user: interaction.user.tag, errorCode: e?.code, errorMessage: e?.message }, "Error opening support ticket");
        await safeReplyError(interaction, "❌ Ocorreu um erro ao abrir o ticket. Tente novamente.");
      }
      return;
    }

    // Support panel — Close ticket
    if (id.startsWith("suporte_close:")) {
      try {
        await closeSupportTicket(interaction);
        logger.info(
          { user: interaction.user.tag, channelId: interaction.channelId },
          "Support ticket closed",
        );
      } catch (err) {
        const e = err as { code?: number; message?: string };
        logger.error({ err, channelId: interaction.channelId, errorCode: e?.code, errorMessage: e?.message }, "Error closing support ticket");
        await safeReplyError(interaction, "❌ Ocorreu um erro ao fechar o ticket.");
      }
      return;
    }
  }
});

client.login(DISCORD_TOKEN);
