/**
 * config.ts — Carregamento centralizado de configurações secretas.
 *
 * Ordem de prioridade para cada valor:
 *   1. Arquivo em config/<nome-do-arquivo>  ← prioridade máxima
 *   2. Variável de ambiente (fallback para Replit e outros ambientes)
 *   3. null  ← valor ausente, recurso correspondente desativado
 *
 * Estrutura esperada da pasta config/:
 *
 *   config/
 *   ├── discord.token   ← token do bot (apenas o texto puro)
 *   ├── gemini.key      ← API Key do Gemini (apenas o texto puro)
 *   └── README.md       ← instruções de configuração
 *
 * Como usar (Termux / qualquer servidor):
 *   echo "SEU_TOKEN_AQUI" > config/discord.token
 *   echo "SUA_KEY_AQUI"  > config/gemini.key
 *   # Reinicie o bot — as chaves são lidas na inicialização.
 *
 * Os arquivos de configuração NUNCA devem ser enviados ao GitHub.
 * Eles já estão no .gitignore. Apenas o README.md é versionado.
 */

import { readFileSync, existsSync } from "node:fs";
import path from "node:path";
import { logger } from "./logger.js";

// ── Caminho da pasta de configuração ──────────────────────────────────────
// process.cwd() aponta para o diretório do pacote discord-bot tanto em
// desenvolvimento (pnpm filter) quanto em produção.
const CONFIG_DIR = path.resolve(process.cwd(), "config");

// ── Leitor de arquivo ──────────────────────────────────────────────────────
function readSecret(filename: string): string | null {
  const filepath = path.join(CONFIG_DIR, filename);
  try {
    if (!existsSync(filepath)) return null;
    const value = readFileSync(filepath, "utf-8").trim();
    return value.length > 0 ? value : null;
  } catch {
    return null;
  }
}

// ── Token do Discord ───────────────────────────────────────────────────────
// Fonte 1: config/discord.token
// Fonte 2: variável de ambiente DISCORD_TOKEN (Replit Secrets)
export const DISCORD_TOKEN: string | null =
  readSecret("discord.token") ?? process.env.DISCORD_TOKEN ?? null;

if (DISCORD_TOKEN) {
  logger.info(
    { source: existsSync(path.join(CONFIG_DIR, "discord.token")) ? "arquivo" : "env" },
    "config: Discord token carregado",
  );
} else {
  logger.error(
    "config: ❌ Discord token não encontrado — " +
    "crie o arquivo config/discord.token ou defina a variável DISCORD_TOKEN",
  );
}

// ── API Key do Gemini ──────────────────────────────────────────────────────
// Fonte 1: config/gemini.key
// Fonte 2: variável de ambiente GEMINI_API_KEY (Replit Secrets)
export const GEMINI_API_KEY: string | null =
  readSecret("gemini.key") ?? process.env.GEMINI_API_KEY ?? null;

if (GEMINI_API_KEY) {
  logger.info(
    { source: existsSync(path.join(CONFIG_DIR, "gemini.key")) ? "arquivo" : "env" },
    "config: Gemini API Key carregada — use /ia ativar para ligar a IA",
  );
} else {
  logger.info(
    "config: Gemini API Key ausente — IA desativada " +
    "(adicione config/gemini.key para ativar futuramente)",
  );
}
