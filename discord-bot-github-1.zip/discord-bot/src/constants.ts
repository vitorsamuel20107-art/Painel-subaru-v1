export const PANEL_CHANNEL_ID  = "1521648793756369016";
export const PANEL2_CHANNEL_ID = "1522055769124634726";

export const FOUNDER_ROLE_NAME = "Fundador";

export const FOUNDER_ROLE_ID = "1490895038576726217";
export const ADMIN_ROLE_ID   = "1490895487463587890";
export const SUPPORT_ROLE_ID = "1522399407365165177";

/** Category where support tickets are created — "🛠️ Atendimento". */
export const SUPPORT_TICKET_CATEGORY_ID = "1522327667402346658";

/** Channel where moderation punishments are logged. */
export const MOD_LOG_CHANNEL_ID = "1525945483967598652";
