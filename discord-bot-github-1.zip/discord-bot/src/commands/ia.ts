import { SlashCommandBuilder, EmbedBuilder } from "discord.js";
import type { ChatInputCommandInteraction, GuildMember } from "discord.js";
import type { Command } from "../types.js";
import { FOUNDER_ROLE_ID, ADMIN_ROLE_ID } from "../constants.js";
import { isReady, isEnabled, setEnabled } from "../ai.js";

const command: Command = {
  data: new SlashCommandBuilder()
    .setName("ia")
    .setDescription("Controla o sistema de IA do bot")
    .addSubcommand((sub) =>
      sub
        .setName("ativar")
        .setDescription("Ativa as respostas da IA (requer API Key configurada no ambiente)")
    )
    .addSubcommand((sub) =>
      sub
        .setName("desativar")
        .setDescription("Desativa as respostas da IA (a key permanece configurada)")
    ),

  async execute(interaction: ChatInputCommandInteraction) {
    // ── Verificação de permissão — apenas Fundador ou Admin ───────────────
    const member    = interaction.member as GuildMember;
    const hasAccess = [FOUNDER_ROLE_ID, ADMIN_ROLE_ID].some(
      (id) => member?.roles?.cache?.has(id),
    );

    if (!hasAccess) {
      await interaction.reply({
        content: "❌ Apenas **Fundador** ou **Administradores** podem controlar a IA.",
        ephemeral: true,
      });
      return;
    }

    const sub = interaction.options.getSubcommand();

    // ── /ia ativar ────────────────────────────────────────────────────────
    if (sub === "ativar") {
      if (!isReady()) {
        await interaction.reply({
          embeds: [
            new EmbedBuilder()
              .setColor(0xFFC300)
              .setTitle("⚠️ API Key não configurada")
              .setDescription(
                "A IA não pode ser ativada porque a `GEMINI_API_KEY` não está presente no ambiente.\n\n" +
                "Configure a chave no Termux e reinicie o bot para liberar este comando.",
              )
              .setTimestamp(),
          ],
          ephemeral: true,
        });
        return;
      }

      if (isEnabled()) {
        await interaction.reply({
          content: "ℹ️ A IA já está **ativada**.",
          ephemeral: true,
        });
        return;
      }

      setEnabled(true);

      await interaction.reply({
        embeds: [
          new EmbedBuilder()
            .setColor(0x00C853)
            .setTitle("🤖 IA Ativada")
            .setDescription(
              "O sistema de IA foi **ativado** com sucesso.\n" +
              "A IA responderá normalmente nos canais configurados.",
            )
            .setFooter({ text: "Use /ia desativar para pausar as respostas." })
            .setTimestamp(),
        ],
        ephemeral: true,
      });
      return;
    }

    // ── /ia desativar ─────────────────────────────────────────────────────
    if (sub === "desativar") {
      if (!isEnabled()) {
        await interaction.reply({
          content: "ℹ️ A IA já está **desativada**.",
          ephemeral: true,
        });
        return;
      }

      setEnabled(false);

      await interaction.reply({
        embeds: [
          new EmbedBuilder()
            .setColor(0xFF6B00)
            .setTitle("🔇 IA Desativada")
            .setDescription(
              "O sistema de IA foi **desativado**.\n" +
              "A IA não responderá em nenhum canal até ser reativada.",
            )
            .setFooter({ text: "Use /ia ativar para religar as respostas." })
            .setTimestamp(),
        ],
        ephemeral: true,
      });
      return;
    }
  },
};

export default command;
