/**
 * ai.ts — Módulo isolado de integração com o Gemini AI.
 *
 * Este módulo é intencionalmente passivo enquanto a API não estiver pronta.
 * O bot funciona normalmente sem ele.
 *
 * Para ativar no futuro (Termux):
 *   1. Adicione GEMINI_API_KEY ao ambiente (export GEMINI_API_KEY=sua_chave)
 *   2. Execute: pnpm add @google/generative-ai
 *   3. Descomente o bloco dentro de ask()
 *   4. Reinicie o bot — a IA estará pronta para uso
 *
 * Controle em tempo real via Discord:
 *   /ia ativar   — liga as respostas (requer API Key no ambiente)
 *   /ia desativar — desliga as respostas (a key permanece no ambiente)
 *
 * O estado (ativada/desativada) é salvo em data/ai-state.json
 * e sobrevive reinicializações do bot.
 */

import { readFileSync, writeFileSync, existsSync, mkdirSync } from "node:fs";
import path from "node:path";
import { logger } from "./logger.js";
import { GEMINI_API_KEY } from "./config.js";

// ── Caminhos ───────────────────────────────────────────────────────────────
// Usa o mesmo padrão de store/keys.ts: cwd() aponta para o diretório do bot.
const DATA_DIR   = process.env.DATA_DIR
  ? path.resolve(process.env.DATA_DIR)
  : path.resolve(process.cwd(), "data");
const STATE_FILE = path.join(DATA_DIR, "ai-state.json");

// ── Estado persistente ─────────────────────────────────────────────────────
interface AiState {
  enabled: boolean;
}

function loadState(): AiState {
  try {
    if (!existsSync(STATE_FILE)) return { enabled: false };
    const raw = readFileSync(STATE_FILE, "utf-8");
    return JSON.parse(raw) as AiState;
  } catch {
    return { enabled: false };
  }
}

function persistState(state: AiState): void {
  try {
    if (!existsSync(DATA_DIR)) mkdirSync(DATA_DIR, { recursive: true });
    writeFileSync(STATE_FILE, JSON.stringify(state, null, 2), "utf-8");
  } catch (err) {
    logger.warn({ err }, "ai: falha ao salvar estado em disco");
  }
}

// Carrega o estado ao iniciar o módulo
let _state: AiState = loadState();

logger.info(
  { ready: Boolean(GEMINI_API_KEY), enabled: _state.enabled },
  "ai: módulo carregado",
);

// ── API pública ────────────────────────────────────────────────────────────

/**
 * Retorna true se GEMINI_API_KEY está presente no ambiente.
 * Não faz nenhuma chamada de rede.
 */
export function isReady(): boolean {
  return Boolean(process.env.GEMINI_API_KEY);
}

/** Retorna o estado atual do toggle (ativada/desativada). */
export function isEnabled(): boolean {
  return _state.enabled;
}

/**
 * Ativa ou desativa a IA.
 * O novo estado é salvo imediatamente em disco e sobrevive a reinicializações.
 */
export function setEnabled(value: boolean): void {
  _state = { enabled: value };
  persistState(_state);
  logger.info({ enabled: value }, "ai: estado atualizado");
}

/**
 * Envia um prompt ao Gemini e retorna o texto de resposta.
 * Retorna null se a chave não estiver configurada, a IA estiver desativada
 * ou ocorrer qualquer erro — nunca lança exceção.
 *
 * ══════════════════════════════════════════════════════════════════════════
 *  PARA ATIVAR: siga os 4 passos no topo deste arquivo e descomente abaixo.
 * ══════════════════════════════════════════════════════════════════════════
 */
export async function ask(prompt: string): Promise<string | null> {
  if (!isReady() || !isEnabled()) return null;

  // ── Descomente este bloco quando a API Key estiver configurada ──────────
  // try {
  //   const { GoogleGenerativeAI } = await import("@google/generative-ai");
  //   const genAI = new GoogleGenerativeAI(GEMINI_API_KEY!);
  //   const model = genAI.getGenerativeModel({ model: "gemini-1.5-flash" });
  //   const result = await model.generateContent(prompt);
  //   return result.response.text();
  // } catch (err) {
  //   logger.error({ err }, "ai: erro na chamada ao Gemini");
  //   return null;
  // }
  // ───────────────────────────────────────────────────────────────────────

  logger.info({ promptLength: prompt.length }, "ai: ask() chamado — integração ainda não ativada");
  return null;
}
