/**
 * ticket-timers.ts — Centralized inactivity timer management.
 *
 * When a ticket is created a 2-minute countdown starts.
 * The FIRST message sent by the ticket owner cancels it permanently.
 * If it fires, the channel is deleted and the user receives a DM.
 */

import { EmbedBuilder } from "discord.js";
import type { Client } from "discord.js";
import { logger } from "./logger.js";

const INACTIVITY_MS = 2 * 60 * 1000; // 2 minutes

interface TimerEntry {
  userId: string;
  timeoutRef: ReturnType<typeof setTimeout>;
}

/** channelId → timer entry */
export const inactivityTimers = new Map<string, TimerEntry>();

/**
 * Start (or restart) the inactivity timer for a ticket channel.
 * If no message is sent by the ticket owner within 2 minutes,
 * the channel is deleted and the user is notified via DM.
 */
export function startInactivityTimer(
  channelId: string,
  userId: string,
  client: Client,
): void {
  clearInactivityTimer(channelId);

  const timeoutRef = setTimeout(async () => {
    inactivityTimers.delete(channelId);

    const now = new Date();

    // DM the user
    try {
      const user = await client.users.fetch(userId);
      await user.send({
        embeds: [
          new EmbedBuilder()
            .setTitle("⏰ Ticket Fechado por Inatividade")
            .setColor(0xe74c3c)
            .setDescription("Seu ticket foi encerrado automaticamente por falta de resposta.")
            .addFields(
              {
                name: "📋 Motivo",
                value:
                  "Nenhuma mensagem foi enviada durante os primeiros 2 minutos após a abertura do ticket.",
                inline: false,
              },
              {
                name: "🕐 Data e hora",
                value: `<t:${Math.floor(now.getTime() / 1000)}:f>`,
                inline: false,
              },
            )
            .setFooter({ text: "Caso ainda precise de ajuda, basta abrir um novo ticket." })
            .setTimestamp(now),
        ],
      });
    } catch (err) {
      logger.warn({ err, userId }, "Could not DM user on inactivity close");
    }

    // Delete the channel
    try {
      const channel = await client.channels.fetch(channelId).catch(() => null);
      if (channel && !channel.isDMBased() && "delete" in channel) {
        await (channel as { delete(reason?: string): Promise<unknown> }).delete(
          "Ticket encerrado por inatividade — sem mensagem nos primeiros 2 minutos",
        );
        logger.info({ channelId, userId }, "Ticket auto-closed due to inactivity");
      }
    } catch (err) {
      logger.warn(
        { err, channelId },
        "Could not delete channel on inactivity close (may have been deleted already)",
      );
    }
  }, INACTIVITY_MS);

  inactivityTimers.set(channelId, { userId, timeoutRef });
}

/**
 * Cancel an active inactivity timer (called when the user sends their first
 * message, or when the ticket is manually closed/finalized).
 */
export function clearInactivityTimer(channelId: string): void {
  const entry = inactivityTimers.get(channelId);
  if (entry) {
    clearTimeout(entry.timeoutRef);
    inactivityTimers.delete(channelId);
  }
}
