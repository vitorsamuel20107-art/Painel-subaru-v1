/**
 * tickets2.ts — Ticket system for painel2 (custom services).
 *
 * Duplicate check: live scan of guild channels named "pedido-*" with a
 * permission overwrite for the user. No in-memory Sets or Maps.
 */

import {
  ChannelType,
  OverwriteType,
  PermissionFlagsBits,
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
} from "discord.js";
import type {
  ButtonInteraction,
  Client,
  Guild,
  GuildMember,
  TextChannel,
  MessageActionRowComponentBuilder,
} from "discord.js";
import { products2 } from "./commands/painel2.js";
import { decrementStock } from "./store/keys.js";
import { FOUNDER_ROLE_ID, ADMIN_ROLE_ID, SUPPORT_ROLE_ID } from "./constants.js";
import { logger } from "./logger.js";
import { startInactivityTimer, clearInactivityTimer } from "./ticket-timers.js";

/** Prevents double-finalization within the same bot session. */
const finalizedTickets2 = new Set<string>();

/**
 * Live check — scans the guild channel cache for any "pedido-*" text channel
 * that has a Member permission overwrite for this user.
 * Returns the channel if found, null otherwise.
 */
function findOpenOrderTicket(guild: Guild, userId: string): TextChannel | null {
  const ch = guild.channels.cache.find(
    c =>
      c.type === ChannelType.GuildText &&
      c.name.startsWith("pedido-") &&
      (c as TextChannel).permissionOverwrites.cache.some(
        ow => ow.type === OverwriteType.Member && ow.id === userId,
      ),
  );
  return (ch as TextChannel) ?? null;
}

// ─── Per-product DM messages ──────────────────────────────────────────────
function buildFinalizationDM(productId: string): EmbedBuilder {
  const messages: Record<string, string> = {
    proj_menu_ui: [
      "Obrigado por escolher nossos serviços.",
      "",
      "📩 Confira esta conversa. Quando seu menu personalizado estiver concluído, ele será enviado por aqui.",
      "",
      "📧 Junto com o projeto, você também receberá:",
      "• E-mail da conta onde o projeto está hospedado.",
      "• Senha da conta.",
      "• Instruções de acesso.",
      "",
      "⚠️ Não compartilhe essas informações com ninguém.",
      "",
      "Agradecemos pela preferência! ❤️",
    ].join("\n"),

    proj_funcao: [
      "Obrigado por escolher nossos serviços.",
      "",
      "📩 Confira esta conversa. Quando sua função exclusiva estiver concluída, ela será enviada por aqui.",
      "",
      "📧 Junto com a entrega, você também receberá:",
      "• E-mail da conta onde o projeto está hospedado.",
      "• Senha da conta.",
      "• Instruções de acesso.",
      "",
      "⚠️ Não compartilhe essas informações com ninguém.",
      "",
      "Agradecemos pela preferência! ❤️",
    ].join("\n"),

    proj_menu_funcoes: [
      "Obrigado por escolher nossos serviços.",
      "",
      "📩 Confira esta conversa. Quando seu pacote de funções estiver concluído, ele será enviado por aqui.",
      "",
      "📧 Junto com a entrega, você também receberá:",
      "• E-mail da conta onde o projeto está hospedado.",
      "• Senha da conta.",
      "• Instruções de acesso.",
      "",
      "⚠️ Não compartilhe essas informações com ninguém.",
      "",
      "Agradecemos pela preferência! ❤️",
    ].join("\n"),

    proj_completo: [
      "Obrigado por escolher nossos serviços.",
      "",
      "📩 Confira esta conversa. Quando seu projeto completo estiver concluído, ele será enviado por aqui.",
      "",
      "📧 Junto com a entrega, você também receberá:",
      "• E-mail da conta onde o projeto está hospedado.",
      "• Senha da conta.",
      "• Instruções de acesso.",
      "",
      "⚠️ Não compartilhe essas informações com ninguém.",
      "",
      "Agradecemos pela preferência! ❤️",
    ].join("\n"),

    proj_keys: [
      "Obrigado por escolher nossos serviços.",
      "",
      "📩 Confira esta conversa. Quando seu sistema de Keys estiver concluído, ele será enviado por aqui.",
      "",
      "📧 Você também receberá:",
      "• E-mail da conta onde o sistema está hospedado.",
      "• Senha da conta.",
      "• Informações de acesso ao painel.",
      "",
      "⚠️ Não compartilhe essas informações com ninguém.",
      "",
      "Agradecemos pela preferência! ❤️",
    ].join("\n"),
  };

  const description = messages[productId] ?? [
    "Obrigado por escolher nossos serviços.",
    "",
    "📩 Confira esta conversa. Quando seu projeto estiver concluído, ele será enviado por aqui.",
    "",
    "Agradecemos pela preferência! ❤️",
  ].join("\n");

  return new EmbedBuilder()
    .setTitle("🎉 Pedido Confirmado!")
    .setColor(0x00c853)
    .setDescription(description)
    .setTimestamp();
}

function buildAdminPanel(
  channelId: string,
  userId: string,
  productId: string,
): ActionRowBuilder<MessageActionRowComponentBuilder>[] {
  return [
    new ActionRowBuilder<MessageActionRowComponentBuilder>().addComponents(
      new ButtonBuilder()
        .setCustomId(`t2_fin:${channelId}:${userId}:${productId}`)
        .setLabel("✅ Finalizar Pedido")
        .setStyle(ButtonStyle.Success),
      new ButtonBuilder()
        .setCustomId(`t2_cls:${channelId}`)
        .setLabel("🔒 Fechar Ticket")
        .setStyle(ButtonStyle.Secondary),
    ),
  ];
}

function buildFinalizedPanel(): ActionRowBuilder<MessageActionRowComponentBuilder>[] {
  return [
    new ActionRowBuilder<MessageActionRowComponentBuilder>().addComponents(
      new ButtonBuilder()
        .setCustomId("t2_done")
        .setLabel("✅ Pedido Finalizado")
        .setStyle(ButtonStyle.Success)
        .setDisabled(true),
    ),
  ];
}

// ─── Create ticket on order confirmation ─────────────────────────────────
export async function createTicket2(
  interaction: ButtonInteraction,
  client: Client,
  productId: string,
): Promise<void> {
  const product = products2[productId];

  if (!product) {
    await interaction.reply({ content: "❌ Produto não encontrado.", ephemeral: true });
    return;
  }
  if (!interaction.guild) {
    await interaction.reply({
      content: "❌ Este sistema só funciona em servidores.",
      ephemeral: true,
    });
    return;
  }

  const guild  = interaction.guild;
  const userId = interaction.user.id;

  // ── Live duplicate check ─────────────────────────────────────────────────
  const existing = findOpenOrderTicket(guild, userId);
  if (existing) {
    await interaction.reply({
      content: `❌ Você já possui um ticket de pedido aberto: ${existing}. Finalize ou feche o ticket atual antes de abrir outro.`,
      ephemeral: true,
    });
    return;
  }

  // Acknowledge immediately
  await interaction.deferUpdate();

  const safeUser = interaction.user.username
    .toLowerCase()
    .replace(/[^a-z0-9]/g, "")
    .slice(0, 20) || "usuario";

  const categoryId = guild.channels.cache.find(
    c => c.type === ChannelType.GuildCategory && c.name.toLowerCase().includes("ticket"),
  )?.id;

  const clientPerms = [
    PermissionFlagsBits.ViewChannel,
    PermissionFlagsBits.SendMessages,
    PermissionFlagsBits.ReadMessageHistory,
    PermissionFlagsBits.AttachFiles,
    PermissionFlagsBits.EmbedLinks,
  ];
  const staffPerms = [
    PermissionFlagsBits.ViewChannel,
    PermissionFlagsBits.SendMessages,
    PermissionFlagsBits.ReadMessageHistory,
    PermissionFlagsBits.ManageChannels,
    PermissionFlagsBits.ManageMessages,
    PermissionFlagsBits.AttachFiles,
    PermissionFlagsBits.EmbedLinks,
  ];

  const ticketChannel = (await guild.channels.create({
    name: `pedido-${safeUser}`,
    type: ChannelType.GuildText,
    parent: categoryId,
    permissionOverwrites: [
      { id: guild.id,         deny:  [PermissionFlagsBits.ViewChannel] },
      { id: userId,           allow: clientPerms },
      { id: client.user!.id, allow: staffPerms  },
      { id: FOUNDER_ROLE_ID, allow: staffPerms  },
      { id: ADMIN_ROLE_ID,   allow: staffPerms  },
      { id: SUPPORT_ROLE_ID, allow: staffPerms  },
    ],
  })) as TextChannel;

  // 1. Welcome embed
  await ticketChannel.send({
    content: `<@${userId}>`,
    embeds: [
      new EmbedBuilder()
        .setTitle("👋 Bem-vindo ao suporte!")
        .setColor(0x8b00ff)
        .setDescription(
          [
            "Explique sua dúvida ou problema de forma clara e vá direto ao assunto.",
            "",
            "⚠️ **Evite abrir um ticket e não enviar nenhuma mensagem**, pois tickets sem resposta serão encerrados automaticamente após **2 minutos**.",
          ].join("\n"),
        )
        .setTimestamp(),
    ],
  });

  // 2. Order summary + team notification
  await ticketChannel.send({
    content: `<@&${FOUNDER_ROLE_ID}>`,
    embeds: [
      new EmbedBuilder()
        .setTitle("🎉 Seu pedido foi registrado com sucesso!")
        .setColor(0x00c853)
        .addFields(
          { name: "📦 Produto", value: `**${product.label}**`, inline: true },
          { name: "💰 Valor",   value: `**${product.price}**`, inline: true },
          { name: "👤 Cliente", value: `<@${userId}>`,         inline: true },
        )
        .setDescription("⏳ Aguarde um membro da equipe.")
        .setTimestamp(),
    ],
  });

  // 3. Client instructions
  await ticketChannel.send({
    embeds: [
      new EmbedBuilder()
        .setTitle("📝 Informações do Projeto")
        .setColor(0x8b00ff)
        .setDescription(
          [
            "Por favor, nos forneça as seguintes informações:",
            "",
            "📝 **Explique detalhadamente como deseja o projeto.**",
            "",
            "🖼️ **Envie imagens de referência** *(opcional)*.",
            "",
            "📋 **Informe qualquer observação importante.**",
          ].join("\n"),
        )
        .setFooter({ text: "Nossa equipe analisará e entrará em contato em breve." }),
    ],
  });

  // 4. Admin panel
  await ticketChannel.send({
    embeds: [
      new EmbedBuilder()
        .setTitle("🔧 Painel Administrativo")
        .setColor(0xff6d00)
        .setDescription(
          "**Exclusivo para a equipe.** Use os botões abaixo para gerenciar este pedido.",
        )
        .setFooter({ text: "Apenas administradores podem interagir com estes botões." }),
    ],
    components: buildAdminPanel(ticketChannel.id, userId, productId),
  });

  // 5. Inactivity timer — cancelled on the user's first message
  startInactivityTimer(ticketChannel.id, userId, client);

  logger.info(
    { ticketChannelId: ticketChannel.id, userId, productId },
    "Ticket created for panel 2 order",
  );
}

// ─── Handle admin panel buttons ───────────────────────────────────────────
export async function handleAdminButton2(
  interaction: ButtonInteraction,
  client: Client,
  refreshPanel: (client: Client) => Promise<void>,
): Promise<void> {
  const member = interaction.member as GuildMember;
  const [action, channelId, userId, productId] = interaction.customId.split(":");
  const product = productId ? products2[productId] : null;

  // ── ✅ Finalizar Pedido ─────────────────────────────────────────────────
  if (action === "t2_fin") {
    // Only Founder can finalize orders
    if (!member.roles.cache.has(FOUNDER_ROLE_ID)) {
      await interaction.reply({
        content: "❌ Apenas membros com o cargo **Fundador** podem finalizar pedidos.",
        ephemeral: true,
      });
      return;
    }

    if (finalizedTickets2.has(channelId)) {
      await interaction.reply({
        content: "⚠️ Este pedido já foi finalizado.",
        ephemeral: true,
      });
      return;
    }

    await interaction.deferReply();
    finalizedTickets2.add(channelId);
    clearInactivityTimer(channelId);

    try {
      await interaction.message.edit({ components: buildFinalizedPanel() });
    } catch {}

    await decrementStock(productId);

    try {
      const user = await client.users.fetch(userId);
      await user.send({ embeds: [buildFinalizationDM(productId)] });
      logger.info({ userId, productId }, "DM sent to client on order finalization");
    } catch (err) {
      logger.warn({ err, userId }, "Could not DM client — DMs may be disabled");
    }

    await interaction.editReply({
      embeds: [
        new EmbedBuilder()
          .setColor(0x00c853)
          .setTitle("✅ Pedido Finalizado")
          .setDescription(
            `O pedido de **${product?.label ?? productId}** foi finalizado por <@${interaction.user.id}>.\n\nEstoque atualizado. <@${userId}> foi notificado via DM.\n\n🔒 Ticket será fechado em 5 segundos.`,
          )
          .setTimestamp(),
      ],
    });

    await refreshPanel(client);
    logger.info(
      { productId, channelId, adminId: interaction.user.id },
      "Panel 2 order finalized",
    );

    setTimeout(async () => {
      try {
        if (interaction.channel && !interaction.channel.isDMBased()) {
          await interaction.channel.delete(
            "Pedido finalizado — ticket encerrado automaticamente",
          );
          finalizedTickets2.delete(channelId);
        }
      } catch (err) {
        logger.error({ err }, "Failed to auto-close ticket channel after finalization");
      }
    }, 5000);
    return;
  }

  // ── 🔒 Fechar Ticket ────────────────────────────────────────────────────
  if (action === "t2_cls") {
    if (![FOUNDER_ROLE_ID, ADMIN_ROLE_ID, SUPPORT_ROLE_ID].some(id => member.roles.cache.has(id))) {
      await interaction.reply({
        content: "❌ Você não tem permissão para usar este botão.",
        ephemeral: true,
      });
      return;
    }
    clearInactivityTimer(channelId);
    await interaction.reply({
      content: "🔒 Fechando ticket em 5 segundos...",
      ephemeral: true,
    });
    setTimeout(async () => {
      try {
        if (interaction.channel && !interaction.channel.isDMBased()) {
          await interaction.channel.delete("Ticket fechado pela equipe");
        }
      } catch (err) {
        logger.error({ err }, "Failed to delete ticket channel");
      }
    }, 5000);
    return;
  }
}
