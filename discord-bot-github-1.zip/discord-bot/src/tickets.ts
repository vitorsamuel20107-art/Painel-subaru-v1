/**
 * tickets.ts — Ticket system for painel1 (FFH4X key purchases).
 *
 * Duplicate check: live scan of guild channels named "key-*" with a
 * permission overwrite for the user. No in-memory Sets or Maps.
 */

import {
  ChannelType,
  OverwriteType,
  PermissionFlagsBits,
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
} from "discord.js";
import type {
  ButtonInteraction,
  Client,
  Guild,
  GuildMember,
  TextChannel,
  MessageActionRowComponentBuilder,
} from "discord.js";
import { products } from "./commands/painel.js";
import { popKey } from "./store/keys.js";
import { FOUNDER_ROLE_ID, ADMIN_ROLE_ID, SUPPORT_ROLE_ID } from "./constants.js";
import { logger } from "./logger.js";
import { startInactivityTimer, clearInactivityTimer } from "./ticket-timers.js";

/** Prevents double-finalization within the same bot session. */
const finalizedTickets1 = new Set<string>();

function hasPermission(member: GuildMember | null): boolean {
  if (!member) return false;
  return [FOUNDER_ROLE_ID, ADMIN_ROLE_ID, SUPPORT_ROLE_ID].some(id =>
    member.roles.cache.has(id),
  );
}

/**
 * Live check — scans the guild channel cache for any "key-*" text channel
 * that has a Member permission overwrite for this user.
 * Returns the channel if found, null otherwise.
 */
function findOpenKeyTicket(guild: Guild, userId: string): TextChannel | null {
  const ch = guild.channels.cache.find(
    c =>
      c.type === ChannelType.GuildText &&
      c.name.startsWith("key-") &&
      (c as TextChannel).permissionOverwrites.cache.some(
        ow => ow.type === OverwriteType.Member && ow.id === userId,
      ),
  );
  return (ch as TextChannel) ?? null;
}

function buildAdminPanel1(channelId: string, userId: string, productId: string) {
  return [
    new ActionRowBuilder<MessageActionRowComponentBuilder>().addComponents(
      new ButtonBuilder()
        .setCustomId(`t1_fin:${channelId}:${userId}:${productId}`)
        .setLabel("✅ Finalizar Pedido")
        .setStyle(ButtonStyle.Success),
      new ButtonBuilder()
        .setCustomId(`t1_cls:${channelId}`)
        .setLabel("🔒 Fechar Ticket")
        .setStyle(ButtonStyle.Secondary),
    ),
  ];
}

function buildFinalizedPanel1() {
  return [
    new ActionRowBuilder<MessageActionRowComponentBuilder>().addComponents(
      new ButtonBuilder()
        .setCustomId("t1_done")
        .setLabel("✅ Pedido Finalizado")
        .setStyle(ButtonStyle.Success)
        .setDisabled(true),
    ),
  ];
}

// ── Create ticket on key order confirmation ───────────────────────────────
export async function createTicket1(
  interaction: ButtonInteraction,
  client: Client,
  productId: string,
): Promise<void> {
  const product = products[productId];

  if (!product) {
    await interaction.reply({ content: "❌ Produto não encontrado.", ephemeral: true });
    return;
  }
  if (!interaction.guild) {
    await interaction.reply({
      content: "❌ Este sistema só funciona em servidores.",
      ephemeral: true,
    });
    return;
  }

  const guild  = interaction.guild;
  const userId = interaction.user.id;

  // ── Live duplicate check ─────────────────────────────────────────────────
  const existing = findOpenKeyTicket(guild, userId);
  if (existing) {
    await interaction.reply({
      content: `❌ Você já possui um ticket de key aberto: ${existing}. Finalize ou feche o ticket atual antes de abrir outro.`,
      ephemeral: true,
    });
    return;
  }

  // Acknowledge immediately — gives a 15-min window for channel creation
  await interaction.deferUpdate();

  const safeUser = interaction.user.username
    .toLowerCase()
    .replace(/[^a-z0-9]/g, "")
    .slice(0, 20) || "usuario";

  const clientPerms = [
    PermissionFlagsBits.ViewChannel,
    PermissionFlagsBits.SendMessages,
    PermissionFlagsBits.ReadMessageHistory,
    PermissionFlagsBits.AttachFiles,
    PermissionFlagsBits.EmbedLinks,
  ];
  const staffPerms = [
    PermissionFlagsBits.ViewChannel,
    PermissionFlagsBits.SendMessages,
    PermissionFlagsBits.ReadMessageHistory,
    PermissionFlagsBits.ManageChannels,
    PermissionFlagsBits.ManageMessages,
    PermissionFlagsBits.AttachFiles,
    PermissionFlagsBits.EmbedLinks,
  ];

  const categoryId = guild.channels.cache.find(
    c => c.type === ChannelType.GuildCategory && c.name.toLowerCase().includes("ticket"),
  )?.id;

  const ticketChannel = (await guild.channels.create({
    name: `key-${safeUser}`,
    type: ChannelType.GuildText,
    parent: categoryId,
    permissionOverwrites: [
      { id: guild.id,         deny:  [PermissionFlagsBits.ViewChannel] },
      { id: userId,           allow: clientPerms },
      { id: client.user!.id, allow: staffPerms  },
      { id: FOUNDER_ROLE_ID, allow: staffPerms  },
      { id: ADMIN_ROLE_ID,   allow: staffPerms  },
      { id: SUPPORT_ROLE_ID, allow: staffPerms  },
    ],
  })) as TextChannel;

  // 1. Welcome embed
  await ticketChannel.send({
    content: `<@${userId}>`,
    embeds: [
      new EmbedBuilder()
        .setTitle("👋 Bem-vindo ao suporte!")
        .setColor(0x8b00ff)
        .setDescription(
          [
            "Explique sua dúvida ou problema de forma clara e vá direto ao assunto.",
            "",
            "⚠️ **Evite abrir um ticket e não enviar nenhuma mensagem**, pois tickets sem resposta serão encerrados automaticamente após **2 minutos**.",
          ].join("\n"),
        )
        .setTimestamp(),
    ],
  });

  // 2. Order notification for the team
  await ticketChannel.send({
    content: `<@&${FOUNDER_ROLE_ID}>`,
    embeds: [
      new EmbedBuilder()
        .setTitle("🎉 Pedido de Key Registrado!")
        .setColor(0x00c853)
        .addFields(
          { name: "📦 Produto", value: `**${product.label}**`, inline: true },
          { name: "💰 Valor",   value: `**${product.price}**`, inline: true },
          { name: "👤 Cliente", value: `<@${userId}>`,         inline: true },
        )
        .setDescription("⏳ Aguarde um membro da equipe para enviar sua key.")
        .setTimestamp(),
    ],
  });

  // 3. Admin panel
  await ticketChannel.send({
    embeds: [
      new EmbedBuilder()
        .setTitle("📋 Painel Administrativo")
        .setColor(0x8b00ff)
        .setDescription("Use os botões abaixo para gerenciar este pedido.")
        .setTimestamp(),
    ],
    components: buildAdminPanel1(ticketChannel.id, userId, productId),
  });

  // 4. Inactivity timer — cancelled on the user's first message
  startInactivityTimer(ticketChannel.id, userId, client);

  logger.info({ userId, channelId: ticketChannel.id, productId }, "Key ticket created");
}

// ── Handle admin buttons ──────────────────────────────────────────────────
export async function handleAdminButton1(
  interaction: ButtonInteraction,
  client: Client,
  refreshPanel: (client: Client) => Promise<void>,
): Promise<void> {
  const member = interaction.member as GuildMember;

  const [action, channelId, userId, productId] = interaction.customId.split(":");

  // ── ✅ Finalizar Pedido ───────────────────────────────────────────────
  if (action === "t1_fin") {
    // Only Founder can finalize orders
    if (!member.roles.cache.has(FOUNDER_ROLE_ID)) {
      await interaction.reply({
        content: "❌ Apenas membros com o cargo **Fundador** podem finalizar pedidos.",
        ephemeral: true,
      });
      return;
    }

    if (finalizedTickets1.has(channelId)) {
      await interaction.reply({ content: "⚠️ Este pedido já foi finalizado.", ephemeral: true });
      return;
    }

    await interaction.deferReply();
    finalizedTickets1.add(channelId);
    clearInactivityTimer(channelId);

    try {
      await interaction.message.edit({ components: buildFinalizedPanel1() });
    } catch {}

    const product = products[productId];
    const key     = await popKey(productId);

    try {
      const user = await client.users.fetch(userId);
      if (key) {
        await user.send({
          embeds: [
            new EmbedBuilder()
              .setTitle("🎉 Compra Aprovada")
              .setColor(0x8b00ff)
              .setDescription(
                [
                  "Obrigado pela sua compra!",
                  "",
                  "🔑 **Sua licença:**",
                  `\`\`\`${key}\`\`\``,
                  "🔑 **Sua Key só funcionará neste Script.**",
                  "```lua",
                  `loadstring(game:HttpGet("https://raw.githubusercontent.com/vitorsamuel20107-art/Night/refs/heads/main/G"))()`,
                  "```",
                ].join("\n"),
              )
              .setFooter({ text: "Night Cheats • Guarde sua key em local seguro. Ela é de uso único." })
              .setTimestamp(),
          ],
        });
        logger.info({ userId, productId }, "Key DM sent on ticket finalization");
      } else {
        logger.warn({ productId }, "No key available — stock may be empty");
      }
    } catch (err) {
      logger.warn({ err, userId }, "Could not DM client — DMs may be disabled");
    }

    await interaction.editReply({
      embeds: [
        new EmbedBuilder()
          .setColor(0x00c853)
          .setTitle("✅ Pedido Finalizado")
          .setDescription(
            `A key de **${product?.label ?? productId}** foi enviada por <@${interaction.user.id}>.\n<@${userId}> foi notificado via DM.\n\n🔒 Ticket será fechado em 5 segundos.`,
          )
          .setTimestamp(),
      ],
    });

    await refreshPanel(client);
    logger.info({ productId, channelId, adminId: interaction.user.id }, "Key ticket finalized");

    setTimeout(async () => {
      try {
        if (interaction.channel && !interaction.channel.isDMBased()) {
          await interaction.channel.delete("Pedido finalizado — ticket encerrado automaticamente");
          finalizedTickets1.delete(channelId);
        }
      } catch (err) {
        logger.error({ err }, "Failed to auto-close key ticket channel");
      }
    }, 5000);
    return;
  }

  // ── 🔒 Fechar Ticket ─────────────────────────────────────────────────
  if (action === "t1_cls") {
    if (!hasPermission(member)) {
      await interaction.reply({
        content: "❌ Você não tem permissão para usar este botão.",
        ephemeral: true,
      });
      return;
    }
    clearInactivityTimer(channelId);
    await interaction.reply({ content: "🔒 Fechando ticket em 5 segundos...", ephemeral: true });
    setTimeout(async () => {
      try {
        if (interaction.channel && !interaction.channel.isDMBased()) {
          await interaction.channel.delete("Ticket fechado pela equipe");
        }
      } catch (err) {
        logger.error({ err }, "Failed to delete key ticket channel");
      }
    }, 5000);
    return;
  }
}
