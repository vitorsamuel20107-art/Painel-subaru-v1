# Configuração do Bot — FFH4X Store

Esta pasta contém as chaves e tokens necessários para o bot funcionar.
**Os arquivos de configuração nunca são enviados ao GitHub** — apenas este README é versionado.

---

## Configuração rápida

Crie os arquivos abaixo com o conteúdo indicado (apenas o valor, sem aspas):

### Token do Discord (obrigatório)

```bash
echo "SEU_TOKEN_AQUI" > discord.token
```

Onde encontrar: [Discord Developer Portal](https://discord.com/developers/applications) → seu app → **Bot** → **Token**

---

### API Key do Gemini (opcional — para a IA)

```bash
echo "SUA_KEY_AQUI" > gemini.key
```

Onde encontrar: [Google AI Studio](https://aistudio.google.com/app/apikey)

Após adicionar a key, reinicie o bot e use `/ia ativar` no Discord.

---

## Estrutura desta pasta

```
config/
├── discord.token   ← token do bot (você cria — nunca vai ao GitHub)
├── gemini.key      ← API Key do Gemini (você cria — nunca vai ao GitHub)
└── README.md       ← este arquivo (versionado no GitHub)
```

## Observações

- O bot lê os arquivos **uma vez na inicialização**. Após editar qualquer arquivo, **reinicie o bot**.
- Se `discord.token` não existir, o bot não iniciará.
- Se `gemini.key` não existir, a IA permanece desativada — o restante do bot funciona normalmente.
- Caso prefira variáveis de ambiente (ex: Replit Secrets), elas também funcionam como fallback:
  - `DISCORD_TOKEN`
  - `GEMINI_API_KEY`
