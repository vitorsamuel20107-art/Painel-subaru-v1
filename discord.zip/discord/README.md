# Discord Bot — FFH4X Store

Bot de vendas e tickets para Discord. Compatível com qualquer hospedagem Node.js.

---

## ⚙️ Configuração

O bot aceita variáveis de ambiente de **duas formas** — use a que for suportada pela sua hospedagem:

### Opção A — Arquivo `.env` (recomendado para Pterodactyl / HeavenCloud)

Crie um arquivo `.env` na pasta raiz do bot (mesmo nível do `package.json`):

```
DISCORD_TOKEN=seu_token_aqui
DISCORD_CLIENT_ID=id_da_aplicacao
DISCORD_GUILD_ID=id_do_servidor
DATA_DIR=./data
```

O arquivo `.env.example` já contém o modelo — basta renomeá-lo para `.env` e preencher os valores.

### Opção B — Variáveis de ambiente do painel

Configure diretamente no painel da hospedagem (Railway, Render, VPS etc.):

| Variável | Obrigatória | Descrição |
|---|---|---|
| `DISCORD_TOKEN` | ✅ Sim | Token do bot (Discord Developer Portal → Bot → Token) |
| `DISCORD_CLIENT_ID` | ✅ Sim | ID da aplicação (General Information → Application ID) |
| `DISCORD_GUILD_ID` | ✅ Sim | ID do servidor Discord (clique direito → Copiar ID) |
| `DATA_DIR` | ❌ Opcional | Caminho da pasta de dados (padrão: `./data`) |

> As duas opções funcionam em conjunto — se o arquivo `.env` existir, ele é carregado automaticamente. Variáveis já definidas no ambiente do sistema têm prioridade.

---

## 🚀 Como Iniciar

### 1. Instalar dependências
```bash
npm install
```

### 2. Configurar variáveis (escolha uma das opções acima)

### 3. Iniciar o bot
```bash
npm start
```

O bot já vem com o código pré-compilado em `dist/`. Não é necessário compilar antes de iniciar.

---

## 📋 Scripts disponíveis

| Script | Comando | Descrição |
|---|---|---|
| `npm start` | `node dist/index.mjs` | **Inicia o bot** (pré-compilado) |
| `npm run build` | `node build.mjs` | Recompila o TypeScript |
| `npm run rebuild` | build + start | Recompila e inicia |
| `npm run dev` | `tsx watch src/index.ts` | Modo desenvolvimento (hot-reload) |
| `npm run deploy-commands` | registra slash commands | Execute **1x** após configurar |

---

## 🖥️ Configuração por hospedagem

### Pterodactyl / HeavenCloud / ACLClouds / Vertra Cloud

1. Faça upload do ZIP e extraia na pasta do servidor
2. Crie o arquivo `.env` com as variáveis (Opção A acima)
3. Configure no painel:
   - **Install command:** `npm install`
   - **Start command:** `npm start`
4. Inicie o servidor

> Se a hospedagem suportar variáveis de ambiente no painel, você pode usar a Opção B em vez do `.env`.

### Railway / Render / VPS

1. Faça deploy do código
2. Configure as variáveis de ambiente no painel da plataforma (Opção B)
3. Install: `npm install` | Start: `npm start`

---

## 🔑 Registrar Slash Commands

Execute **uma única vez** após configurar as variáveis e instalar as dependências:

```bash
npm run deploy-commands
```

Isso registra todos os comandos `/` no servidor Discord. Só precisa ser refeito se você adicionar novos comandos.

---

## 📁 Estrutura

```
discord-bot/
├── src/              # Código-fonte TypeScript
│   ├── commands/     # Comandos slash
│   ├── store/        # Sistema de keys (keys.json)
│   ├── index.ts      # Entrada principal
│   ├── tickets.ts    # Sistema de tickets (painel 1)
│   ├── tickets2.ts   # Sistema de tickets (painel 2)
│   └── constants.ts  # IDs de canais e cargos
├── data/
│   └── keys.json     # Estoque de keys (editável)
├── assets/           # Imagens dos embeds
├── dist/             # Código compilado (gerado pelo build)
├── build.mjs         # Script de compilação
├── package.json
├── tsconfig.json
├── .env.example      # Modelo — renomeie para .env e preencha
└── README.md
```

---

## ℹ️ Node.js Requerido

Versão mínima: **Node.js 18.17.0**
