import { readFile, writeFile, mkdir } from "node:fs/promises";
import path from "node:path";

// DATA_DIR env var allows any Node.js hosting to set a custom data path.
// Default: <cwd>/data — process.cwd() is always the bot root in both dev
// (pnpm sets cwd to package dir) and production (panel starts from bot dir).
const DATA_DIR = process.env.DATA_DIR
  ? path.resolve(process.env.DATA_DIR)
  : path.resolve(process.cwd(), "data");
const KEYS_FILE = path.join(DATA_DIR, "keys.json");

type KeyStore = Record<string, string[]>;

const INITIAL_STORE: KeyStore = {
  key_1dia: [
    "KEYAUTH-94992131-368b-447f-9fda-83df0cba0c24",
    "KEYAUTH-7852d5f6-3f3d-4bc0-81f2-7bb8023cc6b2",
    "KEYAUTH-3c5d60dc-3ff7-4309-9640-4860ca32ae23",
    "KEYAUTH-2efdd855-ec7e-45d6-a7f5-f05803ad43df",
    "KEYAUTH-89cb1bf7-091b-4f19-9e24-c25705b4e71a",
  ],
  key_10dias:        [],
  key_30dias:        [],
  key_permanente:    [],
  proj_menu_ui:      ["SLOT"],
  proj_funcao:       ["SLOT", "SLOT"],
  proj_menu_funcoes: ["SLOT"],
  proj_keys:         ["SLOT", "SLOT"],
  proj_completo:     ["SLOT"],
};

async function loadStore(): Promise<KeyStore> {
  try {
    const raw = await readFile(KEYS_FILE, "utf-8");
    const stored = JSON.parse(raw) as KeyStore;
    // Ensure any new keys added to INITIAL_STORE are present
    for (const [id, val] of Object.entries(INITIAL_STORE)) {
      if (!(id in stored)) stored[id] = val;
    }
    return stored;
  } catch {
    await saveStore(INITIAL_STORE);
    return structuredClone(INITIAL_STORE);
  }
}

async function saveStore(store: KeyStore): Promise<void> {
  await mkdir(DATA_DIR, { recursive: true });
  await writeFile(KEYS_FILE, JSON.stringify(store, null, 2), "utf-8");
}

/** Returns the number of available keys/slots for a product. */
export async function getStock(productId: string): Promise<number> {
  const store = await loadStore();
  return (store[productId] ?? []).length;
}

/** Returns stock counts for every product. */
export async function getAllStocks(): Promise<Record<string, number>> {
  const store = await loadStore();
  const result: Record<string, number> = {};
  for (const [id, keys] of Object.entries(store)) {
    result[id] = keys.length;
  }
  return result;
}

/**
 * Removes and returns the first available key for a product.
 * Returns null if the product has no keys left.
 */
export async function popKey(productId: string): Promise<string | null> {
  const store = await loadStore();
  const keys = store[productId] ?? [];
  if (keys.length === 0) return null;
  const key = keys.shift()!;
  store[productId] = keys;
  await saveStore(store);
  return key;
}

/**
 * Decrements stock by 1 for a product (used for service-type products
 * that don't have real keys, just slot counters).
 * Returns true if a slot was consumed, false if already at 0.
 */
export async function decrementStock(productId: string): Promise<boolean> {
  const store = await loadStore();
  const slots = store[productId] ?? [];
  if (slots.length === 0) return false;
  slots.shift();
  store[productId] = slots;
  await saveStore(store);
  return true;
}

/** Adds new keys to a product (for admin restocking). */
export async function addKeys(productId: string, keys: string[]): Promise<void> {
  const store = await loadStore();
  store[productId] = [...(store[productId] ?? []), ...keys];
  await saveStore(store);
}
