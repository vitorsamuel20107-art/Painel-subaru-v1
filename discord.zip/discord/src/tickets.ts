/**
 * tickets.ts — Ticket system for painel1 (FFH4X key purchases).
 */

import {
  ChannelType,
  PermissionFlagsBits,
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
} from "discord.js";
import type {
  ButtonInteraction,
  Client,
  GuildMember,
  MessageActionRowComponentBuilder,
} from "discord.js";
import { products } from "./commands/painel.js";
import { popKey } from "./store/keys.js";
import { FOUNDER_ROLE_ID, ADMIN_ROLE_ID, SUPPORT_ROLE_ID } from "./constants.js";
import { logger } from "./logger.js";

const finalizedTickets1 = new Set<string>();

function hasPermission(member: GuildMember | null): boolean {
  if (!member) return false;
  return [FOUNDER_ROLE_ID, ADMIN_ROLE_ID, SUPPORT_ROLE_ID]
    .some(id => member.roles.cache.has(id));
}

function buildAdminPanel1(channelId: string, userId: string, productId: string) {
  return [
    new ActionRowBuilder<MessageActionRowComponentBuilder>().addComponents(
      new ButtonBuilder()
        .setCustomId(`t1_fin:${channelId}:${userId}:${productId}`)
        .setLabel("✅ Finalizar Pedido")
        .setStyle(ButtonStyle.Success),
      new ButtonBuilder()
        .setCustomId(`t1_cls:${channelId}`)
        .setLabel("🔒 Fechar Ticket")
        .setStyle(ButtonStyle.Secondary),
    ),
  ];
}

function buildFinalizedPanel1() {
  return [
    new ActionRowBuilder<MessageActionRowComponentBuilder>().addComponents(
      new ButtonBuilder()
        .setCustomId("t1_done")
        .setLabel("✅ Pedido Finalizado")
        .setStyle(ButtonStyle.Success)
        .setDisabled(true),
    ),
  ];
}

// ── Create ticket on key order confirmation ───────────────────────────────
export async function createTicket1(
  interaction: ButtonInteraction,
  client: Client,
  productId: string,
): Promise<void> {
  const product = products[productId];

  if (!product) {
    await interaction.reply({ content: "❌ Produto não encontrado.", ephemeral: true });
    return;
  }
  if (!interaction.guild) {
    await interaction.reply({ content: "❌ Este sistema só funciona em servidores.", ephemeral: true });
    return;
  }

  await interaction.deferUpdate();

  const guild    = interaction.guild;
  const userId   = interaction.user.id;
  const safeUser = interaction.user.username.toLowerCase().replace(/[^a-z0-9]/g, "").slice(0, 20) || "usuario";

  const clientPerms = [
    PermissionFlagsBits.ViewChannel,
    PermissionFlagsBits.SendMessages,
    PermissionFlagsBits.ReadMessageHistory,
    PermissionFlagsBits.AttachFiles,
    PermissionFlagsBits.EmbedLinks,
  ];
  const staffPerms = [
    PermissionFlagsBits.ViewChannel,
    PermissionFlagsBits.SendMessages,
    PermissionFlagsBits.ReadMessageHistory,
    PermissionFlagsBits.ManageChannels,
    PermissionFlagsBits.ManageMessages,
    PermissionFlagsBits.AttachFiles,
    PermissionFlagsBits.EmbedLinks,
  ];

  const categoryId = guild.channels.cache.find(
    c => c.type === ChannelType.GuildCategory && c.name.toLowerCase().includes("ticket")
  )?.id;

  const permissionOverwrites = [
    { id: guild.id,         deny:  [PermissionFlagsBits.ViewChannel] },
    { id: userId,           allow: clientPerms },
    { id: client.user!.id, allow: staffPerms  },
    { id: FOUNDER_ROLE_ID, allow: staffPerms  },
    { id: ADMIN_ROLE_ID,   allow: staffPerms  },
    { id: SUPPORT_ROLE_ID, allow: staffPerms  },
  ];

  const ticketChannel = await guild.channels.create({
    name: `key-${safeUser}`,
    type: ChannelType.GuildText,
    parent: categoryId,
    permissionOverwrites,
  });

  await ticketChannel.send({
    content: `<@&${FOUNDER_ROLE_ID}>`,
    embeds: [
      new EmbedBuilder()
        .setTitle("🎉 Pedido de Key Registrado!")
        .setColor(0x00c853)
        .addFields(
          { name: "📦 Produto", value: `**${product.label}**`, inline: true },
          { name: "💰 Valor",   value: `**${product.price}**`, inline: true },
          { name: "👤 Cliente", value: `<@${userId}>`,         inline: true },
        )
        .setDescription("⏳ Aguarde um membro da equipe para enviar sua key.")
        .setTimestamp(),
    ],
  });

  await ticketChannel.send({
    embeds: [
      new EmbedBuilder()
        .setTitle("📋 Painel Administrativo")
        .setColor(0x8b00ff)
        .setDescription("Use os botões abaixo para gerenciar este pedido.")
        .setTimestamp(),
    ],
    components: buildAdminPanel1(ticketChannel.id, userId, productId),
  });

  logger.info({ userId, channelId: ticketChannel.id, productId }, "Key ticket created");
}

// ── Handle admin buttons ──────────────────────────────────────────────────
export async function handleAdminButton1(
  interaction: ButtonInteraction,
  client: Client,
  refreshPanel: (client: Client) => Promise<void>,
): Promise<void> {
  const member = interaction.member as GuildMember;

  if (!hasPermission(member)) {
    await interaction.reply({
      content: "❌ Você não tem permissão para usar este botão.",
      ephemeral: true,
    });
    return;
  }

  const [action, channelId, userId, productId] = interaction.customId.split(":");

  // ── ✅ Finalizar Pedido ───────────────────────────────────────────────
  if (action === "t1_fin") {
    if (finalizedTickets1.has(channelId)) {
      await interaction.reply({ content: "⚠️ Este pedido já foi finalizado.", ephemeral: true });
      return;
    }

    await interaction.deferReply();
    finalizedTickets1.add(channelId);

    try {
      await interaction.message.edit({ components: buildFinalizedPanel1() });
    } catch {}

    const product = products[productId];
    const key     = await popKey(productId);

    try {
      const user = await client.users.fetch(userId);
      if (key) {
        await user.send({
          embeds: [
            new EmbedBuilder()
              .setTitle("🎉 Compra Aprovada")
              .setColor(0x8b00ff)
              .setDescription(
                [
                  "Obrigado pela sua compra!",
                  "",
                  "🔑 **Sua licença:**",
                  `\`\`\`${key}\`\`\``,
                  "🔑 **Sua Key só funcionará neste Script.**",
                  "```lua",
                  `loadstring(game:HttpGet("https://raw.githubusercontent.com/vitorsamuel20107-art/Night/refs/heads/main/G"))()`,
                  "```",
                ].join("\n")
              )
              .setFooter({ text: "Night Cheats • Guarde sua key em local seguro. Ela é de uso único." })
              .setTimestamp(),
          ],
        });
        logger.info({ userId, productId }, "Key DM sent on ticket finalization");
      } else {
        logger.warn({ productId }, "No key available — stock may be empty");
      }
    } catch (err) {
      logger.warn({ err, userId }, "Could not DM client — DMs may be disabled");
    }

    await interaction.editReply({
      embeds: [
        new EmbedBuilder()
          .setColor(0x00c853)
          .setTitle("✅ Pedido Finalizado")
          .setDescription(
            `A key de **${product?.label ?? productId}** foi enviada por <@${interaction.user.id}>.\n<@${userId}> foi notificado via DM.\n\n🔒 Ticket será fechado em 5 segundos.`
          )
          .setTimestamp(),
      ],
    });

    await refreshPanel(client);
    logger.info({ productId, channelId, adminId: interaction.user.id }, "Key ticket finalized");

    setTimeout(async () => {
      try {
        if (interaction.channel && !interaction.channel.isDMBased()) {
          await interaction.channel.delete("Pedido finalizado — ticket encerrado automaticamente");
        }
      } catch (err) {
        logger.error({ err }, "Failed to auto-close key ticket channel");
      }
    }, 5000);
    return;
  }

  // ── 🔒 Fechar Ticket ─────────────────────────────────────────────────
  if (action === "t1_cls") {
    await interaction.reply({ content: "🔒 Fechando ticket em 5 segundos...", ephemeral: true });
    setTimeout(async () => {
      try {
        if (interaction.channel && !interaction.channel.isDMBased()) {
          await interaction.channel.delete("Ticket fechado pela equipe");
        }
      } catch (err) {
        logger.error({ err }, "Failed to delete key ticket channel");
      }
    }, 5000);
    return;
  }
}
