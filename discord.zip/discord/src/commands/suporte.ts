import {
  SlashCommandBuilder,
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  AttachmentBuilder,
  PermissionFlagsBits,
} from "discord.js";
import type { ChatInputCommandInteraction } from "discord.js";
import type { Command } from "../types.js";
import { logger } from "../logger.js";
import path from "node:path";
import fs from "node:fs";

// process.cwd() is always the bot root directory, both in dev (tsx) and in
// the compiled bundle (dist/index.mjs). See painel.ts for full explanation.
const THUMB_PATH  = path.resolve(process.cwd(), "assets", "main_thumb.png");
const BANNER_PATH = path.resolve(process.cwd(), "assets", "suporte_banner.png");

function buildEmbed(withImage: boolean): EmbedBuilder {
  const embed = new EmbedBuilder()
    .setTitle("🛠️ Suporte — [NIGHT CHEATS]")
    .setColor(0x8b00ff)
    .setThumbnail("attachment://main_thumb.png")
    .setDescription(
      [
        "**Abra um ticket se precisar de:**",
        "",
        "• Tirar dúvidas sobre nossos scripts, produtos ou qualquer serviço da nossos;",
        "",
        "• Receber ajuda como configuração ou utilização dos scripts;",
        "",
        "• Resolver erros, bugs ou problemas técnicos;",
        "",
        "• Solicitar suporte relacionado à sua compra ou acesso aos produtos.",
        "",
        "🎫 Clique no botão abaixo para abrir um ticket.",
      ].join("\n")
    )
    .setFooter({ text: "Suporte e atendimento!" });

  if (withImage) {
    embed.setImage("attachment://suporte_banner.png");
  }

  return embed;
}

const command: Command = {
  data: new SlashCommandBuilder()
    .setName("suporte")
    .setDescription("Envia o painel de suporte neste canal")
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

  async execute(interaction: ChatInputCommandInteraction) {
    await interaction.deferReply({ ephemeral: true });

    const channel = interaction.channel;
    if (!channel || channel.isDMBased()) {
      await interaction.editReply("❌ Use este comando em um canal de servidor.");
      return;
    }

    const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
      new ButtonBuilder()
        .setCustomId("suporte_open")
        .setLabel("🎫 Abrir Ticket")
        .setStyle(ButtonStyle.Success)
    );

    const thumbExists  = fs.existsSync(THUMB_PATH);
    const bannerExists = fs.existsSync(BANNER_PATH);
    const useImages    = thumbExists && bannerExists;
    logger.info({ thumbExists, bannerExists }, "Support panel image check");

    try {
      if (useImages) {
        const thumbAttachment  = new AttachmentBuilder(THUMB_PATH,  { name: "main_thumb.png"    });
        const bannerAttachment = new AttachmentBuilder(BANNER_PATH, { name: "suporte_banner.png" });
        await channel.send({
          embeds: [buildEmbed(true)],
          components: [row],
          files: [thumbAttachment, bannerAttachment],
        });
      } else {
        logger.warn({ THUMB_PATH, BANNER_PATH }, "Images not found — sending without images");
        await channel.send({ embeds: [buildEmbed(false)], components: [row] });
      }

      logger.info({ adminId: interaction.user.id, channelId: channel.id }, "Support panel posted");
      await interaction.editReply("✅ Painel de suporte enviado com sucesso!");
    } catch (err) {
      logger.error({ err, channelId: channel.id }, "Failed to send support panel");
      await interaction.editReply(
        `❌ Erro ao enviar o painel: \`${err instanceof Error ? err.message : String(err)}\``
      );
    }
  },
};

export default command;
