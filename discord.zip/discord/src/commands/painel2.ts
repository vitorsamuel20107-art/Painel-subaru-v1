/**
 * painel2.ts — Second independent sales panel (custom services).
 * Stock control and ticket creation are handled via tickets2.ts.
 */

import path from "node:path";
import {
  SlashCommandBuilder,
  EmbedBuilder,
  StringSelectMenuBuilder,
  StringSelectMenuOptionBuilder,
  ButtonBuilder,
  ButtonStyle,
  ActionRowBuilder,
  AttachmentBuilder,
} from "discord.js";
import type {
  Client,
  ChatInputCommandInteraction,
  StringSelectMenuInteraction,
  MessageActionRowComponentBuilder,
} from "discord.js";
import type { Command } from "../types.js";
import { getAllStocks, getStock } from "../store/keys.js";
import { PANEL2_CHANNEL_ID } from "../constants.js";
import { logger } from "../logger.js";

// process.cwd() is always the bot root directory, both in dev (tsx) and in
// the compiled bundle (dist/index.mjs). See painel.ts for full explanation.
const ASSETS_DIR  = path.resolve(process.cwd(), "assets");
const THUMB_PATH  = path.join(ASSETS_DIR, "main_thumb.png");
const BANNER_PATH = path.join(ASSETS_DIR, "projetos_banner.png");

// ─── Products ─────────────────────────────────────────────────────────────
export const products2: Record<string, { label: string; price: string }> = {
  proj_menu_ui:      { label: "🎨 MENU UI PERSONALIZADA", price: "R$ 10,00"             },
  proj_funcao:       { label: "⚙️ FUNÇÃO EXCLUSIVA",      price: "R$ 12,00"             },
  proj_menu_funcoes: { label: "🧩 PACOTE DE FUNÇÕES",     price: "R$ 18,00"             },
  proj_keys:         { label: "🔑 SISTEMA DE KEYS",       price: "R$ 25,00"             },
  proj_completo:     { label: "👑 PROJETO COMPLETO",      price: "A partir de R$ 45,00" },
};

// ─── Embed ────────────────────────────────────────────────────────────────
function buildMainEmbed2(): EmbedBuilder {
  return new EmbedBuilder()
    .setTitle("🎨 Projeto Personalizado")
    .setColor(0x8b00ff)
    .setThumbnail("attachment://main_thumb.png")
    .setDescription(
      [
        "Transforme sua ideia em um projeto exclusivo!",
        "",
        "⚙️ | **O QUE VOCÊ RECEBE:**",
        "",
        "🎨 Design totalmente personalizado",
        "👤 Nome, logo e identidade visual exclusivos",
        "⚙️ Funções desenvolvidas conforme o seu pedido",
        "🖥️ Interface (UI) exclusiva",
        "🔑 Sistema de Keys próprio",
        "🛡️ Painel para gerenciamento de Keys",
        "💎 Suporte durante o desenvolvimento",
        "🔄 Atualizações gratuitas",
        "",
        "🎮 **PERSONALIZAÇÕES:**",
        "",
        "• Menus Roblox",
        "• Funções exclusivas(no meu alcançe é claro)",
        "• Interface personalizada",
        "• Sistemas de Keys",
        "• Sistemas de autenticação",
        "• Outras personalizações sob encomenda",
      ].join("\n")
    )
    .setImage("attachment://projetos_banner.png")
    .setTimestamp();
}

// ─── Select menu with live stock ──────────────────────────────────────────
async function buildSelectMenu2(): Promise<
  ActionRowBuilder<MessageActionRowComponentBuilder>
> {
  const stocks = await getAllStocks();

  const options = Object.entries(products2).map(([id, { label, price }]) => {
    const stock = stocks[id] ?? 0;
    const description =
      stock > 0
        ? `💸 | Valor: ${price} - 📦 | Estoque: ${stock}`
        : "❌ Sem Estoque";

    return new StringSelectMenuOptionBuilder()
      .setLabel(label)
      .setDescription(description)
      .setValue(id);
  });

  const menu = new StringSelectMenuBuilder()
    .setCustomId("painel2_produto")
    .setPlaceholder("📦 Selecione um produto")
    .addOptions(options);

  return new ActionRowBuilder<MessageActionRowComponentBuilder>().addComponents(menu);
}

// ─── Panel payload ────────────────────────────────────────────────────────
export async function buildPanelPayload2() {
  return {
    embeds: [buildMainEmbed2()],
    files: [
      new AttachmentBuilder(THUMB_PATH,  { name: "main_thumb.png"      }),
      new AttachmentBuilder(BANNER_PATH, { name: "projetos_banner.png" }),
    ],
    components: [await buildSelectMenu2()],
  };
}

// ─── Refresh (send or edit existing message) ─────────────────────────────
export async function refreshPanel2(client: Client): Promise<void> {
  try {
    const channel = await client.channels.fetch(PANEL2_CHANNEL_ID);
    if (!channel || !channel.isTextBased() || !channel.isSendable()) {
      logger.error({ channelId: PANEL2_CHANNEL_ID }, "Panel 2 channel not found or not sendable");
      return;
    }

    const messages = await channel.messages.fetch({ limit: 100 });
    const botId    = client.user?.id;
    const existing = messages.find(
      (msg) =>
        msg.author.id === botId &&
        msg.embeds.length > 0 &&
        (msg.embeds[0].title ?? "").includes("Projeto Personalizado")
    );

    const payload = await buildPanelPayload2();

    if (existing) {
      await existing.edit(payload);
      logger.info({ messageId: existing.id }, "Panel 2 updated in channel");
    } else {
      await channel.send(payload);
      logger.info({ channelId: PANEL2_CHANNEL_ID }, "Panel 2 sent to channel");
    }
  } catch (err) {
    logger.error({ err }, "Failed to refresh sales panel 2");
  }
}

// ─── Select handler (shows details + confirm button) ─────────────────────
export async function handleProductSelect2(
  interaction: StringSelectMenuInteraction
): Promise<void> {
  const value   = interaction.values[0];
  const product = products2[value];

  if (!product) {
    await interaction.reply({ content: "❌ Produto não encontrado.", ephemeral: true });
    return;
  }

  const stock = await getStock(value);

  if (stock === 0) {
    await interaction.reply({
      embeds: [
        new EmbedBuilder()
          .setColor(0xff1744)
          .setTitle("❌ Sem Estoque")
          .setDescription(
            `**${product.label}** está temporariamente sem estoque.\nVolte em breve ou escolha outro produto.`
          )
          .setTimestamp(),
      ],
      ephemeral: true,
    });
    return;
  }

  const confirmButton = new ButtonBuilder()
    .setCustomId(`painel2_confirmar:${value}`)
    .setLabel("✅ Confirmar Pedido")
    .setStyle(ButtonStyle.Success);

  const row = new ActionRowBuilder<MessageActionRowComponentBuilder>().addComponents(confirmButton);

  await interaction.reply({
    embeds: [
      new EmbedBuilder()
        .setTitle("🛒 Detalhes do Produto")
        .setColor(0x8b00ff)
        .addFields(
          { name: "📦 Produto", value: `**${product.label}**`, inline: true  },
          { name: "💰 Preço",   value: `**${product.price}**`, inline: true  },
          { name: "📊 Estoque", value: `✅ **${stock} disponíve${stock === 1 ? "l" : "is"}**`, inline: false },
        )
        .setDescription("Clique em **Confirmar Pedido** para abrir um ticket e dar início ao seu projeto.")
        .setFooter({ text: "Um ticket privado será criado automaticamente para você." })
        .setTimestamp(),
    ],
    components: [row],
    ephemeral: true,
  });
}

// ─── Slash command ────────────────────────────────────────────────────────
const command: Command = {
  data: new SlashCommandBuilder()
    .setName("painel2")
    .setDescription("Envia o segundo painel de vendas no canal configurado"),

  async execute(interaction: ChatInputCommandInteraction) {
    await interaction.reply(await buildPanelPayload2());
  },
};

export default command;
