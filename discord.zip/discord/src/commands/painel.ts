import path from "node:path";
import {
  SlashCommandBuilder,
  EmbedBuilder,
  StringSelectMenuBuilder,
  StringSelectMenuOptionBuilder,
  ButtonBuilder,
  ButtonStyle,
  ActionRowBuilder,
  AttachmentBuilder,
} from "discord.js";
import type {
  Client,
  ChatInputCommandInteraction,
  StringSelectMenuInteraction,
  MessageActionRowComponentBuilder,
} from "discord.js";
import type { Command } from "../types.js";
import { getAllStocks, getStock } from "../store/keys.js";
import { PANEL_CHANNEL_ID } from "../constants.js";
import { logger } from "../logger.js";

// process.cwd() is always the bot root directory, both in dev (tsx) and in
// the compiled bundle (dist/index.mjs), because pnpm sets cwd to the package
// directory before running any script. External hosting panels do the same.
const ASSETS_DIR     = path.resolve(process.cwd(), "assets");
const THUMBNAIL_PATH = path.join(ASSETS_DIR, "main_thumb.png");
const BANNER_PATH    = path.join(ASSETS_DIR, "banner.png");

// ─── Configurable ────────────────────────────────────────────────────────────
const DEMO_URL =
  process.env.DEMO_URL ?? "https://youtu.be/UByxHt4V7y8?is=jnmXUfyLZm8w1JT4";
// ─────────────────────────────────────────────────────────────────────────────

export const products: Record<string, { label: string; price: string }> = {
  key_1dia:      { label: "1 DIA // FFH4X",      price: "R$1,00"  },
  key_10dias:    { label: "10 DIAS // FFH4X",    price: "R$10,00" },
  key_30dias:    { label: "30 DIAS // FFH4X",    price: "R$20,00" },
  key_permanente:{ label: "PERMANENTE // FFH4X", price: "R$28,00" },
};

function buildMainEmbed(): EmbedBuilder {
  return new EmbedBuilder()
    .setTitle("🛒 Script Mobile FFH4X")
    .setColor(0x8b00ff)
    .setThumbnail("attachment://main_thumb.png")
    .setDescription(
      [
        "⚙️ | **FUNÇÕES:**",
        "",
        "• AIMBOT (Rage/Legit)",
        "• FOV",
        "• ESP",
        "   └ Caixas",
        "   └ Linhas",
        "   └ Nome",
        "   └ Distância",
        "   └ Vida",
        "   └ Esqueleto",
        "• SPIN BOT",
        "• FREE CAM",
        "• 3ª PESSOA",
        "• BYPASS",
        "",
        "✅ | **75% ANTIBAN**",
        "",
        "🐱‍👤 | Disfarçado, ative usando 3 dedos na tela.",
      ].join("\n")
    )
    .setImage("attachment://banner.png")
    .setTimestamp();
}

async function buildSelectMenu(): Promise<
  ActionRowBuilder<MessageActionRowComponentBuilder>
> {
  const stocks = await getAllStocks();

  const menu = new StringSelectMenuBuilder()
    .setCustomId("painel_produto")
    .setPlaceholder("📦 Selecione um produto")
    .addOptions(
      new StringSelectMenuOptionBuilder()
        .setLabel("1 DIA // FFH4X")
        .setDescription(
          stocks.key_1dia > 0
            ? `💸 Valor: R$1,00 • 📦 Estoque: ${stocks.key_1dia}`
            : "❌ Sem estoque"
        )
        .setValue("key_1dia"),
      new StringSelectMenuOptionBuilder()
        .setLabel("10 DIAS // FFH4X")
        .setDescription(
          stocks.key_10dias > 0
            ? `💸 Valor: R$10,00 • 📦 Estoque: ${stocks.key_10dias}`
            : "❌ Sem estoque"
        )
        .setValue("key_10dias"),
      new StringSelectMenuOptionBuilder()
        .setLabel("30 DIAS // FFH4X")
        .setDescription(
          stocks.key_30dias > 0
            ? `💸 Valor: R$20,00 • 📦 Estoque: ${stocks.key_30dias}`
            : "❌ Sem estoque"
        )
        .setValue("key_30dias"),
      new StringSelectMenuOptionBuilder()
        .setLabel("PERMANENTE // FFH4X")
        .setDescription(
          stocks.key_permanente > 0
            ? `💸 Valor: R$28,00 • 📦 Estoque: ${stocks.key_permanente}`
            : "❌ Sem estoque"
        )
        .setValue("key_permanente")
    );

  return new ActionRowBuilder<MessageActionRowComponentBuilder>().addComponents(menu);
}

function buildButtonRow(): ActionRowBuilder<MessageActionRowComponentBuilder> {
  const button = new ButtonBuilder()
    .setLabel("🎥 Confira a demonstração")
    .setStyle(ButtonStyle.Link)
    .setURL(DEMO_URL);

  return new ActionRowBuilder<MessageActionRowComponentBuilder>().addComponents(
    button
  );
}

export async function buildPanelPayload() {
  return {
    embeds: [buildMainEmbed()],
    files: [
      new AttachmentBuilder(THUMBNAIL_PATH, { name: "main_thumb.png" }),
      new AttachmentBuilder(BANNER_PATH, { name: "banner.png" }),
    ],
    components: [await buildSelectMenu(), buildButtonRow()],
  };
}

/** Sends or edits the sales panel in the configured channel. */
export async function refreshPanel(client: Client): Promise<void> {
  try {
    const channel = await client.channels.fetch(PANEL_CHANNEL_ID);
    if (!channel || !channel.isTextBased() || !channel.isSendable()) {
      logger.error({ channelId: PANEL_CHANNEL_ID }, "Panel channel not found or not sendable");
      return;
    }

    const messages = await channel.messages.fetch({ limit: 100 });
    const botId = client.user?.id;
    const existing = messages.find(
      (msg) =>
        msg.author.id === botId &&
        msg.embeds.length > 0 &&
        (msg.embeds[0].title ?? "").includes("FFH4X")
    );

    const payload = await buildPanelPayload();

    if (existing) {
      await existing.edit(payload);
      logger.info({ messageId: existing.id }, "Panel updated in channel");
    } else {
      await channel.send(payload);
      logger.info({ channelId: PANEL_CHANNEL_ID }, "Panel sent to channel");
    }
  } catch (err) {
    logger.error({ err }, "Failed to refresh sales panel");
  }
}

export async function handleProductSelect(
  interaction: StringSelectMenuInteraction
): Promise<void> {
  const value = interaction.values[0];
  const product = products[value];

  if (!product) {
    await interaction.reply({ content: "❌ Produto não encontrado.", ephemeral: true });
    return;
  }

  const stock = await getStock(value);

  if (stock === 0) {
    await interaction.reply({
      embeds: [
        new EmbedBuilder()
          .setColor(0xff1744)
          .setTitle("❌ Sem Estoque")
          .setDescription(
            `**${product.label}** está temporariamente sem estoque.\nVolte em breve ou escolha outro produto.`
          )
          .setTimestamp(),
      ],
      ephemeral: true,
    });
    return;
  }

  const embed = new EmbedBuilder()
    .setTitle("🛒 Detalhes do Produto")
    .setColor(0x8b00ff)
    .addFields(
      { name: "📦 Produto", value: `**${product.label}**`, inline: true },
      { name: "💰 Preço",   value: `**${product.price}**`, inline: true },
      { name: "📊 Estoque", value: `✅ **${stock} Keys disponíveis**`, inline: false }
    )
    .setFooter({ text: "Entre em contato para finalizar sua compra." })
    .setTimestamp();

  const confirmButton = new ButtonBuilder()
    .setCustomId(`painel_confirmar:${value}`)
    .setLabel("✅ Confirmar Pedido")
    .setStyle(ButtonStyle.Success);
  const confirmRow = new ActionRowBuilder<MessageActionRowComponentBuilder>().addComponents(confirmButton);
  await interaction.reply({ embeds: [embed], components: [confirmRow], ephemeral: true });
}

const command: Command = {
  data: new SlashCommandBuilder()
    .setName("painel")
    .setDescription("Exibe o painel de vendas do Script FFH4X Mobile"),

  async execute(interaction: ChatInputCommandInteraction) {
    await interaction.reply(await buildPanelPayload());
  },
};

export default command;
