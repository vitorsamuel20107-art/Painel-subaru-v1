import { SlashCommandBuilder, EmbedBuilder } from "discord.js";
import type { ChatInputCommandInteraction } from "discord.js";
import type { Command } from "../types.js";

const command: Command = {
  data: new SlashCommandBuilder()
    .setName("help")
    .setDescription("List all available commands"),

  async execute(interaction: ChatInputCommandInteraction) {
    const embed = new EmbedBuilder()
      .setTitle("Available Commands")
      .setColor(0x5865f2)
      .setDescription("Here is a list of all slash commands:")
      .addFields(
        { name: "/ping", value: "Check bot latency", inline: false },
        { name: "/help", value: "Show this help message", inline: false },
        {
          name: "/serverinfo",
          value: "Display information about this server",
          inline: false,
        }
      )
      .setTimestamp()
      .setFooter({ text: "Discord Bot powered by discord.js v14" });

    await interaction.reply({ embeds: [embed] });
  },
};

export default command;
