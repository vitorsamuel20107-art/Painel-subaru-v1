import {
  SlashCommandBuilder,
  EmbedBuilder,
  PermissionFlagsBits,
} from "discord.js";
import type { ChatInputCommandInteraction } from "discord.js";
import type { Command } from "../types.js";
import { logger } from "../logger.js";

const command: Command = {
  data: new SlashCommandBuilder()
    .setName("dm")
    .setDescription("Envia as credenciais de acesso do script por DM")
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .addUserOption((opt) =>
      opt
        .setName("usuario")
        .setDescription("O usuário que receberá a DM")
        .setRequired(true)
    )
    .addStringOption((opt) =>
      opt
        .setName("email")
        .setDescription("E-mail da conta")
        .setRequired(true)
    )
    .addStringOption((opt) =>
      opt
        .setName("senha")
        .setDescription("Senha da conta")
        .setRequired(true)
    )
    .addStringOption((opt) =>
      opt
        .setName("instrucoes")
        .setDescription("Instruções de acesso")
        .setRequired(true)
    ),

  async execute(interaction: ChatInputCommandInteraction) {
    await interaction.deferReply({ ephemeral: true });

    const target     = interaction.options.getUser("usuario", true);
    const email      = interaction.options.getString("email", true);
    const senha      = interaction.options.getString("senha", true);
    const instrucoes = interaction.options.getString("instrucoes", true);

    const dmEmbed = new EmbedBuilder()
      .setTitle("📦 SEU SCRIPT")
      .setColor(0x8b00ff)
      .setDescription(
        [
          "━━━━━━━━━━━━━━━━━━━━━━",
          "",
          "🔐 **Conta de Acesso**",
          "",
          `📧 **E-mail:** ${email}`,
          `🔑 **Senha:** ${senha}`,
          "",
          "📋 **Como acessar**",
          "",
          instrucoes,
          "",
          "━━━━━━━━━━━━━━━━━━━━━━",
          "",
          "✅ Caso tenha qualquer dúvida, abra um ticket.",
        ].join("\n")
      );

    try {
      const dm = await target.createDM();
      await dm.send({ embeds: [dmEmbed] });

      logger.info(
        { adminId: interaction.user.id, targetId: target.id },
        "DM sent via /dm command"
      );

      await interaction.editReply({
        embeds: [
          new EmbedBuilder()
            .setColor(0x00c853)
            .setTitle("✅ DM enviada com sucesso!")
            .setDescription(`A mensagem foi enviada para ${target}.`)
            .setTimestamp(),
        ],
      });
    } catch {
      logger.warn(
        { adminId: interaction.user.id, targetId: target.id },
        "Failed to send DM — user may have DMs disabled"
      );

      await interaction.editReply({
        embeds: [
          new EmbedBuilder()
            .setColor(0xff0000)
            .setTitle("❌ Não foi possível enviar a DM")
            .setDescription(
              `${target} pode estar com as DMs desativadas ou bloqueou o bot.`
            )
            .setTimestamp(),
        ],
      });
    }
  },
};

export default command;
