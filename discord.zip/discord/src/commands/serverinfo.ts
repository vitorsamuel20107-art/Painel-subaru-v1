import { SlashCommandBuilder, EmbedBuilder } from "discord.js";
import type { ChatInputCommandInteraction } from "discord.js";
import type { Command } from "../types.js";

const command: Command = {
  data: new SlashCommandBuilder()
    .setName("serverinfo")
    .setDescription("Display information about this server"),

  async execute(interaction: ChatInputCommandInteraction) {
    const { guild } = interaction;
    if (!guild) {
      await interaction.reply({
        content: "This command can only be used inside a server.",
        ephemeral: true,
      });
      return;
    }

    const owner = await guild.fetchOwner();
    const createdAt = Math.floor(guild.createdTimestamp / 1000);

    const embed = new EmbedBuilder()
      .setTitle(guild.name)
      .setColor(0x5865f2)
      .setThumbnail(guild.iconURL())
      .addFields(
        { name: "Owner", value: owner.user.tag, inline: true },
        { name: "Members", value: guild.memberCount.toString(), inline: true },
        {
          name: "Created",
          value: `<t:${createdAt}:R>`,
          inline: true,
        },
        {
          name: "Channels",
          value: guild.channels.cache.size.toString(),
          inline: true,
        },
        {
          name: "Roles",
          value: guild.roles.cache.size.toString(),
          inline: true,
        },
        {
          name: "Boosts",
          value: (guild.premiumSubscriptionCount ?? 0).toString(),
          inline: true,
        }
      )
      .setTimestamp();

    await interaction.reply({ embeds: [embed] });
  },
};

export default command;
