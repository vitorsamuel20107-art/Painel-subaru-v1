import {
  SlashCommandBuilder,
  EmbedBuilder,
  PermissionFlagsBits,
} from "discord.js";
import type { ChatInputCommandInteraction, GuildMember } from "discord.js";
import type { Command } from "../types.js";
import { products, refreshPanel } from "./painel.js";
import { products2, refreshPanel2 } from "./painel2.js";
import { FOUNDER_ROLE_ID } from "../constants.js";
import { popKey, getStock, addKeys } from "../store/keys.js";
import { logger } from "../logger.js";

const PRODUCT_CHOICES = [
  { name: "1 DIA // FFH4X",      value: "key_1dia"       },
  { name: "10 DIAS // FFH4X",    value: "key_10dias"     },
  { name: "30 DIAS // FFH4X",    value: "key_30dias"     },
  { name: "PERMANENTE // FFH4X", value: "key_permanente" },
] as const;

const PRODUCT2_CHOICES = [
  { name: "🎨 MENU UI PERSONALIZADA", value: "proj_menu_ui"      },
  { name: "⚙️ FUNÇÃO EXCLUSIVA",      value: "proj_funcao"       },
  { name: "🧩 PACOTE DE FUNÇÕES",     value: "proj_menu_funcoes" },
  { name: "🔑 SISTEMA DE KEYS",       value: "proj_keys"         },
  { name: "👑 PROJETO COMPLETO",      value: "proj_completo"     },
] as const;

const command: Command = {
  data: new SlashCommandBuilder()
    .setName("admin")
    .setDescription("Comandos administrativos")
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)

    // ── /admin enviarkey ──────────────────────────────────────────────────
    .addSubcommand((sub) =>
      sub
        .setName("enviarkey")
        .setDescription("Envia uma key para o comprador após confirmar o pagamento")
        .addUserOption((opt) =>
          opt
            .setName("usuario")
            .setDescription("O comprador que receberá a key por DM")
            .setRequired(true)
        )
        .addStringOption((opt) =>
          opt
            .setName("produto")
            .setDescription("Produto comprado")
            .setRequired(true)
            .addChoices(...PRODUCT_CHOICES)
        )
    )

    // ── /admin addkeys ────────────────────────────────────────────────────
    .addSubcommand((sub) =>
      sub
        .setName("addkeys")
        .setDescription("Adiciona novas keys ao estoque de um produto FFH4X")
        .addStringOption((opt) =>
          opt
            .setName("produto")
            .setDescription("Produto que receberá as novas keys")
            .setRequired(true)
            .addChoices(...PRODUCT_CHOICES)
        )
        .addStringOption((opt) =>
          opt
            .setName("keys")
            .setDescription("Keys separadas por vírgula (ex: KEY-aaa, KEY-bbb)")
            .setRequired(true)
        )
    )

    // ── /admin addstock ───────────────────────────────────────────────────
    .addSubcommand((sub) =>
      sub
        .setName("addstock")
        .setDescription("Adiciona vagas ao estoque de um produto do painel de projetos")
        .addStringOption((opt) =>
          opt
            .setName("produto")
            .setDescription("Produto do painel de projetos personalizados")
            .setRequired(true)
            .addChoices(...PRODUCT2_CHOICES)
        )
        .addIntegerOption((opt) =>
          opt
            .setName("quantidade")
            .setDescription("Quantidade de vagas a adicionar (padrão: 1)")
            .setRequired(false)
            .setMinValue(1)
            .setMaxValue(100)
        )
    ),

  // ── execute ───────────────────────────────────────────────────────────────
  async execute(interaction: ChatInputCommandInteraction) {
    const member = interaction.member as GuildMember;
    if (!member?.roles?.cache?.has(FOUNDER_ROLE_ID)) {
      await interaction.reply({
        content: "❌ Você não tem permissão para usar este comando. Apenas o cargo **Fundador** pode utilizá-lo.",
        ephemeral: true,
      });
      return;
    }

    const sub = interaction.options.getSubcommand();

    // ── /admin enviarkey ──────────────────────────────────────────────────
    if (sub === "enviarkey") {
      await interaction.deferReply({ ephemeral: true });

      const target    = interaction.options.getUser("usuario", true);
      const productId = interaction.options.getString("produto", true);
      const product   = products[productId];

      if (!product) {
        await interaction.editReply("❌ Produto inválido.");
        return;
      }

      const stock = await getStock(productId);
      if (stock === 0) {
        await interaction.editReply(
          `❌ **${product.label}** está sem estoque. Use \`/admin addkeys\` para repor as keys.`
        );
        return;
      }

      const key = await popKey(productId);
      if (!key) {
        await interaction.editReply("❌ Não foi possível obter uma key. Tente novamente.");
        return;
      }

      const dmEmbed = new EmbedBuilder()
        .setTitle("🎉 Compra Aprovada")
        .setColor(0x8b00ff)
        .setDescription(
          [
            "Obrigado pela sua compra!",
            "",
            "🔑 **Sua licença:**",
            `\`\`\`${key}\`\`\``,
            "🔑 **Sua Key só funcionará neste Script.**",
            "```lua",
            `loadstring(game:HttpGet("https://raw.githubusercontent.com/vitorsamuel20107-art/Night/refs/heads/main/G"))()`,
            "```",
          ].join("\n")
        )
        .setFooter({
          text: "Night Cheats • Guarde sua key em local seguro. Ela é de uso único.",
        })
        .setTimestamp();

      try {
        const dm = await target.createDM();
        await dm.send({ embeds: [dmEmbed] });
      } catch {
        await interaction.editReply(
          `❌ Não foi possível enviar DM para **${target.username}**. O usuário pode ter DMs desativadas. A key não foi consumida.`
        );
        logger.warn({ userId: target.id }, "Failed to send DM — key not consumed");
        return;
      }

      const newStock = await getStock(productId);
      logger.info(
        { productId, userId: target.id, adminId: interaction.user.id, newStock },
        "Key delivered via DM"
      );

      await Promise.all([
        refreshPanel(interaction.client),
        refreshPanel2(interaction.client),
      ]);

      await interaction.editReply({
        embeds: [
          new EmbedBuilder()
            .setColor(0x00c853)
            .setTitle("✅ Key enviada com sucesso!")
            .addFields(
              { name: "👤 Comprador",        value: `${target}`,             inline: true },
              { name: "📦 Produto",          value: product.label,           inline: true },
              { name: "📊 Estoque restante", value: `**${newStock}** keys`,  inline: true }
            )
            .setTimestamp(),
        ],
      });
      return;
    }

    // ── /admin addkeys ────────────────────────────────────────────────────
    if (sub === "addkeys") {
      await interaction.deferReply({ ephemeral: true });

      const productId = interaction.options.getString("produto", true);
      const raw       = interaction.options.getString("keys", true);
      const product   = products[productId];

      if (!product) {
        await interaction.editReply("❌ Produto inválido.");
        return;
      }

      const parsed = raw
        .split(/[,\n]+/)
        .map((k) => k.trim())
        .filter((k) => k.length > 0);

      if (parsed.length === 0) {
        await interaction.editReply("❌ Nenhuma key válida encontrada. Separe as keys por vírgula.");
        return;
      }

      await addKeys(productId, parsed);
      const newStock = await getStock(productId);

      logger.info(
        { productId, added: parsed.length, newStock, adminId: interaction.user.id },
        "Keys added to stock"
      );

      await Promise.all([
        refreshPanel(interaction.client),
        refreshPanel2(interaction.client),
      ]);

      await interaction.editReply({
        embeds: [
          new EmbedBuilder()
            .setColor(0x8b00ff)
            .setTitle("📦 Estoque atualizado!")
            .addFields(
              { name: "📦 Produto",            value: product.label,                     inline: true },
              { name: "➕ Keys adicionadas",    value: `**${parsed.length}**`,            inline: true },
              { name: "📊 Estoque atual",       value: `**${newStock}** keys disponíveis`, inline: true },
              { name: "🔑 Keys cadastradas",   value: parsed.map((k) => `\`${k}\``).join("\n"), inline: false }
            )
            .setTimestamp(),
        ],
      });
      return;
    }

    // ── /admin addstock ───────────────────────────────────────────────────
    if (sub === "addstock") {
      await interaction.deferReply({ ephemeral: true });

      const productId  = interaction.options.getString("produto", true);
      const quantidade = interaction.options.getInteger("quantidade") ?? 1;
      const product    = products2[productId];

      if (!product) {
        await interaction.editReply("❌ Produto inválido.");
        return;
      }

      // Add slot entries (each SLOT represents one available unit)
      const slots = Array.from({ length: quantidade }, () => "SLOT");
      await addKeys(productId, slots);
      const newStock = await getStock(productId);

      logger.info(
        { productId, added: quantidade, newStock, adminId: interaction.user.id },
        "Stock slots added to panel 2 product"
      );

      await refreshPanel2(interaction.client);

      await interaction.editReply({
        embeds: [
          new EmbedBuilder()
            .setColor(0x00c853)
            .setTitle("📦 Estoque atualizado!")
            .addFields(
              { name: "📦 Produto",          value: product.label,                       inline: true },
              { name: "➕ Vagas adicionadas", value: `**${quantidade}**`,                 inline: true },
              { name: "📊 Estoque atual",    value: `**${newStock}** vaga${newStock !== 1 ? "s" : ""} disponíve${newStock !== 1 ? "is" : "l"}`, inline: true }
            )
            .setTimestamp(),
        ],
      });
      return;
    }
  },
};

export default command;
