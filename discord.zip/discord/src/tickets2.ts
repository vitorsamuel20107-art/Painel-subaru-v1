/**
 * tickets2.ts — Ticket system for painel2 (custom services).
 * Handles ticket creation on order confirmation and admin button actions.
 */

import {
  ChannelType,
  PermissionFlagsBits,
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
} from "discord.js";
import type {
  ButtonInteraction,
  Client,
  GuildMember,
  MessageActionRowComponentBuilder,
} from "discord.js";
import { products2 } from "./commands/painel2.js";
import { decrementStock } from "./store/keys.js";
import { FOUNDER_ROLE_NAME, FOUNDER_ROLE_ID, ADMIN_ROLE_ID, SUPPORT_ROLE_ID } from "./constants.js";
import { logger } from "./logger.js";

// Track finalized tickets to prevent double-finalization (in-memory; survives hot reloads)
const finalizedTickets = new Set<string>();

// ─── Per-product DM messages ──────────────────────────────────────────────
function buildFinalizationDM(productId: string): EmbedBuilder {
  const messages: Record<string, string> = {
    proj_menu_ui: [
      "Obrigado por escolher nossos serviços.",
      "",
      "📩 Confira esta conversa. Quando seu menu personalizado estiver concluído, ele será enviado por aqui.",
      "",
      "📧 Junto com o projeto, você também receberá:",
      "• E-mail da conta onde o projeto está hospedado.",
      "• Senha da conta.",
      "• Instruções de acesso.",
      "",
      "⚠️ Não compartilhe essas informações com ninguém.",
      "",
      "Agradecemos pela preferência! ❤️",
    ].join("\n"),

    proj_funcao: [
      "Obrigado por escolher nossos serviços.",
      "",
      "📩 Confira esta conversa. Quando sua função exclusiva estiver concluída, ela será enviada por aqui.",
      "",
      "📧 Junto com a entrega, você também receberá:",
      "• E-mail da conta onde o projeto está hospedado.",
      "• Senha da conta.",
      "• Instruções de acesso.",
      "",
      "⚠️ Não compartilhe essas informações com ninguém.",
      "",
      "Agradecemos pela preferência! ❤️",
    ].join("\n"),

    proj_menu_funcoes: [
      "Obrigado por escolher nossos serviços.",
      "",
      "📩 Confira esta conversa. Quando seu pacote de funções estiver concluído, ele será enviado por aqui.",
      "",
      "📧 Junto com a entrega, você também receberá:",
      "• E-mail da conta onde o projeto está hospedado.",
      "• Senha da conta.",
      "• Instruções de acesso.",
      "",
      "⚠️ Não compartilhe essas informações com ninguém.",
      "",
      "Agradecemos pela preferência! ❤️",
    ].join("\n"),

    proj_completo: [
      "Obrigado por escolher nossos serviços.",
      "",
      "📩 Confira esta conversa. Quando seu projeto completo estiver concluído, ele será enviado por aqui.",
      "",
      "📧 Junto com a entrega, você também receberá:",
      "• E-mail da conta onde o projeto está hospedado.",
      "• Senha da conta.",
      "• Instruções de acesso.",
      "",
      "⚠️ Não compartilhe essas informações com ninguém.",
      "",
      "Agradecemos pela preferência! ❤️",
    ].join("\n"),

    proj_keys: [
      "Obrigado por escolher nossos serviços.",
      "",
      "📩 Confira esta conversa. Quando seu sistema de Keys estiver concluído, ele será enviado por aqui.",
      "",
      "📧 Você também receberá:",
      "• E-mail da conta onde o sistema está hospedado.",
      "• Senha da conta.",
      "• Informações de acesso ao painel.",
      "",
      "⚠️ Não compartilhe essas informações com ninguém.",
      "",
      "Agradecemos pela preferência! ❤️",
    ].join("\n"),
  };

  const description = messages[productId] ?? [
    "Obrigado por escolher nossos serviços.",
    "",
    "📩 Confira esta conversa. Quando seu projeto estiver concluído, ele será enviado por aqui.",
    "",
    "Agradecemos pela preferência! ❤️",
  ].join("\n");

  return new EmbedBuilder()
    .setTitle("🎉 Pedido Confirmado!")
    .setColor(0x00c853)
    .setDescription(description)
    .setTimestamp();
}

// ─── Admin panel buttons ──────────────────────────────────────────────────
function buildAdminPanel(
  channelId: string,
  userId: string,
  productId: string
): ActionRowBuilder<MessageActionRowComponentBuilder>[] {
  const row = new ActionRowBuilder<MessageActionRowComponentBuilder>().addComponents(
    new ButtonBuilder()
      .setCustomId(`t2_fin:${channelId}:${userId}:${productId}`)
      .setLabel("✅ Finalizar Pedido")
      .setStyle(ButtonStyle.Success),
    new ButtonBuilder()
      .setCustomId(`t2_cls:${channelId}`)
      .setLabel("🔒 Fechar Ticket")
      .setStyle(ButtonStyle.Secondary),
  );
  return [row];
}

function buildFinalizedPanel(): ActionRowBuilder<MessageActionRowComponentBuilder>[] {
  const row = new ActionRowBuilder<MessageActionRowComponentBuilder>().addComponents(
    new ButtonBuilder()
      .setCustomId("t2_done")
      .setLabel("✅ Pedido Finalizado")
      .setStyle(ButtonStyle.Success)
      .setDisabled(true),
  );
  return [row];
}

// ─── Create ticket on order confirmation ─────────────────────────────────
export async function createTicket2(
  interaction: ButtonInteraction,
  client: Client,
  productId: string,
): Promise<void> {
  const product = products2[productId];

  if (!product) {
    await interaction.reply({ content: "❌ Produto não encontrado.", ephemeral: true });
    return;
  }

  if (!interaction.guild) {
    await interaction.reply({ content: "❌ Este sistema só funciona em servidores.", ephemeral: true });
    return;
  }

  // Defer so we have time to create the channel
  await interaction.deferUpdate();

  const guild      = interaction.guild;
  const userId     = interaction.user.id;
  const safeUser   = interaction.user.username.toLowerCase().replace(/[^a-z0-9]/g, "").slice(0, 20) || "usuario";

  // Find ticket category (optional — uses any category with "ticket" in the name)
  const categoryId = guild.channels.cache.find(
    c => c.type === ChannelType.GuildCategory && c.name.toLowerCase().includes("ticket")
  )?.id;

  // ── Permission overwrites ──────────────────────────────────────────────
  const clientPerms = [
    PermissionFlagsBits.ViewChannel,
    PermissionFlagsBits.SendMessages,
    PermissionFlagsBits.ReadMessageHistory,
    PermissionFlagsBits.AttachFiles,
    PermissionFlagsBits.EmbedLinks,
  ];
  const staffPerms = [
    PermissionFlagsBits.ViewChannel,
    PermissionFlagsBits.SendMessages,
    PermissionFlagsBits.ReadMessageHistory,
    PermissionFlagsBits.ManageChannels,
    PermissionFlagsBits.ManageMessages,
    PermissionFlagsBits.AttachFiles,
    PermissionFlagsBits.EmbedLinks,
  ];

  const permissionOverwrites: { id: string; allow?: bigint[]; deny?: bigint[] }[] = [
    { id: guild.id,         deny:  [PermissionFlagsBits.ViewChannel] },
    { id: userId,           allow: clientPerms },
    { id: client.user!.id, allow: staffPerms  },
    { id: FOUNDER_ROLE_ID, allow: staffPerms  },
    { id: ADMIN_ROLE_ID,   allow: staffPerms  },
    { id: SUPPORT_ROLE_ID, allow: staffPerms  },
  ];

  // ── Create the ticket channel ──────────────────────────────────────────
  const ticketChannel = await guild.channels.create({
    name: `pedido-${safeUser}`,
    type: ChannelType.GuildText,
    parent: categoryId,
    permissionOverwrites,
  });

  // 1. Order summary + mention Fundador to notify the team
  await ticketChannel.send({
    content: `<@&${FOUNDER_ROLE_ID}>`,
    embeds: [
      new EmbedBuilder()
        .setTitle("🎉 Seu pedido foi registrado com sucesso!")
        .setColor(0x00c853)
        .addFields(
          { name: "📦 Produto", value: `**${product.label}**`, inline: true },
          { name: "💰 Valor",   value: `**${product.price}**`, inline: true },
          { name: "👤 Cliente", value: `<@${userId}>`,         inline: true },
        )
        .setDescription("⏳ Aguarde um membro da equipe.")
        .setTimestamp(),
    ],
  });

  // 2. Instructions for the client
  await ticketChannel.send({
    embeds: [
      new EmbedBuilder()
        .setTitle("📝 Informações do Projeto")
        .setColor(0x8b00ff)
        .setDescription(
          [
            "Por favor, nos forneça as seguintes informações:",
            "",
            "📝 **Explique detalhadamente como deseja o projeto.**",
            "",
            "🖼️ **Envie imagens de referência** *(opcional)*.",
            "",
            "📋 **Informe qualquer observação importante.**",
          ].join("\n")
        )
        .setFooter({ text: "Nossa equipe analisará e entrará em contato em breve." }),
    ],
  });

  // 3. Admin panel (only admins can interact)
  await ticketChannel.send({
    embeds: [
      new EmbedBuilder()
        .setTitle("🔧 Painel Administrativo")
        .setColor(0xff6d00)
        .setDescription(
          "**Exclusivo para a equipe.** Use os botões abaixo para gerenciar este pedido."
        )
        .setFooter({ text: "Apenas administradores podem interagir com estes botões." }),
    ],
    components: buildAdminPanel(ticketChannel.id, userId, productId),
  });

  // 4. Update the original "Confirmar Pedido" message to confirm ticket was opened
  await interaction.editReply({
    embeds: [
      new EmbedBuilder()
        .setTitle("✅ Ticket Criado!")
        .setColor(0x00c853)
        .setDescription(
          `Seu ticket foi criado em ${ticketChannel}.\n\nAcesse o canal para acompanhar seu pedido.`
        )
        .addFields(
          { name: "📦 Produto", value: `**${product.label}**`, inline: true },
          { name: "💰 Valor",   value: `**${product.price}**`, inline: true },
        )
        .setTimestamp(),
    ],
    components: [],
  });

  logger.info({ ticketChannelId: ticketChannel.id, userId, productId }, "Ticket created for panel 2 order");
}

// ─── Admin permission check ───────────────────────────────────────────────
function isAdminOrFounder(member: GuildMember): boolean {
  return (
    member.permissions.has(PermissionFlagsBits.Administrator) ||
    member.roles.cache.some(r => r.name === FOUNDER_ROLE_NAME)
  );
}

// ─── Handle admin panel buttons ───────────────────────────────────────────
export async function handleAdminButton2(
  interaction: ButtonInteraction,
  client: Client,
  refreshPanel: (client: Client) => Promise<void>,
): Promise<void> {
  const member = interaction.member as GuildMember;

  if (!isAdminOrFounder(member)) {
    await interaction.reply({
      content: "❌ Apenas administradores podem usar estes botões.",
      ephemeral: true,
    });
    return;
  }

  // customId formats:
  //   t2_fin:<channelId>:<userId>:<productId>
  //   t2_cls:<channelId>
  const [action, channelId, userId, productId] = interaction.customId.split(":");
  const product = productId ? products2[productId] : null;

  // ── Permission check ──────────────────────────────────────────────────
  const adminMember = interaction.member as GuildMember;
  if (![FOUNDER_ROLE_ID, ADMIN_ROLE_ID, SUPPORT_ROLE_ID].some(id => adminMember?.roles?.cache?.has(id))) {
    await interaction.reply({ content: "❌ Você não tem permissão para usar este botão.", ephemeral: true });
    return;
  }

  // ── ✅ Finalizar Pedido ─────────────────────────────────────────────────
  if (action === "t2_fin") {
    // Prevent double-finalization
    if (finalizedTickets.has(channelId)) {
      await interaction.reply({
        content: "⚠️ Este pedido já foi finalizado.",
        ephemeral: true,
      });
      return;
    }

    await interaction.deferReply();

    // Mark as finalized immediately to block concurrent clicks
    finalizedTickets.add(channelId);

    // Disable the admin panel buttons so no one can click again
    try {
      await interaction.message.edit({ components: buildFinalizedPanel() });
    } catch {
      // Non-critical — continue even if edit fails
    }

    // Decrement stock (only on finalization)
    await decrementStock(productId);

    // DM the client with a per-product message
    try {
      const user = await client.users.fetch(userId);
      await user.send({ embeds: [buildFinalizationDM(productId)] });
      logger.info({ userId, productId }, "DM sent to client on order finalization");
    } catch (err) {
      logger.warn({ err, userId }, "Could not DM client — DMs may be disabled");
    }

    // Post finalization summary in the ticket
    await interaction.editReply({
      embeds: [
        new EmbedBuilder()
          .setColor(0x00c853)
          .setTitle("✅ Pedido Finalizado")
          .setDescription(
            `O pedido de **${product?.label ?? productId}** foi finalizado por <@${interaction.user.id}>.\n\nEstoque atualizado. <@${userId}> foi notificado via DM.\n\n🔒 Ticket será fechado em 5 segundos.`
          )
          .setTimestamp(),
      ],
    });

    // Refresh panel so stock counter updates for everyone
    await refreshPanel(client);
    logger.info({ productId, channelId, adminId: interaction.user.id }, "Panel 2 order finalized");

    // Auto-close the ticket after a short delay
    setTimeout(async () => {
      try {
        if (interaction.channel && !interaction.channel.isDMBased()) {
          await interaction.channel.delete("Pedido finalizado — ticket encerrado automaticamente");
        }
      } catch (err) {
        logger.error({ err }, "Failed to auto-close ticket channel after finalization");
      }
    }, 5000);
    return;
  }

  // ── 🔒 Fechar Ticket ────────────────────────────────────────────────────
  if (action === "t2_cls") {
    await interaction.reply({ content: "🔒 Fechando ticket em 5 segundos...", ephemeral: true });
    setTimeout(async () => {
      try {
        if (interaction.channel && !interaction.channel.isDMBased()) {
          await interaction.channel.delete("Ticket fechado pela equipe");
        }
      } catch (err) {
        logger.error({ err }, "Failed to delete ticket channel");
      }
    }, 5000);
    return;
  }
}
