import 'dotenv/config';
import { Client, Collection, GatewayIntentBits, Events } from "discord.js";
import type { Command } from "./types.js";
import pingCommand from "./commands/ping.js";
import helpCommand from "./commands/help.js";
import serverInfoCommand from "./commands/serverinfo.js";
import painelCommand,  { handleProductSelect,  refreshPanel  } from "./commands/painel.js";
import painel2Command, { handleProductSelect2, refreshPanel2 } from "./commands/painel2.js";
import adminCommand from "./commands/admin.js";
import dmCommand from "./commands/dm.js";
import suporteCommand from "./commands/suporte.js";
import { createTicket1, handleAdminButton1 } from "./tickets.js";
import { createTicket2, handleAdminButton2 } from "./tickets2.js";
import { openSupportTicket, closeSupportTicket } from "./tickets-suporte.js";
import { logger } from "./logger.js";

const token = process.env.DISCORD_TOKEN;
if (!token) {
  logger.error("DISCORD_TOKEN environment variable is not set. Exiting.");
  process.exit(1);
}

const client = new Client({
  intents: [GatewayIntentBits.Guilds],
});

const commands = new Collection<string, Command>();

for (const command of [
  pingCommand,
  helpCommand,
  serverInfoCommand,
  painelCommand,
  painel2Command,
  adminCommand,
  dmCommand,
  suporteCommand,
]) {
  commands.set(command.data.name, command);
  logger.info({ command: command.data.name }, "Registered command");
}

client.once(Events.ClientReady, (c) => {
  logger.info({ tag: c.user.tag, guilds: c.guilds.cache.size }, "Bot is online and ready");
  refreshPanel(c);
  refreshPanel2(c);
});

client.on(Events.InteractionCreate, async (interaction) => {
  // ── Slash commands ──────────────────────────────────────────────────────
  if (interaction.isChatInputCommand()) {
    const command = commands.get(interaction.commandName);
    if (!command) {
      logger.warn({ command: interaction.commandName }, "Unknown command received");
      return;
    }

    try {
      await command.execute(interaction);
      logger.info(
        { command: interaction.commandName, user: interaction.user.tag },
        "Command executed"
      );
    } catch (err) {
      logger.error({ err, command: interaction.commandName }, "Error executing command");
      const reply = { content: "Ocorreu um erro ao executar este comando.", ephemeral: true };
      if (interaction.replied || interaction.deferred) {
        await interaction.followUp(reply);
      } else {
        await interaction.reply(reply);
      }
    }
    return;
  }

  // ── Select menus ────────────────────────────────────────────────────────
  if (interaction.isStringSelectMenu()) {
    const id  = interaction.customId;
    const log = { value: interaction.values[0], user: interaction.user.tag };

    if (id === "painel_produto") {
      try {
        await handleProductSelect(interaction);
        logger.info(log, "Panel 1 product selected");
      } catch (err) {
        logger.error({ err }, "Error handling panel 1 product select");
        if (!interaction.replied)
          await interaction.reply({ content: "Ocorreu um erro ao processar sua seleção.", ephemeral: true });
      }
      return;
    }

    if (id === "painel2_produto") {
      try {
        await handleProductSelect2(interaction);
        logger.info(log, "Panel 2 product selected");
      } catch (err) {
        logger.error({ err }, "Error handling panel 2 product select");
        if (!interaction.replied)
          await interaction.reply({ content: "Ocorreu um erro ao processar sua seleção.", ephemeral: true });
      }
      return;
    }
  }

  // ── Buttons ─────────────────────────────────────────────────────────────
  if (interaction.isButton()) {
    const id = interaction.customId;

    // Panel 1 — "Confirmar Pedido" → creates key ticket
    if (id.startsWith("painel_confirmar:")) {
      const productId = id.split(":")[1];
      try {
        await createTicket1(interaction, client, productId);
        logger.info({ productId, user: interaction.user.tag }, "Ticket created for panel 1 key order");
      } catch (err) {
        logger.error({ err }, "Error creating ticket for panel 1 key order");
        if (!interaction.replied && !interaction.deferred)
          await interaction.reply({ content: "Ocorreu um erro ao criar o ticket. Tente novamente.", ephemeral: true });
      }
      return;
    }

    // Panel 1 — Admin panel buttons (t1_fin, t1_cls)
    if (id.startsWith("t1_")) {
      try {
        await handleAdminButton1(interaction, client, refreshPanel);
        logger.info({ customId: id, user: interaction.user.tag }, "Panel 1 admin button clicked");
      } catch (err) {
        logger.error({ err }, "Error handling panel 1 admin button");
        if (!interaction.replied && !interaction.deferred)
          await interaction.reply({ content: "Ocorreu um erro ao processar esta ação.", ephemeral: true });
      }
      return;
    }

    // Panel 2 — "Confirmar Pedido" → creates ticket
    if (id.startsWith("painel2_confirmar:")) {
      const productId = id.split(":")[1];
      try {
        await createTicket2(interaction, client, productId);
        logger.info({ productId, user: interaction.user.tag }, "Ticket created for panel 2 order");
      } catch (err) {
        logger.error({ err }, "Error creating ticket for panel 2 order");
        if (!interaction.replied && !interaction.deferred)
          await interaction.reply({ content: "Ocorreu um erro ao criar o ticket. Tente novamente.", ephemeral: true });
      }
      return;
    }

    // Panel 2 — Admin panel buttons (t2_pay, t2_dev, t2_fin, t2_can, t2_cls)
    if (id.startsWith("t2_")) {
      try {
        await handleAdminButton2(interaction, client, refreshPanel2);
        logger.info({ customId: id, user: interaction.user.tag }, "Panel 2 admin button clicked");
      } catch (err) {
        logger.error({ err }, "Error handling panel 2 admin button");
        if (!interaction.replied && !interaction.deferred)
          await interaction.reply({ content: "Ocorreu um erro ao processar esta ação.", ephemeral: true });
      }
      return;
    }

    // Support panel — Open ticket
    if (id === "suporte_open") {
      try {
        await openSupportTicket(interaction, client);
        logger.info({ user: interaction.user.tag }, "Support ticket opened");
      } catch (err) {
        logger.error({ err }, "Error opening support ticket");
        if (!interaction.replied && !interaction.deferred)
          await interaction.reply({ content: "Ocorreu um erro ao abrir o ticket. Tente novamente.", ephemeral: true });
      }
      return;
    }

    // Support panel — Close ticket
    if (id.startsWith("suporte_close:")) {
      try {
        await closeSupportTicket(interaction);
        logger.info({ user: interaction.user.tag, channelId: interaction.channelId }, "Support ticket closed");
      } catch (err) {
        logger.error({ err }, "Error closing support ticket");
        if (!interaction.replied && !interaction.deferred)
          await interaction.reply({ content: "Ocorreu um erro ao fechar o ticket.", ephemeral: true });
      }
      return;
    }
  }
});

client.login(token);
