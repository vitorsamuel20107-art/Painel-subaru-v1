import { REST, Routes } from "discord.js";
import pingCommand from "./commands/ping.js";
import helpCommand from "./commands/help.js";
import serverInfoCommand from "./commands/serverinfo.js";
import painelCommand from "./commands/painel.js";
import painel2Command from "./commands/painel2.js";
import adminCommand from "./commands/admin.js";
import dmCommand from "./commands/dm.js";
import suporteCommand from "./commands/suporte.js";
import { logger } from "./logger.js";

const token = process.env.DISCORD_TOKEN;
const clientId = process.env.DISCORD_CLIENT_ID;
const guildId = process.env.DISCORD_GUILD_ID;

if (!token || !clientId) {
  logger.error(
    "DISCORD_TOKEN and DISCORD_CLIENT_ID must be set before deploying commands."
  );
  process.exit(1);
}

const commandData = [
  pingCommand,
  helpCommand,
  serverInfoCommand,
  painelCommand,
  painel2Command,
  adminCommand,
  dmCommand,
  suporteCommand,
].map((c) => c.data.toJSON());

const rest = new REST().setToken(token);

if (guildId) {
  logger.info({ guildId, count: commandData.length }, "Deploying guild commands (instant)");
  await rest.put(Routes.applicationGuildCommands(clientId, guildId), {
    body: commandData,
  });
  logger.info("Guild commands deployed successfully");
} else {
  logger.info({ count: commandData.length }, "Deploying global commands");
  await rest.put(Routes.applicationCommands(clientId), { body: commandData });
  logger.info(
    "Global commands deployed — may take up to 1 hour to appear in all servers"
  );
}
