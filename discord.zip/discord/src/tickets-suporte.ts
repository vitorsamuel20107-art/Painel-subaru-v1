/**
 * tickets-suporte.ts — Ticket system for the support panel.
 * Handles ticket creation (suporte_open) and closing (suporte_close).
 */

import {
  ChannelType,
  PermissionFlagsBits,
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
} from "discord.js";
import type {
  ButtonInteraction,
  Client,
  GuildMember,
  MessageActionRowComponentBuilder,
} from "discord.js";
import { FOUNDER_ROLE_NAME, FOUNDER_ROLE_ID, ADMIN_ROLE_ID, SUPPORT_ROLE_ID } from "./constants.js";
import { logger } from "./logger.js";

function hasPermission(member: GuildMember | null): boolean {
  if (!member) return false;
  return [FOUNDER_ROLE_ID, ADMIN_ROLE_ID, SUPPORT_ROLE_ID]
    .some(id => member.roles.cache.has(id));
}

// ── Open support ticket ────────────────────────────────────────────────────
export async function openSupportTicket(
  interaction: ButtonInteraction,
  client: Client
): Promise<void> {
  const guild  = interaction.guild;
  const member = interaction.member as GuildMember;

  if (!guild || !member) {
    await interaction.reply({ content: "❌ Erro ao abrir ticket.", ephemeral: true });
    return;
  }

  // Check if user already has an open support ticket
  const existing = guild.channels.cache.find(
    (ch) =>
      ch.name === `suporte-${member.user.username.toLowerCase().replace(/\s+/g, "-")}` &&
      ch.isTextBased()
  );

  if (existing) {
    await interaction.reply({
      content: `⚠️ Você já possui um ticket aberto: ${existing}`,
      ephemeral: true,
    });
    return;
  }

  const staffAllow = [
    PermissionFlagsBits.ViewChannel,
    PermissionFlagsBits.SendMessages,
    PermissionFlagsBits.ReadMessageHistory,
    PermissionFlagsBits.ManageMessages,
    PermissionFlagsBits.ManageChannels,
    PermissionFlagsBits.AttachFiles,
  ];

  const overwrites: Parameters<typeof guild.channels.create>[0]["permissionOverwrites"] = [
    { id: guild.roles.everyone, deny:  [PermissionFlagsBits.ViewChannel] },
    {
      id:    member.id,
      allow: [
        PermissionFlagsBits.ViewChannel,
        PermissionFlagsBits.SendMessages,
        PermissionFlagsBits.ReadMessageHistory,
        PermissionFlagsBits.AttachFiles,
      ],
    },
    { id: FOUNDER_ROLE_ID,  allow: staffAllow },
    { id: ADMIN_ROLE_ID,    allow: staffAllow },
    { id: SUPPORT_ROLE_ID,  allow: staffAllow },
  ];

  if (client.user) {
    overwrites.push({
      id:    client.user.id,
      allow: [
        PermissionFlagsBits.ViewChannel,
        PermissionFlagsBits.SendMessages,
        PermissionFlagsBits.ManageChannels,
        PermissionFlagsBits.ReadMessageHistory,
      ],
    });
  }

  const channelName   = `suporte-${member.user.username.toLowerCase().replace(/\s+/g, "-")}`;
  const ticketChannel = await guild.channels.create({
    name: channelName,
    type: ChannelType.GuildText,
    permissionOverwrites: overwrites,
  });

  const welcomeEmbed = new EmbedBuilder()
    .setTitle("🎫 Ticket de Suporte")
    .setColor(0x8b00ff)
    .setDescription(
      [
        `Olá, ${member}! 👋`,
        "",
        "Nossa equipe está disponível para ajudá-lo.",
        "Por favor, **descreva sua dúvida ou problema** abaixo e aguarde o atendimento.",
        "",
        "⏳ Responderemos o mais breve possível.",
        "⚠️ Não feche este ticket antes de resolver sua questão.",
      ].join("\n")
    )
    .setFooter({ text: "Night Cheats • Suporte" })
    .setTimestamp();

  const closeRow = new ActionRowBuilder<MessageActionRowComponentBuilder>().addComponents(
    new ButtonBuilder()
      .setCustomId(`suporte_close:${ticketChannel.id}`)
      .setLabel("🔒 Fechar Ticket")
      .setStyle(ButtonStyle.Danger)
  );

  await ticketChannel.send({
    content: `${member} <@&${FOUNDER_ROLE_ID}> <@&${SUPPORT_ROLE_ID}>`,
    embeds: [welcomeEmbed],
    components: [closeRow],
  });

  await interaction.reply({
    content: `✅ Ticket aberto: ${ticketChannel}`,
    ephemeral: true,
  });

  logger.info(
    { userId: member.id, channelId: ticketChannel.id },
    "Support ticket opened"
  );
}

// ── Close support ticket ───────────────────────────────────────────────────
export async function closeSupportTicket(
  interaction: ButtonInteraction
): Promise<void> {
  const member = interaction.member as GuildMember;

  if (!hasPermission(member)) {
    await interaction.reply({
      content: "❌ Você não tem permissão para fechar este ticket.",
      ephemeral: true,
    });
    return;
  }

  await interaction.reply({
    content: "🔒 Fechando ticket em 5 segundos...",
    ephemeral: true,
  });

  setTimeout(async () => {
    try {
      if (interaction.channel && !interaction.channel.isDMBased()) {
        await interaction.channel.delete("Ticket de suporte encerrado pela equipe");
      }
    } catch (err) {
      logger.error({ err }, "Failed to delete support ticket channel");
    }
  }, 5000);

  logger.info(
    { adminId: interaction.user.id, channelId: interaction.channelId },
    "Support ticket closed"
  );
}
