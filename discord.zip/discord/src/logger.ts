import pino from "pino";

export const logger = pino({
  name: "discord-bot",
  transport:
    process.env.NODE_ENV === "development"
      ? { target: "pino-pretty", options: { colorize: true } }
      : undefined,
});
