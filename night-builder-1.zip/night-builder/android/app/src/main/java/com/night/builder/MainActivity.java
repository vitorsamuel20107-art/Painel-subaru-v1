package com.night.builder;

import android.os.Bundle;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        registerPlugin(NightBuilderPlugin.class);
        super.onCreate(savedInstanceState);
    }
}
